<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-primary" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>

<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">

     <hr>
     <h2>Artilharia</h2>
     <thead>
     <tr>
     <th scope="col">Ranking</th>
     <th scope="col">Posição</th>
     <th scope="col">Jogador</th>
     <th scope="col">Número de Gols </th>
     <th scope="col">Time</th>
     </tr>
     <tbody>
     <tr>
     <th scope="row">1</th>
     <td>Atacante</td>
     <td>Gustavo Coutinho</td>
     <td>14</td>
     <td>Vitória</td>
      
         </tr>
     <tr>
     <th scope="row">2</th>
     <td>Atacante</td>
     <td>Ytalo</td>
     <td>13</td>
     <td>Sampaio Correia</td>
     </tr>
     <tr>
     <th scope="row">3</th>
     <td>Atacante</td>
     <td>Vagner Love</td>
     <td>11</td>
     <td>Sport</td>
     </tr>
     <tr>
     <th scope="row">4</th>
     <td>Atacante</td>
     <td>Leo Gamalho</td>
     <td>10</td>
     <td>Vitoria</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Erick de Arruda</td>
     <td>10</td>
     <td>Ceará</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Caio Dantas</td>
     <td>10</td>
     <td>Guarani</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Derek</td>
     <td>10</td>
     <td>Guarani</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Eder</td>
     <td>9</td>
     <td>Criciuma</td>
     </tr>
      
         <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Fernandão</td>
     <td>9</td>
     <td>Tombense</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Aselmo</td>
     <td>9</td>
     <td>Crb</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Luiz Fernando</td>
     <td>9</td>
     <td>Atletico GO</td>
     </tr>
     <tr>
     <th scope="row">5</th>
     <td>Meia</td>
     <td>Ze Roberto</td>
     <td>8</td>
     <td>Mirassol</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Bruno Nazario</td>
     <td>8</td>
     <td>Mirassol</td>
     </tr>
     <tr>
     <th scope="row">6</th>
     <td>Meia</td>
     <td>Luciano Juba</td>
     <td>7</td>
     <td>Londrina</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Renato</td>
     <td>7</td>
     <td>CRB</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Bruninho</td>
     <td>7</td>
     <td>Guarani</td>
     </tr>
     
     
     </tbody>
     <table style="border: solid; border-width: 2px;"><table border="1">
     <table class="table">
     <hr>
     <h2>Assistentes</h2>
     <thead>
     <tr>
     <th scope="col">Ranking</th>
     <th scope="col">Posição</th>
     <th scope="col">Jogador</th>
     <th scope="col">Número de assistências </th>
     <th scope="col">Time</th>
     </tr>
     <tr>
     <th scope="row">1</th>
     <td>Atacante</td>
     <td>Osvaldo</td>
     <td>9</td>
     <td>Vitória</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Felipe Mateus</td>
     <td>9</td>
     <td>Criciuma</td>
     </tr>
     
     <tr>
     <th scope="row">2</th>
     <td>Meia</td>
     <td>Nene</td>
     <td>7</td>
     <td>Juventude</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Bruno José</td>
     <td>7</td>
     <td>Guarani</td>
     </tr>
     <tr>
     <th scope="row">3</th>
     <td>Atacante</td>
     <td>Bruno Nazario</td>
     <td>6</td>
     <td>Chapecoense</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Shaylon</td>
     <td>6</td>
     <td>Atlético-GO</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Parede</td>
     <td>6</td>
     <td>Vila Nova</td>
     </tr>
     <tr>
     <th scope="row">4</th>
     <td>Atacante</td>
     <td>Luciano Juba</td>
     <td>5</td>
     <td>Sport</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Jorginho</td>
     <td>5</td>
     <td>Sport </td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>David</td>
     <td>5</td>
     <td>Juventude</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Frizzo</td>
     <td>5</td>
     <td>Tombense</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Lateral-esquerdo</td>
     <td>Egídio</td>
     <td>5</td>
     <td>Tombense</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Lateral-direito</td>
     <td>Diogo Hereda</td>
     <td>5</td>
     <td>CRB</td>
     </tr>
     <tr>
     <th scope="row">6</th>
     <td>Meia</td>
     <td>Negueba</td>
     <td>5</td>
     <td>Mirassol</td>
     </tr>
     
     </thead>
     <table style="border: solid; border-width: 2px;"><table border="1">
     <table class="table">
     <h2>Cartões amarelos</h2>
     <thead>
     <tr>
     <th scope="col">Ranking</th>
     <th scope="col">Posição</th>
     <th scope="col">Jogador</th>
     <th scope="col">Número de cartões amarelos </th>
     <th scope="col">Time</th>
     <tr>
     <th scope="row">1</th>
     <td>Meia</td>
     <td>Bruno Silva</td>
     <td>16</td>
     <td>Tombense</td>
     </tr>
     <tr>
     <th scope="row">2</th>
     <td>Meia</td>
     <td>Gustavo Cazonatti</td>
     <td>13</td>
     <td>Chapecoense</td>
     </tr>
     <tr>
     <th scope="row">3</th>
     <td>Lateral-Esquerdo</td>
     <td>Artur</td>
     <td>12</td>
     <td>Ponte Preta</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Zagueiro</td>
     <td>Wellington</td>
     <td>12</td>
     <td>Avai</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Aldo</td>
     <td>12</td>
     <td>Ituano</td>
     </tr>
      
         <tr>
     <th scope="row"></th>
     <td>Lateral-direito</td>
     <td>Jean</td>
     <td>12</td>
     <td>Juventude</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Guilherme</td>
     <td>11</td>
     <td>Botafogo-SP</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Cristovam</td>
     <td>11</td>
     <td>Criciúma</td>
     </tr>
     <tr>
     <th scope="row">4</th>
     <td>Meia</td>
     <td>Ezequiel</td>
     <td>10</td>
     <td>Londrina</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Jean</td>
     <td>10</td>
     <td>Juventude</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Mateus</td>
     <td>10</td>
     <td>Ponte Preta</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Matheus Barbosa</td>
     <td>10</td>
     <td>Guarani</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>J. Aldo</td>
     <td>10</td>
     <td>Ituano</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Bruno </td>
     <td>10</td>
     <td>Chapecoense</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Zagueiro</td>
     <td>Fábio Alemão </td>
     <td>10</td>
     <td>CRB</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Tarik</td>
     <td>10</td>
     <td>Botafogo-SP</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>João Paulo</td>
     <td>10</td>
     <td>Londrina</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Zagueiro</td>
     <td>Camutanga</td>
     <td>10</td>
     <td>Vitória</td>
     </tr>
     <tr>
     <th scope="row">5</th>
     <td>Meia</td>
     <td>Wellington Reis</td>
     <td>9</td>
     <td>ABC</td>
     </tr>
     
     </thead>
     <table style="border: solid; border-width: 2px;"><table border="1">
     <table class="table">
     <h2>Cartões vermelhos</h2>
      
       <thead>
      
         <tr>
     <th scope="col">Ranking</th>
     <th scope="col">Posição</th>
     <th scope="col">Jogador</th>
     <th scope="col">Número de cartões vermelhos </th>
     <th scope="col">Time</th>
     <tr>
     <th scope="row">1</th>
     <td>Meia</td>
     <td>Matheus Bueno</td>
     <td>2</td>
     <td>Guarani</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Airton</td>
     <td>2</td>
     <td>Atlético-GO</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Paulinho</td>
     <td>2</td>
     <td>Londrina</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Zagueiro</td>
     <td>Claudinho</td>
     <td>2</td>
     <td>Ituano</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Zagueiro</td>
     <td>Alan</td>
     <td>2</td>
     <td>Guarani</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Matheus Jesus</td>
     <td>2</td>
     <td>Ponte Preta</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Zagueiro</td>
     <td>Fábio Sanches</td>
     <td>2</td>
     <td>Ponte Preta</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Jeh</td>
     <td>2</td>
     <td>Ponte Preta</td>
     </tr>
     
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Felipe Garcia</td>
     <td>2</td>
     <td>ABC</td>
     </tr>
     <tr>
     <th scope="row">2</th>
     <td>Jadson</td>
     <td>Juventude</td>
     <td>1</td>
     <td>Náutico</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Camatunga</td>
     <td>1</td>
     <td>Vitória</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Lateral-esquerdo</td>
     <td>Natanael</td>
     <td>1</td>
     <td>Avaí</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Bruno Silva</td>
     <td>1</td>
     <td>Tombense</td>
     </tr>
      
     <tr>
     <th scope="row"></th>
     <td>Atacante</td>
     <td>Eder</td>
     <td>1</td>
     <td>Criciúma</td>
     </tr>
     <tr>
     <th scope="row"></th>
     <td>Meia</td>
     <td>Ezequiel</td>
     <td>1</td>
     <td>Londrina</td>
     </tr>
     
    <div vw class="enabled">
     <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 
  </body>
</html>