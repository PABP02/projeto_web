<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
  <thead>
   <tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de Gols </th>
<th scope="col">Time</th>

</tr>
<tbody>

<tr>
<th scope="row">1</th>
<td>Atacante</td>
<td>Haaland</td>
<td>13</td>
<td>Man. City</td>

 

    </tr>
    <tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Salah</td>
<td>10</td>
<td>Liverpool</td>
</tr>
    <tr>
<th scope="row">3</th>
<td>Atacante</td>
<td>Son</td>
<td>8</td>
<td>Tottenham</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Bowen</td>
<td>8</td>
<td>West Ham</td>
</tr>
<tr>
<th scope="row">4</th>
<td>Atacante</td>
<td>Wilson</td>
<td>7</td>
<td>Newcastle</td>
</tr>
<tr>
<th scope="row">5</th>
<td>Atacante</td>
<td>Isak</td>
<td>6</td>
<td>Newcastle</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>N.Jackson</td>
<td>6</td>
<td>Chelsea</td>
</tr>
 


<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Hee-Chan hWang</td>
<td>6</td>
<td>Wolwes</td>
</tr>

<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Watkins</td>
<td>6</td>
<td>Aston Villa</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Mbeumo</td>
<td>6</td>
<td>Brentford</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Solanke</td>
<td>6</td>
<td>Bournemouth</td>
</tr>


    <tr>
<th scope="row">6</th>
<td>Atacante</td>
<td>Ferguson</td>
<td>5</td>
<td>Brighton</td>
</tr>

<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Edouard</td>
<td>5</td>
<td>Crystal Palace</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Nketiah</td>
<td>5</td>
<td>Arsenal</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Douglas Luiz</td>
<td>5</td>
<td>Aston Villa</td>
</tr>

<tr>
<th scope="row">7</th>
<td>Atacante</td>
<td>Saka</td>
<td>4</td>
<td>Arsenal</td>
</tr>

 



<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Sterling</td>
<td>4</td>
<td>Chelsea</td>
</tr>

 

    <tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Alvarez</td>
<td>4</td>
<td>Manchester City</td>
</tr>

</tbody>

<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<hr>
<h2>Assistentes</h2>
<thead>
<tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de assistências </th>
<th scope="col">Time</th>

</tr>
<tr>
<th scope="row">1</th>
<td>Atacante</td>
<td>Pedro Neto</td>
<td>7</td>
<td>Wolwes</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Lateral Direito</td>
<td>Trippier</td>
<td>6</td>
<td>Newcastle</td>
</tr>
<tr>
<th scope="row">3</th>
<td>Meia</td>
<td>Maddison</td>
<td>5</td>
<td>Tottenhan</td>
</tr>
    <tr>
<th scope="row"></th>
<td>Meia</td>
<td>Ward Prowse</td>
<td>5</td>
<td>West Ham</td>
</tr>
   <tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Doku</td>
<td>5</td>
<td>Manchester City</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Watkins</td>
<td>5</td>
<td>Aston Villa</td>
</tr>
<tr>
<th scope="row">4</th>
<td>Atacante</td>
<td>Salah</td>
<td>4</td>
<td>Liverpool</td>
</tr>

    <tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Julian Alvarez</td>
<td>4</td>
<td>Manchester City</td>
</tr>
<tr>
<th scope="row"></th>
<td>Lateral Direito</td>
<td>Coufal</td>
<td>4</td>
<td>West Ham</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Darwin Nunez</td>
<td>4</td>
<td>Liverpool</td>
</tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Saka</td>
<td>4</td>
<td>Arsenal</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Gallagher </td>
<td>4</td>
<td>Chelsea</td>
</tr>
<tr>
<th scope="row">5</th>
<td>Atacante</td>
<td>Mateta</td>
<td>3</td>
<td>Crystal Palace</td>
</tr>

 

        <tr>
<th scope="row"></th>
<td>Lateral Esquerdo</td>
<td>Estupinan</td>
<td>3</td>
<td>Brighton</td>
</tr>

 


<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Diaby</td>
<td>3</td>
<td>Aston Villa</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Mitoma</td>
<td>3</td>
<td>Brighton</td>
</tr>

 




</thead>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<h2>Cartões amarelos</h2>
<thead>
<tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de cartões amarelos </th>
<th scope="col">Time</th>
<tr>
<th scope="row">1</th>
<td>Atacante</td>
<td>Jackson</td>
<td>7</td>
<td>Chelsea</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Gordon</td>
<td>6</td>
<td>Newcastle</td>
</tr>  
<tr>
<th scope="row"></th>
<td>Bissouma</td>
<td>Volante</td>
<td>6</td>
<td>Tottenhan</td>
</tr>
<tr>
<th scope="row"></th>
<td>Lateral Esquerdo</td>
<td>Emerson</td>
<td>6</td>
<td>West Ham</td>
</tr>

<tr>
<th scope="row">3</th>
<td>Lateral Esquerdo</td>
<td>Hickey</td>
<td>5</td>
<td>Brentford</td>
</tr>
<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>Dawson</td>
<td>5</td>
<td>Wolwes</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Lemina</td>
<td>5</td>
<td>Wolwes</td>
</tr>


<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Bruno Guimarães</td>
<td>5</td>
<td>Newcastle</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Mac Allister</td>
<td>5</td>
<td>Liverpool</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Paquetá</td>
<td>5</td>
<td>West Ham</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Álvarez</td>
<td>5</td>
<td>West Ham</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Palhinha</td>
<td>5</td>
<td>Fulham</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Cullen</td>
<td>5</td>
<td>Burnley</td>
</tr>



<tr>
<th scope="row">4</th>
<td>Volante</td>
<td>Douglas Luiz</td>
<td>4</td>
<td>Aston Villa</td>
</tr>

<tr>
<th scope="row"></th>
<td>Lateral Esquerdo</td>
<td>Digne</td>
<td>4</td>
<td>Aston Villa</td>
</tr>

<tr>
<th scope="row"></th>
<td>Lateral Direito</td>
<td>Nelson Semedo</td>
<td>4</td>
<td>Wolwes</td>
</tr>

<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Havertz</td>
<td>4</td>
<td>Arsenal</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Kamara</td>
<td>4</td>
<td>Aston Villa</td>
</tr>





 

  </thead>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<h2>Cartões vermelhos</h2>

 

  <thead>

 

    <tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de cartões vermelhos </th>
<th scope="col">Time</th>
<tr>
<th scope="row">1</th>
<td>Meia</td>
<td>Casemiro</td>
<td>1</td>
<td>Manchester United</td>
</tr>

<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>Koulibaly</td>
<td>1</td>
<td>Chelsea</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Darwin N.</td>
<td>1</td>
<td>Liverpool</td>
</tr>


<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Mac Allister</td>
<td>1</td>
<td>Liverpool</td>
</tr>
<tr>
<th scope="row"></th>
<td>Volante</td>
<td>Bissouma</td>
<td>1</td>
<td>Tottenhan</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Lemina</td>
<td>1</td>
<td>Wolwes</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Jota</td>
<td>1</td>
<td>Liverpool</td>
</tr>
<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>Aguerd</td>
<td>1</td>
<td>West Ham</td>
</tr>
<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>Ream</td>
<td>1</td>
<td>Fulham</td>
</tr>


 <div vw class="enabled">
 <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

</body>
</html>