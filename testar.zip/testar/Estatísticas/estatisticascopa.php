<!DOCTYPE html>
<html>
<head>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
      <nav class="navbar navbar-expand-lg bg-black">
  <div class="container-fluid">
    <a class="navbar-brand text-" ><img src="../teste.PNG" width="150px"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         
         
          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
           <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
              <li><a class="dropdown-item text-"  href="Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classficação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../ htmls clubes/História do seu clube de  coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>
         
        </ul>    
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">
        <button class="btn btn-outline- text-info" type="submit">Buscar</button>
      </form>
    </div>
  </div>
</nav>

<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
 <tr>
  <thead>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número </th>
      <th scope="col">Time</th>
   </thead>
 </tr>
    <hr>
    <h2>Artilharia</h2>
  <thead>
 <tr>

  <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Mpappe</td>
      <td>8</td>
      <td>França</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Messi</td>
      <td>7</td>
      <td>Argentina</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Julian Alvarez</td>
      <td>4</td>
      <td>Argentina</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Giroud</td>
      <td>4</td>
      <td>França</td>
    </tr>
     <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>E.Valencia</td>
      <td>3</td>
      <td>Equador</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Rasfhord</td>
      <td>3</td>
      <td>Inglaterra</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>B.Saka</td>
      <td>3</td>
      <td>Inglaterra</td>
    </tr>

     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Richarlison</td>
      <td>3</td>
      <td>Brasil</td>
    </tr>
<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Alvaro Morata</td>
      <td>3</td>
      <td>Espanha</td>
    </tr>


      <th scope="row"></th>
      <td>Atacante</td>
      <td>Gakpo</td>
      <td>3</td>
      <td>Holanda</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Gonçalo Ramos</td>
      <td>3</td>
      <td>Gana</td>
    </tr>
      <tr>
      <th scope="row">5</th>
      <td>Atacante</td>
      <td>Taremi</td>
      <td>2</td>
      <td>irá</td>
    </tr>  
<tr>
      <th scope="row">5</th>
      <td>Atacante</td>
      <td>Kramaric</td>
      <td>2</td>
      <td>Croacia</td>
    </tr>
     <tr>
      <th scope="row">5</th>
      <td>Meia</td>
      <td>B.Fernandes</td>
      <td>2</td>
      <td>Portugal</td>
    </tr>

    <tr>
      <th scope="row">5</th>
      <td>Atacante</td>
      <td>Ferran Torres</td>
      <td>2</td>
      <td>Espanha</td>
    </tr>
 
    <tr>
      <th scope="row">5</th>
      <td>Meia</td>
      <td>Kudus</td>
      <td>2</td>
      <td>Gana</td>
    </tr>
   
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
   
    </tr>
     <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Bruno Fernandes</td>
      <td>3</td>
      <td>Portugal</td>
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Kane</td>
      <td>3</td>
      <td>Inglaterra</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Griezmann</td>
      <td>3</td>
      <td>França</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Perisic</td>
      <td>3</td>
      <td>Croacia</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Messi</td>
      <td>3</td>
      <td>Argentina </td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Thuram</td>
      <td>2</td>
      <td>França</td>
    </tr>
     
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Zivkoivc</td>
      <td>2</td>
      <td>Croacia</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Klaasen</td>
      <td>2</td>
      <td>Holanda</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Lateral-Esquerdo</td>
      <td>Jordi Alba</td>
      <td>2</td>
      <td>Espanha</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-Esquedo</td>
      <td>Theo Hernandez</td>
      <td>2</td>
      <td>França</td>
    </tr>

      <th scope="row"></th>
      <td>Atacante</td>
      <td>Foden</td>
      <td>2</td>
      <td>Inglaterra</td>
    </tr>

     

  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos  </th>
      <th scope="col">Time</th>
      <tr>
      <th scope="row">1</th>
      <td>Lateral Esquerdo</td>
      <td>Acuña</td>
      <td>3</td>
      <td>Argentina</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Jahanbakhsh</td>
      <td>2</td>
      <td>Irã</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Onana</td>
      <td>2</td>
      <td>Bélgica</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Abdulelah Al-Malki</td>
      <td>2</td>
      <td>Arábia Saudita</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Jhegson Méndez</td>
      <td>2</td>
      <td>Equador</td>
    </tr>

<tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Francisco Calvo</td>
      <td>2</td>
      <td>Costa Rica</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Abdulelah Al-Amri</td>
      <td>2</td>
      <td>Arábia Saudita</td>
    </tr>

<tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Itakura</td>
      <td>2</td>
      <td>Japão</td>
    </tr>


   
   
   
    </tr>
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
     <tr>
      <th scope="row">1</th>
      <td>Goleiro</td>
      <td>Hennessey</td>
      <td>1</td>
      <td>País de Gales</td>
    </tr>                                                                                                                                                                
     <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Aboubakar</td>
      <td>1</td>
      <td>Camarões</td>
    </tr> 
    <div vw class="enabled"> 
     <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>                                                                                                                                                                          
</body>
</html>