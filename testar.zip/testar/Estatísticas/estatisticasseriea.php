<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>

<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de Gols </th>
      <th scope="col">Time</th>
   
    </tr>
    <tbody>
          <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Lautaro</td>
      <td>12</td>
      <td>Inter de Milão</td>
    </tr>
        <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Giroud</td>
      <td>7</td>
      <td>Milan</td>
    </tr>
   
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Osimhen</td>
      <td>6</td>
      <td>Napoli</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Lukaku</td>
      <td>6</td>
      <td>Roma</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>N. González</td>
      <td>6</td>
      <td>Fiorentina</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Colpani</td>
      <td>6</td>
      <td>Monza</td>
    </tr>
  
       <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Scamacca</td>
      <td>5</td>
      <td>Atalanta</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Berardi</td>
      <td>5</td>
      <td>Sassuolo</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Politano</td>
      <td>5</td>
      <td>Napoli</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Soulé</td>
      <td>5</td>
      <td>Frosinone</td>
    </tr>
          <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Gudmundsson</td>
      <td>5</td>
      <td>Genoa</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Çalhanoglu</td>
      <td>5</td>
      <td>Inter de Milão</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Bonaventura</td>
      <td>5</td>
      <td>Fiorentina</td>
    </tr>
        <tr>
      <th scope="row">5</th>
      <td>Atacante</td>
      <td>Boulaye Dia</td>
      <td>4</td>
      <td>Salernitana</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Vlahovic</td>
      <td>4</td>
      <td>Juventus</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Chiesa</td>
      <td>4</td>
      <td>Juventus</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Pulisic</td>
      <td>4</td>
      <td>Milan</td>
    </tr>
  <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Thuram</td>
      <td>4</td>
      <td>Inter de Milão</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Ederson</td>
      <td>4</td>
      <td>Atacante</td>
    </tr>
    


 
   
 
   
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
    <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Marcos Thuram</td>
      <td>5</td>
      <td>Inter de Milão</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Lateral-direito</td>
      <td>De Marco</td>
      <td>4</td>
      <td>Inter de Milão</td>
    </tr>
        <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>Felipe Anderson</td>
      <td>4</td>
      <td>Lazio</td>
    </tr>
          <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>De Roon </td>
      <td>4</td>
      <td>Atalanta</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Toljan</td>
      <td>4</td>
      <td>Sassuolo</td>
    </tr>
        <tr>
      <th scope="row">4</th>
      <td>Meia</td>
      <td>Dybala</td>
      <td>3</td>
      <td>Roma</td>
    </tr>
          <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Kostic</td>
      <td>3</td>
      <td>Juventus</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Duncan</td>
      <td>3</td>
      <td>Fiorentina</td>
    </tr>



    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Kvaratskhelia</td>
      <td>3</td>
      <td>Napoli</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Giroud</td>
      <td>3</td>
      <td>Milan</td>
    </tr>

     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Paredes</td>
      <td>3</td>
      <td>Roma</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Rafael Leão</td>
      <td>3</td>
      <td>Milan</td>
    </tr>
   

   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Politano</td>
      <td>3</td>
      <td>Napoli</td>
    </tr>

   
 
   
     
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões aamrelos </th>
      <th scope="col">Time</th>
          <tr>
      <th scope="row">1</th>
      <td>Lateral-esquerdo</td>
      <td>Theo Hernandez </td>
      <td>6</td>
      <td>Milan</td>
    </tr>
   
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Luis Alberto</td>
      <td>5</td>
      <td>Lazio</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>De Roon</td>
      <td>5</td>
      <td>Atalanta</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Rabiot</td>
      <td>5</td>
      <td>Juventus</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Paredes</td>
      <td>5</td>
      <td>Roma</td>
    </tr>
         <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Luca Ranieri</td>
      <td>5</td>
      <td>Fiorentina</td>
    </tr>
           <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Maleh</td>
      <td>5</td>
      <td>Empoli</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Kabasele</td>
      <td>5</td>
      <td>Udiinese</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Bani</td>
      <td>5</td>
      <td>Genoa</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Faraoni</td>
      <td>5</td>
      <td>Hellas Verona</td>
    </tr>
      <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>Immobille</td>
      <td>4</td>
      <td>Lazio</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Bonaventura</td>
      <td>4</td>
      <td>Fiorentina</td>
    </tr>
   
   
   
    </tr>
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
 <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Giroud</td>
      <td>1</td>
      <td>Milan</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Tomori</td>
      <td>1</td>
      <td>Milan</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Goleiro</td>
      <td>Maignan</td>
      <td>1</td>
      <td>Milan</td>
    </tr>

     <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Tóloi</td>
      <td>1</td>
      <td>Atalanta</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Natan</td>
      <td>1</td>
      <td>Napoli</td>
    </tr>
   
   
<tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Mazzitelli</td>
      <td>1</td>
      <td>Frosinone</td>
    </tr>
  
    <tr>
      <th scope="row"></th>
      <td>Goleiro</td>
      <td>Josep Martinez</td>
      <td>1</td>
      <td>Genoa</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Baschirotto</td>
      <td>1</td>
      <td>Lecce</td>
    </tr>
   
   <div vw class="enabled">
    <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

 


</body>
</html>  