<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>

<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <thead>
      <tr>
       <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de gols </th>
      <th scope="col">Time</th>
   
    </tr>
  </thead>
    <hr>

    <h2>Artilharia</h2>
  <thead>
   <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Mbappe</td>
      <td>13</td>
      <td>PSG</td>

    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Akor Adams</td>
      <td>7</td>
      <td>Montpellier</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Golovin</td>
      <td>5</td>
      <td>Monaco</td>
    </tr>
       <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Ben Yedder</td>
      <td>5</td>
      <td>Monaco</td>
    </tr>
          <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Mohamed</td>
      <td>5</td>
      <td>Nantes</td>
    </tr>
       <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Teuma</td>
      <td>4</td>
      <td>Reims</td>
    </tr>
        <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Alioui</td>
      <td>4</td>
      <td>Le Havre</td>
    </tr>
          <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Dallinga</td>
      <td>4</td>
      <td>Toulose</td>
    </tr>
   <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Aboukhlal</td>
      <td>3</td>
      <td>Toulose</td>
    </tr>
   

    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Lacazette</td>
      <td>3</td>
      <td>Lyon</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>Salah</td>
      <td>3</td>
      <td>Rennais</td>
    </tr>


   
 
     
<tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Bologun</td>
      <td>3</td>
      <td>Monaco</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Bayo</td>
      <td>3</td>
      <td>Le Havre</td>
    </tr>
   <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Ismaila Sarr</td>
      <td>3</td>
      <td>Olympique Marsseille</td>
    </tr>
      <tr>
      <th scope="row">3</th>
      <td>Lateral-direito</td>
      <td>Hakimi</td>
      <td>3</td>
      <td>PSG</td>
    </tr>
 
 
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Simon</td>
      <td>3</td>
      <td>Nantes </td>
    </tr>

</td>
    </tr>
   
   
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
   
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Lateral-esquerdo</td>
      <td>Caio Henrique</td>
      <td>4</td>
      <td>Monaco</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Lateral Direito</td>
      <td>Hakimi</td>
      <td>4</td>
      <td>PSG</td>
    </tr>
      <tr>
      <th scope="row">5</th>
      <td>Meia</td>
      <td>Sotoca</td>
      <td>4</td>
      <td>Lens</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Moses Simon</td>
      <td>4</td>
      <td>Nantes</td>
    </tr>
        <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Dembele</td>
      <td>4</td>
      <td>PSG</td>
    </tr>
        <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Zhegrova</td>
      <td>4</td>
      <td>Lille</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Josue Casimir</td>
      <td>3</td>
      <td>Le Havre</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Munetsi</td>
      <td>3</td>
      <td>Reims</td>
    </tr>
           <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Savanier</td>
      <td>3</td>
      <td>Montpellier</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Fofana</td>
      <td>3</td>
      <td>Monaco</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Aubameyang</td>
      <td>3</td>
      <td>Olimpyque Marseille</td>
    </tr>


  
 
   
   
     
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos </th>
      <th scope="col">Time</th>
        <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Medina</td>
      <td>5</td>
      <td>Lens</td>
    </tr>
      <tr>
      <th scope="row">3</th>
      <td>Zagueiro</td>
      <td>Brassier</td>
      <td>5</td>
      <td>Stade Brestois</td>
    </tr>
   
      <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Gradit</td>
      <td>5</td>
      <td>Lens</td>
    </tr>
       <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Golovin</td>
      <td>5</td>
      <td>Monaco</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Matic</td>
      <td>5</td>
      <td>Rennes</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Zakaria</td>
      <td>5</td>
      <td>Monaco</td>
    </tr>
       <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Camara</td>
      <td>4</td>
      <td>Stade Brestois</td>
    </tr>
         <tr>
      <th scope="row">2</th>
      <td>Lateral-esquerdo</td>
      <td>Renan Lodi</td>
      <td>4</td>
      <td>Olympique de Marsellie</td>
    </tr>
         <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Alidu Seidu</td>
      <td>4</td>
      <td>Clermont</td>
    </tr>
         <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Spierings</td>
      <td>4</td>
      <td>Toulouse</td>
    </tr>
         <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Yazici</td>
      <td>4</td>
      <td>Lille</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Lateral-direito</td>
      <td>Assignon</td>
      <td>4</td>
      <td>Rennes</td>
    </tr>
      <tr>
      <th scope="row">2</th>
      <td>Lateral-direito</td>
      <td>Thomas Foket</td>
      <td>4</td>
      <td>Reims</td>
    </tr>
       <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Wahi</td>
      <td>4</td>
      <td>Lens</td>
    </tr>
  
  
 
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Angel Gomes</td>
      <td>3</td>
      <td>Lille</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>S.Magassa</td>
      <td>3</td>
      <td>Monaco</td>
    </tr>
  

  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
     <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Thomasson</td>
      <td>1</td>
      <td>Lens</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Mohamed</td>
      <td>1</td>
      <td>Nantes </td>
    </tr>

     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Grandsir</td>
      <td>1</td>
      <td>La Havre</td>
    </tr>
   <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Alexsandro</td>
      <td>1</td>
      <td>Lille</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Lacazette</td>
      <td>1</td>
      <td>Lyon</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Abou Lo</td>
      <td>1</td>
      <td>Metz</td>
    </tr>
    <div vw class="enabled">

    <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
    
    </body>
</html>