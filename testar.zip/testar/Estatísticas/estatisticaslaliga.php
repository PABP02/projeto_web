<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>

<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
  <h2>Artilharia</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de Gols </th>
      <th scope="col">Time</th>
   
    </tr>
    <tbody>
   
    <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Bellingham</td>
      <td>8</td>
      <td>Real Madrid</td>

    </tr>
      <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Morata</td>
      <td>5</td>
      <td>Atletico Madrid</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Take kubo</td>
      <td>5</td>
      <td>Real Sociedad</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Lewandowski</td>
      <td>5</td>
      <td>Barcelona</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Joselu</td>
      <td>5</td>
      <td>Real Madrid</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Bryan Zaragoza</td>
      <td>5</td>
      <td>Granada</td>
    </tr>
   
     <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Abdón Prats</td>
      <td>4</td>
      <td>Mallorca</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Griezmann</td>
      <td>4</td>
      <td>Atlético de Madrid</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Luis Suárez</td>
      <td>4</td>
      <td>Almería</td>
    </tr>
     
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Sergio Arribas</td>
      <td>4</td>
      <td>Almería</td>
</tr>

     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Oyarzabal</td>
      <td>4</td>
      <td>Real Sociedad</td>
    </tr>
 
   
 
   
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Guruzeta</td>
      <td>4</td>
      <td>Athletic</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Mayoral</td>
      <td>4</td>
      <td>Gatafe</td>

   
   
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
   
    </tr>
     <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Diego rico</td>
      <td>4</td>
      <td>Getafe</td>
    </tr>
         <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Saúl</td>
      <td>4</td>
      <td>Atlético de Madrid</td>
    </tr>
          <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Alex Baena</td>
      <td>4</td>
      <td>Villarreal</td>
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>L.Ramanzani</td>
      <td>4</td>
      <td>Almeria</td>
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Sávio Moreira</td>
      <td>4</td>
      <td>Girona</td>
    </tr>
        <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>O.De Marcos</td>
      <td>3</td>
      <td>Athletic</td>
    </tr>
       <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Lewandowski</td>
      <td>3</td>
      <td>Barcelona</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Sergi Darder</td>
      <td>3</td>
      <td>Mallorca</td>
    </tr>
      <tr>
      <th scope="row">2</th>
      <td>Lateral-direito</td>
      <td>Brais Mendez</td>
      <td>3</td>
      <td>Real Sociedad</td>
    </tr>
        <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>De Paul</td>
      <td>2</td>
      <td>Atletico Madrid</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Samuel Lino</td>
      <td>2</td>
      <td>Atletico de Madrid</td>
    </tr>

     
     
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos </th>
      <th scope="col">Time</th>
        <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Guido</td>
      <td>5</td>
      <td>Real Betis</td>
    </tr>
      <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Djené</td>
      <td>5</td>
      <td>Getafe</td>
    </tr>

      <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Ruben Alcaraz</td>
      <td>5</td>
      <td>Cádiz</td>
    </tr>
        <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Iván Alejo</td>
      <td>4</td>
      <td>Cadiz</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Rodriguez</td>
      <td>4</td>
      <td>Las Palmas</td>
    </tr>
      <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Gumbau</td>
      <td>4</td>
      <td>Granada</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Dani Rodríguez</td>
      <td>4</td>
      <td>Mallorca</td>
    </tr>
   
      <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Rudiger</td>
      <td>4</td>
      <td>Real Madrid</td>
    </tr>
       <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Gonzalez</td>
      <td>4</td>
      <td>Mallorca</td>
    </tr>
           <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Diakhaby</td>
      <td>4</td>
      <td>Valencia</td>
    </tr>
   <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Le Normand</td>
      <td>4</td>
      <td>Real Sociedad</td>
    </tr>
          <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Duarte</td>
      <td>4</td>
      <td>Getafe</td>
    </tr>
       
   <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Yéremy Pino</td>
      <td>4</td>
      <td>Villareal</td>
    </tr>
       
 
       


 
    </tr>
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
     <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Chimy Àvila</td>
      <td>2</td>
      <td>Osasuna</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Oihan</td>
      <td>2</td>
      <td>Athletic</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Antonio Puertas</td>
      <td>1</td>
      <td>Granada</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>J.MatA</td>
      <td>1</td>
      <td>Getafe</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Darwin Machis</td>
      <td>1</td>
      <td>Cadiz</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>G.Escalante</td>
      <td>1</td>
      <td>Cadiz</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>De la Torre</td>
      <td>1</td>
      <td>Celta</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Alex Baena</td>
      <td>1</td>
      <td>Villareal</td>
    </tr>
    <div vw class="enabled">
     <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>