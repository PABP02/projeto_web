<!DOCTYPE html>

 

<html>

 

<head>

 

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

 

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

 

 

  <meta charset="utf-8">

 

  <meta name="viewport" content="width=device-width, initial-scale=1">

 

  <title>Papo de Torcedores</title>

 

</head>

 

 

<body style="background-color:gainsboro;">

 

  <nav class="navbar navbar-expand-lg bg-black">

 

    <div class="container-fluid">

 

      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>

 

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

 

        <span class="navbar-toggler-icon"></span>

 

      </button>

 

      <div class="collapse navbar-collapse" id="navbarSupportedContent">

 

        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">

 

 

 

          <li class="nav-item dropdown">

 

            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">

 

              Opções

 

            </button>

 

 

            <ul class="dropdown-menu">

 

               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>

 

             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>

 

 

                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

 

 

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

 

 

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>

 <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

 

            </ul>

 

          </li>

 

 

        </ul>

 

 

      </div>

 

    </div>

 

  </nav>

 

 

<table style="border: solid; border-width: 2px;"><table border="1">

 

  <table class="table">

 

    <hr>

 

   h2>Artilharia</h2>

 

  <thead>

 

    <tr>

 

      <th scope="col">Ranking</th>

 

      <th scope="col">Posição</th>

 

      <th scope="col">Jogador</th>

 

      <th scope="col">Número de Gols </th>

 

      <th scope="col">Time</th>

 

 

    </tr>

 

    <tbody>

 

 

   <tr>

 

      <th scope="row">1</th>

 

      <td>Atacante</td>

 

      <td>Harry Kane</td>

 

      <td>17</td>

 

      <td>Bayern de Munique</td>

 

    </tr>

 

 

    <tr>

 

      <th scope="row">2</th>

 

      <td>Atacante</td>

 

      <td>Guirassy</td>

 

      <td>15</td>

 

      <td>Stuttgart</td>

 

</tr>

 

   <tr>

 

      <th scope="row">3</th>

 

      <td>Atacante</td>

 

      <td>Lois Openda</td>

 

      <td>9</td>

 

      <td>RB Leipzig</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Jonas Wind</td>

 

      <td>8</td>

 

      <td>Wolfsburg</td>

 

    </tr>

 

    <tr>

 

      <th scope="row">4</th>

 

      <td>Atacante</td>

 

      <td>Boniface</td>

 

      <td>7</td>

 

      <td>B.Leverkusen</td>

 

    </tr>

 

      <tr>

 

      <th scope="row">5</th>

 

      <td>Atacante</td>

 

      <td>Maximilian Beier</td>

 

      <td>6</td>

 

      <td>Hoffenheim</td>

 

    </tr>

 

    <tr>

 

      <th scope="row">6</th>

 

      <td>Atacante</td>

 

      <td>Ermedin Demirovic</td>

 

      <td>5</td>

 

      <td>Augsburg</td>

 

    </tr>

 

     <tr>

 

      <th scope="row"></th>

 

      <td>atacante</td>

 

      <td>Kevin Behrens</td>

 

      <td>4</td>

 

      <td>Union Berlin</td>

 

    </tr>

 

 

     <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Eren Dinkci</td>

 

      <td>4</td>

 

      <td>1. FC Heidenheim 1846</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Robin Gosens</td>

 

      <td>4</td>

 

      <td>Union Berlin</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td>Loïs Openda</td>

 

      <td>4</td>

 

      <td>RB Leipzig</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Andrej Kramaric</td>

 

      <td>4</td>

 

      <td>Hoffenheim</td>

 

    </tr>  

 

    <tr>

 

      <th scope="row">7</th>

 

      <td>Atacante</td>

 

      <td>Xavi Simons</td>

 

      <td>3</td>

 

      <td>RB Leipzig</td>

 

    </tr>  

 

     <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Marvin Mehlem</td>

 

      <td>3</td>

 

      <td> Darmstadt 98</td>

 

    </tr>

 

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Donyell Malen</td>

 

      <td>3</td>

 

      <td>Borussia Dortmund</td>

 

    </tr>

 

  </tbody>

 

 

  <table style="border: solid; border-width: 2px;"><table border="1">

 

  <table class="table">

 

    <hr>

 

    <h2>Assistentes</h2>

 

  <thead>

 

    <tr>

 

      <th scope="col">Ranking</th>

 

      <th scope="col">Posição</th>

 

      <th scope="col">Jogador</th>

 

      <th scope="col">Número de assistências </th>

 

      <th scope="col">Time</th>

 

 

    </tr>

 

    <tr>

 

      <th scope="row">1</th>

 

      <td>Atacante</td>

 

      <td>Xavi Simons</td>
 

      <td>7</td>

 

      <td>RB Leipzig</td>

 

    </tr>

 

    <tr>

 

      <th scope="row">2</th>

 

      <td>Atacante</td>

 

      <td>Leroy Sané</td>

 

      <td>6</td>

 

      <td>Bayer de Munique</td>

 

    </tr>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td>Florian Wirtz</td>

 

      <td>5</td>

 

      <td>B Leverkusen</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Meia Direita</td>

 

      <td>Vincenzo Grifo</td>

 

      <td>5</td>

 

      <td>Freiburg</td>

 

    </tr>

 

      <tr>

 

      <th scope="row">3</th>

 

      <td>Atacante</td>

 

      <td>Frinpong</td>

 

      <td>5</td>

 

      <td>Bayer leverkusen</td>

 

        <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Chris Funhrich</td>

 

      <td>5</td>

 

      <td>Stuttgart</td>

 

    </tr>

 

      <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Hofmann</td>

 

      <td>5</td>

 

      <td>B leverkusen</td>

 

    </tr>

 

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Lateral Esquerdo</td>

 

      <td>  Alphonso Davies</td>

 

      <td>3</td>

 

      <td>Bayern de Munique</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Volante</td>

 

      <td>Joshua Kimmich</td>

 

      <td>3</td>

 

      <td>Bayern de Munique</td>

 

    </tr>

 

       <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Vincenzo Grifo</td>

 

      <td>3</td>

 

      <td>Freiburg</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td>  Grischa Prömel</td>

 

      <td>3</td>

 

      <td>Hoffenheim</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td> Jeremie Frimpong</td>

 

      <td>3</td>

 

      <td>  Bayer Leverkusen</td>

 

    </tr>

 

     <tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td>  Florian Wirtz</td>

 

      <td>3</td>

 

      <td> Bayer Leverkusen</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>  Pascal Stenzel</td>

 

      <td>3</td>

 

      <td>VfB Stuttgart</td>

 

    </tr>

 

 

     <tr>

 

      <th scope="row"></th>

 

      <td>Lateral Esquerdo</td>

 

      <td>Marvin Ducksch</td>

 

      <td>3</td>

 

      <td>Werder Bremen</td>

 

    </tr>

 

 

      <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Aïssa Laïdouni</td>

 

      <td>3</td>

 

      <td>Union Berlin</td>

 

    </tr>

 

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Jan-Niklas Beste</td>

 

      <td>3</td>

 

      <td>1. FC Heidenheim 1846</td>

 

    </tr>

 

 

 

  </thead>

 

  <table style="border: solid; border-width: 2px;"><table border="1">

 

  <table class="table">

 

    <h2>Cartões amarelos</h2>

 

     <thead>

 

    <tr>

 

      <th scope="col">Ranking</th>

 

      <th scope="col">Posição</th>

 

      <th scope="col">Jogador</th>

 

      <th scope="col">Número de cartões amarelos </th>

 

      <th scope="col">Time</th>

 

  <tr>

 

      <th scope="row">1</th>

 

      <td>Meia</td>

 

      <td>Dominik Kohr</td>

 

      <td>5</td>

 

      <td>Mainz 05</td>

 

    </tr>

 

    <tr>

 

      <th scope="row">2</th>

 

      <td>Atacante</td>

 

      <td>Van den Berg</td>

 

      <td>5</td>

 

      <td>Mainz 05</td>

 

    </tr>

 

     <tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td>Klarer</td>

 

      <td>5</td>

 

      <td>Darmstadt 98</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Lateral Esquerdo</td>

 

      <td>Marmoush</td>

 

      <td>4</td>

 

      <td>Frankfurt</td>

 

    </tr>

 

     <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>Marvin Mehlem</td>

 

      <td>3</td>

 

      <td>Werder Bremen</td>

 

    </tr>

 

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>Jonattan Tah</td>

 

      <td>3</td>

 

      <td>FC Augsburg</td>

 

    </tr>

 

       <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>Kevin Stoger</td>

 

      <td>3</td>

 

      <td>Bochum</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>Robin Koko</td>

 

      <td>3</td>

 

      <td>Werder Bremen</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>E.Palacio</td>

 

      <td>3</td>

 

      <td>Bayer Leverkusen</td>

 

    </tr>

 

    <tr>

 

      <th scope="row">3</th>

 

      <td>Lateral-direito</td>

 

      <td>Henrichs</td>

 

      <td>2</td>

 

      <td>RB Leipzig</td>

 

    </tr>

 

     <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>Kabak</td>

 

      <td>2</td>

 

      <td>Hoffenheim</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>Lukebakio</td>

 

      <td>2</td>

 

      <td>Hertha</td>

 

    </tr>

 

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td>N. Höfler</td>

 

      <td>2</td>

 

      <td>SC Freiburg</td>

 

    </tr>

 

  </thead>

 

  <table style="border: solid; border-width: 2px;"><table border="1">

 

  <table class="table">

 

    <h2>Cartões vermelhos</h2>

 

 

  <thead>

 

 

    <tr>

 

      <th scope="col">Ranking</th>

 

      <th scope="col">Posição</th>

 

      <th scope="col">Jogador</th>

 

      <th scope="col">Número de cartões vermelhos </th>

 

      <th scope="col">Time</th>

 

 

     <tr>

 

      <th scope="row">1</th>

 

      <td>Zagueiro</td>

 

      <td>Matej Maglica</td>

 

      <td>2</td>

 

      <td>Darmstardy</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>R. Carstensen</td>

 

      <td>1</td>

 

      <td>FC Köln</td>

 

    </tr>

 

 

<tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td>Mario Götze</td>

 

      <td>1</td>

 

      <td>Frankfurt</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>Ramy Bensebaini</td>

 

      <td>1</td>

 

      <td>Borussia Dortmund</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>zagueiro</td>

 

      <td>Brenden Aaronson</td>

 

      <td>1</td>

 

      <td>União Berlin</td>

 

    </tr>

 

     <tr>

 

      <th scope="row"></th>

 

      <td>Atacante</td>

 

      <td>S. Guirassy</td>

 

      <td>1</td>

 

      <td>Stuttgart</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Zagueiro</td>

 

      <td>Kevin Volland</td>

 

      <td>1</td>

 

      <td>União Berlin</td>

 

    </tr>

 

    <tr>

 

      <th scope="row"></th>

 

      <td>Meia</td>

 

      <td>Ansgar Knauff</td>

 

      <td>1</td>

 

      <td>Frankfurt</td>

 

    </tr>
 

 

 
<div vw class="enabled">
  <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

</body>

 

</html>