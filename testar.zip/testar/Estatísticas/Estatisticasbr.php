<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
    <thead>
            <th scope="row">1</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Paulinho</td>
  
   
  
        <td>20</td>
  
   
  
        <td>Atlético-MG</td>
  
   
  
      </tr>
      <tr>
  
   
  
        <th scope="row">2</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Tiquinho Soares</td>
  
   
  
        <td>17</td>
  
   
  
        <td>Botafogo</td>
  
   
  
   
  
      </tr>
  
        <th scope="row">3</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Suárez</td>
  
   
  
        <td>17</td>
  
   
  
        <td>Gremio</td>
  
   
  
      </tr>
  
   
  
   
  
      <tr>
  
   
  
        <th scope="row">4</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Hulk</td>
  
   
  
        <td>15</td>
  
   
  
        <td>Atl.Mineiro</td>
  
   
  
      </tr>
  
       <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Marcos Leonardo</td>
  
   
  
        <td>13</td>
  
   
  
        <td>Santos</td>
  
   
  
      </tr>
        <th scope="row">5</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Pedro</td>
  
   
  
        <td>13</td>
  
   
  
        <td>Flamengo</td>
  
   
  
      </tr>
   <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Robson</td>
  
   
  
        <td>12</td>
  
   
  
        <td>Coritiba</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row">6</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Deyverson</td>
  
   
  
        <td>12</td>
  
   
  
        <td>Cuiaba</td>
  
   
  
      </tr>
   <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Mastriani</td>
  
   
  
        <td>11</td>
  
   
  
        <td>América-MG</td>
  
   
  
      </tr>
       <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Vitor Roque</td>
  
   
  
        <td>11</td>
  
   
  
        <td>Atletico . Pr</td>
  
   
  
      </tr>
  
  
   
  
   
  
   
  
  
  
   
  
   
  
  
  
   
  
     
  
   
  
       <tr>
  
   
  
        <th scope="row">7</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Eduardo Sacha</td>
  
   
  
        <td>10</td>
  
   
  
        <td>Bragantino</td>
  
   
  
      </tr>
  
   
  
     
  
    </tbody>
  
   
  
   
  
    <table style="border: solid; border-width: 2px;"><table border="1">
  
   
  
    <table class="table">
  
   
  
      <hr>
  
   
  
      <h2>Assistentes</h2>
  
   
  
    <thead>
  
   
  
      <tr>
  
   
  
        <th scope="col">Ranking</th>
  
   
  
        <th scope="col">Posição</th>
  
   
  
        <th scope="col">Jogador</th>
  
   
  
        <th scope="col">Número de assistências </th>
  
   
  
        <th scope="col">Time</th>
  
   
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row">1</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Suárez</td>
  
   
  
        <td>11</td>
  
   
  
        <td>Gremio</td>
  
   
  
      </tr>
     <th scope="row">2</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Hulk</td>
  
   
  
        <td>11</td>
  
   
  
        <td>Atlético-MG</td>
  
   
  
      </tr>
   
  
      <tr>
  
   
  
        <th scope="row">3</th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Gerson</td>
  
   
  
        <td>8</td>
  
   
  
        <td>Flamengo</td>
  
   
  
      </tr>
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Pavon</td>
  
   
  
        <td>8</td>
  
   
  
        <td>Atl.Mineiro</td>
  
   
  
      </tr>
  <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Ganso</td>
  
   
  
        <td>7</td>
  
   
  
        <td>Fluminense</td>
  
   
  
      </tr>
  
  
   
  
      <tr>
  
   
  
        <th scope="row">3</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Arias</td>
  
   
  
        <td>7</td>
  
   
  
        <td>Fluminense</td>
  
   
  
      </tr>
          <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Veiga</td>
  
   
  
        <td>7</td>
  
   
  
        <td>Palmeiras</td>
  
   
  
      </tr>
  
  
   
  
       <tr>
  
   
  
     
  
   
  
   
  
   
  
      <tr>
  
   
  
        <th scope="row">4</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Soteldo</td>
  
   
  
        <td>6</td>
  
   
  
        <td>Santos</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Cauly</td>
  
   
  
        <td>6</td>
  
   
  
        <td>Bahia</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Eduardo</td>
  
   
  
        <td>6</td>
  
   
  
        <td>Botafogo</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Lateral - Direito</td>
  
   
  
        <td>Mayke</td>
  
   
  
        <td>6</td>
  
   
  
        <td>Palmeiras</td>
  
   
  
      </tr>
  
   
  <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Villasanti</td>
  
   
  
        <td>5</td>
  
   
  
        <td>Gremio</td>
  
   
  
      </tr>
  
   
  <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Cristaldo</td>
  
   
  
        <td>5</td>
  
   
  
        <td>Gremio</td>
  
   
  
      </tr>
  <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Alisson</td>
  
   
  
        <td>5</td>
  
   
  
        <td>São Paulo</td>
  
   
  
      </tr>
   
  
  
   
  
   
  
  
   
  
   
  
    </thead>
  
   
  
    <table style="border: solid; border-width: 2px;"><table border="1">
  
   
  
    <table class="table">
  
   
  
      <h2>Cartões amarelos</h2>
  
   
  
       <thead>
  
   
  
      <tr>
  
   
  
        <th scope="col">Ranking</th>
  
   
  
        <th scope="col">Posição</th>
  
   
  
        <th scope="col">Jogador</th>
  
   
  
        <th scope="col">Número de cartões amarelos </th>
  
   
  
        <th scope="col">Time</th>
  
   
  
   
  
     <tr>
  
   
  
        <th scope="row">1</th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Kannemann </td>
  
   
  
        <td>15</td>
  
   
  
        <td>Gremio</td>
  
   
  
      </tr>
  
   
  
   
  
      <tr>
  
   
  
        <th scope="row">2</th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Robson</td>
  
   
  
        <td>13</td>
  
   
  
        <td>Coritiba</td>
  
   
  
      </tr>
      <tr>
  
   
  
        <th scope="row">3</th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Mercado</td>
  
   
  
        <td>12</td>
  
   
  
        <td>Internacional</td>
  
   
  
      </tr>
  
  
   
        <th scope="row">4</th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Rodrigo F. </td>
  
   
  
        <td>11</td>
  
   
  
        <td>Santos</td>
  
   
  
      </tr>
   <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Brítez</td>
  
   
  
        <td>10</td>
  
   
  
        <td>Fortaleza</td>
  
   
  
      </tr>
   <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Lateral-direito</td>
  
   
  
        <td>Fagner</td>
  
   
  
        <td>10</td>
  
   
  
        <td>Corinthians</td>
  
   
  
      </tr>
   
  
      <tr>
  
   
  
   
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>A. Canobbio</td>
  
   
  
        <td>10</td>
  
   
  
        <td>Athletico</td>
  
   
  
      </tr>
  
   
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>André</td>
  
   
  
        <td>10</td>
  
   
  
        <td>Fluminense</td>
  
   
  
      </tr>
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Zé Rafael</td>
  
   
  
        <td>10</td>
  
   
  
        <td>Palmeiras</td>
  
   
  
      </tr>
  
   
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Mauricio Lemos</td>
  
   
  
        <td>10</td>
  
   
  
        <td>Atlético-MG</td>
  
   
  
      </tr>
  
  
      <tr>
  
   
  
        <th scope="row">3</th>
  
   
  
        <td>Lateral-esquerdo</td>
  
   
  
        <td>Juninho Capixaba</td>
  
   
  
        <td>9</td>
  
   
  
        <td>RB Bragantino</td>
  
   
  
      </tr>
  
   
  
   
  
     
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Lateral-esquerdo</td>
  
   
  
        <td>Reinaldo</td>
  
   
  
        <td>9</td>
  
   
  
        <td>Gremio</td>
  
   
  
      </tr>
  
   
  
   
  
   
  
   
  
     
  
   
  
   
  
  
   
  
   
  
     
  
   
  
   
  
    </thead>
  
   
  
    <table style="border: solid; border-width: 2px;"><table border="1">
  
   
  
    <table class="table">
  
   
  
      <h2>Cartões vermelhos</h2>
  
   
  
   
  
    <thead>
  
   
  
   
  
      <tr>
  
   
  
        <th scope="col">Ranking</th>
  
   
  
        <th scope="col">Posição</th>
  
   
  
        <th scope="col">Jogador</th>
  
   
  
        <th scope="col">Número de cartões vermelhos </th>
  
   
  
        <th scope="col">Time</th>
  
   
  
   
  
       <tr>
  
   
  
        <th scope="row">1</th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Lucas Halter</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Goiás</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Kanu</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Bahia</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Soteldo</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Santos</td>
  
   
  
      </tr>
  
   
  
   
  
  <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Lateral-esquerdo</td>
  
   
  
        <td>Reinaldo</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Gremio</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Lateral-direito</td>
  
   
  
        <td>Maguinho</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Goiás</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Oliveira</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Cruzeiro</td>
  
   
  
      </tr>
        <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Nino</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Fluminense</td>
  
   
  
      </tr>
  
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Hulk</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Atlético-MG</td>
  
   
  
      </tr>
  
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Gabriel</td>
  
   
  
        <td>2</td>
  
   
  
        <td>Flamengo</td>
  
   
  
      </tr>
  
  
  
       <tr>
  
   
  
        <th scope="row">2</th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Maycon</td>
  
   
  
        <td>1</td>
  
   
  
        <td>Corinthians</td>
  
   
  
      </tr>
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Iago Maidana</td>
  
   
  
        <td>1</td>
  
   
  
        <td>América-MG</td>
  
   
  
      </tr>
  
   
  
   
  
      <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Pablo Maia</td>
  
   
  
        <td>1</td>
  
   
  
        <td>São Paulo</td>
  
   
  
      </tr>
  
   
  
  <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Iago Maidana</td>
  
   
  
        <td>1</td>
  
   
  
        <td>América-MG</td>
  
   
  
      </tr>
  
   
  
       <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Atacante</td>
  
   
  
        <td>Felipe Azevedo</td>
  
   
  
        <td>1</td>
  
   
  
        <td>América-MG</td>
  
   
  
      </tr>
  
   
  
       <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Zagueiro</td>
  
   
  
        <td>Britez</td>
  
   
  
        <td>1</td>
  
   
  
        <td>Fortaleza</td>
  
   
  
      </tr>
  
   
  
  <tr>
  
   
  
        <th scope="row"></th>
  
   
  
        <td>Meia</td>
  
   
  
        <td>Rodrigo Nestor</td>
  
   
  
        <td>1</td>
  
   
  
        <td>São Paulo</td>
      </tr>
  
    
    <div vw class="enabled">
 <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

</body>
</html>