<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Papo de Torcedores</title>
</head>

<body style="background-color: white;">
    <nav class="navbar navbar-expand-lg bg-black">
        <div class="container-fluid">
            <a class="navbar-brand text-"><img src="../teste.PNG" width="250px"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">
                    <li class="nav-item dropdown">
                        <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Opções
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
                            <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a>
                            </li>
                            <li><a class="dropdown-item text-" href="#">Estatísticas de nacionais</a></li>
                            <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
                            <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
                            <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
  </nav>
 <style>
  
    body {
      background-color: #f5f5f5;
      font-family: Arial, sans-serif;
    }

    .navbar {
      background-color: #343a40; 
    }

    .navbar-brand img {
      width: 250px;
      height: auto;
    }

    .nav-link {
      color: #ffffff; 
    }



    .container {
      padding: 20px;
    }

    hr {
      background-color: #343a40;
    }

    .container img {
      max-width: 100%;
      height: auto;
    }

    .container a {
      display: block;
      margin: 20px 0;
    }
  </style>

  <div class="container">
<img src="https://logospng.org/wp-content/uploads/brasileirao-serie-a.png" width="200px" height="200px" alt="Brasileirão">
      <a class="btn btn-primary" href="Estatisticasbr.php">Estatísticas Brasileirão</a>
    <hr>
     <img src="https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/Premier_League_Logo.svg/1200px-Premier_League_Logo.svg.png" width="180px" height="100px" alt="Premier League">
      <a class="btn btn-primary" href="estatisticaspl.php">Estatísticas Premier League</a>
    <hr>
      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Serie_A_logo_2022.svg/200px-Serie_A_logo_2022.svg.png" width="180px" height="200px" alt="Serie A Tim">
      <a class="btn btn-primary" href="estatisticaseriea.php">Estatísticas Serie A Tim</a>
    <hr>
 
      <img src="https://a2.espncdn.com/combiner/i?img=%2Fi%2Fleaguelogos%2Fsoccer%2F500%2F15.png" width="180px" height="100px" alt="La Liga">
      <a class="btn btn-primary" href="estatisticaslaliga.php">Estatísticas La Liga</a>
    <hr>
        <img src="https://upload.wikimedia.org/wikipedia/pt/f/f9/Bundesliga_logo_%282017%29.png" width="180px" height="100px" style = "margin: center"alt="Bundesliga">
      <a class="btn btn-primary" href="estatisticasbunds.php">Estatísticas Bundesliga</a>
          <hr>
        <img src="https://upload.wikimedia.org/wikipedia/pt/f/f4/Campeonato_Brasileiro_S%C3%A9rie_B_logo.png" width="180px" height="100px" alt="Serie B">
      <a class="btn btn-primary" href="estatisticasserieb.php">Estatísticas Serie B</a>
          <hr>
         <img src="https://upload.wikimedia.org/wikipedia/commons/4/49/Ligue1_Uber_Eats_logo.png" width="180px" height="200px" alt="Ligue One">
      <a class="btn btn-primary" href="estatisticasligue1.php">Estatísticas Ligue One</a>
  </div>
  <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

</body>

</html>
