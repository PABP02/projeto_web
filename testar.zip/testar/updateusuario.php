<?php 
include "PDO.php";

$pdo = new usePDO();
$pdo->createDB();
$pdo->createTableuser();
$updateuser = new usePDO();
$updatePeople = new usePDO();
$updateState = new usePDO();
$updateCity = new usePDO();
$updateAddress = new usePDO();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['ID'], $_POST['nome'], $_POST['email'], $_POST['senha'])) {
        $updateuser->updateuser($_POST['ID'], $_POST['nome'], $_POST['email'], $_POST['senha']); 
    }

    if (isset($_POST['ID'], $_POST['cpf'], $_POST['ddn'])) {
        $updatePeople->updatePeople($_POST['ID'], $_POST['cpf'], $_POST['ddn']); 
    }

    if (isset($_POST['ID'], $_POST['estado'])) {
        $updateState->updateState($_POST['ID'], $_POST['estado']); 
    }

    if (isset($_POST['ID'], $_POST['cidade'])) {
        $updateCity->updateCity($_POST['ID'], $_POST['cidade']); 
    }

    if (isset($_POST['ID'], $_POST['cep'], $_POST['endereco'])) {
        $updateAddress->updateAddress($_POST['ID'], $_POST['cep'], $_POST['endereco']); 
    }

    header("location: cadastro.php");
} else {
    echo "Método inválido.";
}
?>
