<?php
include "PDO.php";

$pdo = new usePDO();
$pdo->createDB();
$pdo->createTableTimess();

if(isset($_GET['id'])) {
  $timeID = $_GET['id'];
  $times = $pdo->selectTimess($timeID);
}
else{
    //erro
}


?>
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Papo de Torcedores</title>
</head>

<body>
       
    <div class="accordion mt-4" id="accordionTeams">
       
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading<?php echo $index; ?>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse" aria-expanded="false" aria-controls="collapse">
                        <?php echo $times['clube']; ?>
                    </button>
                </h2>
                <div id="collapse" class="accordion-collapse collapse" aria-labelledby="heading" data-bs-parent="#accordionTeams">
                    <div class="accordion-body">
                        <p>História: <?php echo str_replace(".", ",", $times['historia']); ?></p>
                   
                        <p>Ídolos: <?php echo $times['idolo']; ?></p>


                    </div>
                </div>
            </div>
    </div>

<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>

</html>
