<?php 
include "PDO.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pdo = new usePDO();
    $userId = $_SESSION['ID']; // Adicione esta linha para obter o ID do usuário logado
    $insertTimecoracao = $pdo->insertTimescoracao($_POST['timecoracao'], $userId); // Corrija a chamada da função
    $_SESSION['timecoracao'] = $_POST['timecoracao'];
    // echo $_SESSION['timecoracao'];
    header("location:teste.php");
}

?>


<!-- if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['timecoracao'])) {
    $_SESSION['timecoracao'] = $_POST['timecoracao'];

     $insertTimecoracao = $pdo->insertTimescoracao( $_POST['timecoracao'], $_SESSION['ID']);


    header('location:Copa do mundo.php');
    exit;
} -->