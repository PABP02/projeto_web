<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>>O Vasco foi fundado como um clube de remo em 1898, por um grupo de 63 rapazes, imigrantes portugueses e luso-descendentes, reunidos no bairro da Saúde. O nome escolhido foi Club de Regatas Vasco da Gama, pois naquele ano eram comemorados os 400 anos da viagem do célebre almirante à Índia. Apesar de ter sido fundado como um "clube de regatas", consagrando-se no remo como um dos maiores campeões do continente, o Vasco da Gama ainda abrange outras modalidades como atletismo, vôlei de praia, basquete, futebol de areia, dentre outros, tendo como esporte mais tradicional o futebol. As cores do Vasco guardam forte significação: o preto remete aos mares desconhecidos do Oriente, desbravados por Vasco da Gama, enquanto o branco da faixa diagonal refere-se à rota descoberta pelo almirante. Além disso, estas são cores que se encaixam na ideia de uma comunhão de etnias (já que foi o primeiro clube do Brasil a lutar contra preconceitos raciais e sociais).</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>
Torneio Octogonal Rivadávia Corrêa Meyer	1	1953
		<hr>
I Torneio de Paris	1	1957
<hr>
	Campeonato Sul-Americano de Campeões	1	1948
	<hr>
	Copa Libertadores da América	1	1998
	<hr>
	Copa Mercosul	1	2000
	<hr>
	Campeonato Brasileiro	4	1974, 1989, 1997 e 2000
	<hr>
	Copa do Brasil	1	2011
	<hr>
	Campeonato Brasileiro - Série B	1	2009
	<hr>
	Torneio Rio-São Paulo	3	1958, 1966 e 1999
	<hr>
	Torneio João Havelange	1	1993
	<hr>
	Taça dos Campeões Rio-São Paulo	1	1936
	<hr>
	Campeonato Carioca	24	1923, 1924, 1929, 1934, 1936, 1945, 1947, , 1950, 1952, 1956, 1958, 1970, 1977, 1982OO, 1987, 1988, , 1993, 1994, 1998, 2003, 2015 e 2016
	<hr>
	Campeonato Carioca - Série B	1	1922
	<hr>
	Copa Rio Estadual	2	1992 e 1993
<hr>

Taça Guanabara Independente	1	1965

<hr>
Torneio Início	10	1926, 1929, 1930, 1931, 1932, 1942, 1944, 1945, 1948 e 1958

<hr>
Taça Eficiência	11	1943, 1945, 1946, 1947, 1949, 1950, 1955, 1958, 1973, 1980 e 1982
<hr>
Taça Disciplina	2	1943 e 1964
<hr>
	Campeonatos Cariocas de Aspirantes, Reservas ou Amadores	30	1920, 19221, 19222, 19223, 1924, 1926, 1928, 1930, 19341, 19342, 1936, 1937, 19411, 19412, 1942, 1943, 1946, 1947, 19481, 19482, 1949, 1950, 1951, 1954, 1955, 1960, 1961, 1964, 1966 e 1967
<hr>
	Taça Guanabara	12	1976, 1977, 1986, 1987, 1990C, 1992, 1994, 1998, 2000, 2003, 2016 e 2019
	<hr>
Taça Rio	11	1984, 1988, 1992, 1993, 1998, 1999, 2001, 2003, 2004, 2017 e 2021
<hr>
	Turnos disputados com outros nomes	9	1972, 1973, 1974, 1975, 1977, 1980, 1981, 1988 e 1997
<hr>
	Torneio Municipal	4	1944, 1945, 1946 e 1947
	<hr>
	Torneio Relâmpago	2	1944 e 1946
	<hr>
	Torneio Gérson dos Santos Coelho1	1948
	<hr>
	Taça Cidade do Rio de Janeiro	1	1959
	<hr>
	Torneio Extra	2	1973 e 1990
	<hr>
	Campeonato da Capital	1	1992
	<hr>
	Taça Cidade de Cabo Frio	1	1975
</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>Ademir, Barbosa, Bellini, Danilo, Edmundo, Juninho Pernambucano, Romário e Roberto Dinamite.</p>
      </div>
    </div>
  </div>
</div>











<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>







</body>
</html>

