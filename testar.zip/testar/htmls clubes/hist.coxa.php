<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>O Coritiba Foot Ball Club é da cidade de Curitiba, no Paraná, e foi fundado por alemães. É o mais antigo time do Estado e um dos principais, sendo chamado pelos torcedores de Coxa. Foi fundado em 12 de outubro de 1909. Diversos jovens se reuniam no Clube Ginástico Teuto-Brasileiro e foram apresentados ao esporte. Encantados, passaram a promover partidas entre eles no campo do Quartel da Força Pública. Em pouco tempo, todos estavam completamente apaixonados e decidiram fundar um clube para a prática do futebol, primeiramente chamado de Coritibano Football Club. A fundação ocorreu no antigo Theatro Hauer. Seu maior rival é o Athletico.</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>
	Fita Azul Internacional	1	

	Campeonato Brasileiro	
1	1985
<hr>
	Campeonato Brasileiro - Série B	
2	2007 e 2010
<hr>
	Campeonato Paranaense	
39	1916, 1927, 1931, 1933, 1935, 1939, 1941, 1942, 1946, 1947, 1951, 1952, 1954, 1956, 1957, 1959, 1960, 1968, 1969, 1971, 1972, 1973, 1974, 1975, 1976, 1978, 1979, 1986, 1989, 1999, 2003, 2004, 2008, 2010, 2011, 2012, 2013, 2017 e 2022
<hr>
	Liga APSA	
1	1916
<hr>
	1º Turno do Campeonato Paranaense	
10	1942, 1943, 1954, 1956, 1957, 1976, 1983, 1984, 2011 e 2013
<hr>
	2º Turno do Campeonato Paranaense	
6	1945, 1975, 1976, 1986, 2011 e 2012
<hr>
	Taça Dionísio Filho (turno)	
1	2018
<hr>
	Campeonato Paranaense - Zona Sul	
3	1959, 1960 e 1962
<hr>
	Torneio Início do Paraná	
10	1920, 1921, 1930, 1932, 1939, 1941, 1942, 1951, 1952 e 1957
</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>Alex
Fedato
Hermes
Hidalgo
Keirrison
Kruger
Nilo
Oberdan
Pachequinho
Rafael Camarota</p>
      </div>
    </div>
  </div>
</div>


<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>


</body>
</html>




