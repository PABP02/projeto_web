<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p>Fortaleza Esporte Clube é um clube poliesportivo que está sediado na cidade de Fortaleza, no Nordeste do Brasil. Foi fundado em 18 de outubro de 1918, por Alcides Santos, um dos maiores esportistas cearenses, que se apaixonou pelo futebol durante o período em que estudou no College Stella, na Suíça. Dono da maior torcida do estado do Ceará, 2ª maior do Nordeste e 13ª maior do Brasil,o clube leva os maiores públicos para os estádios cearenses desde os anos 70, comprovando o crescimento de sua torcida após as grandes campanhas de vice-campeão brasileiro em 1960 e 1968, da conquista do Norte–Nordeste em 1970 e de consideráveis títulos estaduais. Na Série A do Campeonato Brasileiro de 2005, teve a segunda maior média de público dentre todos os 22 clubes. Em 2014, foi o clube detentor do maior público do país numa só partida. O grande público acabou sendo notícia em sites do mundo inteiro, como o Japão, dando grande ênfase a sua torcida e a festa que é realizada durante os jogos. O Fortaleza também tem a maior renda da história da Arena Castelão. Seu maior rival é o Ceará.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
>Campeonato Brasileiro - Série B  1 2018
<hr>
  Torneio Norte–Nordeste  1 1970
<hr>

 

 

  Copa do Nordeste  2 2019 e 2022

<hr>

 

  Copa Cidade de Natal  1 1946
<hr>
Ceará Paraíba Rio Grande do Norte Torneio Octávio Pinto Guimarães 1 1986
<hr>
  Campeonato Cearense de Futebol  46  1920, 1921, 1923, 1924, 1926, 1927, 1928, 1933, 1934, 1937, 1938, 1946, 1947, 1949, 1953, 1954, 1959, 1960, 1964, 1965, 1967, 1969, 1973, 1974, 1982, 1983, 1985, 1987, 1991, 1992, 2000, 2001, 2003, 2004, 2005, 2007, 2008, 2009, 2010, 2015, 2016, 2019, 2020, 2021, 2022, 2023.
<hr>
Torneio Início do Ceará 12  1925, 1927, 1928, 1933, 1935, 1948, 1960, 1961, 1962, 1964, 1965 e 1977
<hr>
  Taça dos Campeões Cearenses 2 2016, 2017
</p>

 

 

</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Croinha, Júlio Bala, Rinaldo, Mozarzinho, Pedrinho Simões, Maizena, Mirandinha, Bosco, Salvino, Sandro Gaúcho, Dude, Ronaldo Angelim, Clodoaldo, Daniel Frasson.</p>
</div>
</div>
</div>
</div>

 

 

 

 

 <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

 

 

 

 

</body>
</html>