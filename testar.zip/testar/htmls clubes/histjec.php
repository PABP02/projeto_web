<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>O Juventude nasceu em função de uma dissidência interna ocorrida no Clube Juvenil entre os membros casados e os solteiros, que se sentiam discriminados. Disso resultou a fundação de um clube rival, o Recreio da Juventude, em 28 de dezembro de 1912, que inicialmente só admitiu solteiros. Desde o início muitos dos associados do Juventude, por influência do amador inglês John Tibbitz, pensavam em criar um clube futebolístico, que se concretizou como o E. C. Juventude, fundado no dia 29 de junho de 1913 com o nome de Sport Club Foot Ball Juventude, que permaneceria até 1915 vinculado ao Recreio. Segundo o relato de Francisco Michielin, a fundação movimentou a cidade. Tem como principais rivais os grandes do estadp, Gremio e Internacional.</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>
<p>Nacionais
Copa do Brasil: 1: 1999.
<hr>
Campeonato Brasileiro Série B: 1: 1994.
<hr>


Rio Grande do Sul Campeonato Gaúcho: 1: 1998.
<hr>
Rio Grande do Sul Campeonato do Interior: 16 vezes — 1964, 1965, 1966, 1986, 1991, 1993, 1994, 1995, 1996, 1998, 2001, 2006, 2007, 2008, 2011 e 2021
<hr>
Rio Grande do Sul Copa FGF: 2: 2011 , 2012.
<hr>
Rio Grande do Sul Copa Governador do Estado: 2 vezes — 1975 e 1976.
<hr>
Rio Grande do Sul Campeonato da Região Serrana: 1 vez — 2014
<hr>
Rio Grande do Sul Seletiva do Torneio Centro-Sul: 1 vez — 1968
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>Principal ídolo: Alex Telles.</p>
      </div>
    </div>
  </div>
</div>












<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>






</body>
</html>


	



