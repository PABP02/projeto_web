<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p>No começo de sua história, o Cuiabá Esporte Clube era um centro de treinamentos com enfoque nas categorias de base chamado "Escolinha do Gaúcho", uma referência ao ex-jogador e fundador Luís Carlos Tóffoli, o Gaúcho. Até o fim de 2002, o time competiu apenas em campeonatos amadores de Mato Grosso. No ano seguinte, em 2003, houve a alteração do nome e desde então o Cuiabá Esporte Clube tornou-se uma equipe profissional, fazendo a sua estreia no Campeonato Mato-Grossense daquele ano. Nos primeiros anos competindo na elite estadual, o Cuiabá foi bicampeão mato-grossense, em 2003 e 2004. Já a nível nacional, estreou na Série C do Campeonato Brasileiro com vitória por 4x3 diante do Jacira-MT e liderou o Grupo 13 que contava também com o Chapadão-MS e correspondia a Primeira fase da competição. Pela segunda fase, diante do Palmas-TO, após dois jogo terminados em 1x3 a eliminação veio nos pênaltis com o placar de 4x2 para os visitantes[5]. Em 2004 a história se repetiu, com a classificação na fase de grupos e a eliminação na segunda fase, desta vez diante do Gama-DF. Pela Copa do Brasil estreou em 2004 diante do Goiás-GO.

 

Entre os anos de 2007 e 2008 o time passou por um período de licenciamento, sendo o fator financeiro uma das principais razões para isso acontecer.Nesse mesmo período a sociedade entre Gaúcho e os irmãos Neponuceno, os outros dois sócios do Cuiabá Esporte Clube, foi desfeita. Seu maior rival é o Luverdense.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
  Campeão Mato-grossense 12 vezes:
2003, 2004, 2011, 2013, 2014, 2015, 2017, 2018, 2019, 2021, 2022 e 2023
<hr>
Campeão da Copa Verde: 2015 e 2019
<hr>
Campeão invicto da Copa Governador: 2010</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Principal ídolo: Fernando</p>
</div>
</div>
</div>
</div>

 

 
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

 

 

</body>
</html>