<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p>Fundado em 2 de junho de 1914, o Ceará orgulha-se de ter várias marcas importantes dentro do futebol cearense. Entre elas, a melhor colocação de um time do Estado na Série A do Campeonato Brasileiro (sétimo, em 1985) e na Copa do Brasil (vice-campeão, em 1994), além do maior número de títulos do Estadual (39, igualado pelo Fortaleza em 2010). O time alvinegro também foi o único do Estado a participar de uma competição internacional oficial: a Copa Conmebol de 1995 - vaga conseguida depois do vice da Copa do Brasil. Depois de 16 anos longe da primeira divisão do País, o Ceará conquistou o retorno ao terminar a Série B de 2009 em terceiro lugar. Seu maior rival é o Fortaleza.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
Torneio Norte-Nordeste: 1 título (1969)
<hr>
Copa do Nordeste: 3 títulos (2015, 2020, 2023)
<hr>

 

Campeonato Cearense: 45 títulos (1915, 1916, 1917, 1918, 1919, 1922, 1925, 1931, 1932, 1939, 1941, 1942, 1948, 1951, 1957, 1958, 1961, 1962, 1963, 1971, 1972, 1975, 1976, 1977, 1978, 1980, 1981, 1984, 1986, 1989, 1990, 1992, 1993, 1996, 1997, 1998, 1999, 2002, 2006, 2011, 2012, 2013, 2014, 2017 e 2018)

 

 

</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Arturzão
Carneiro
Gildo
Harry Carey
Hélio Carrasco
Iarley
Marciano
Mota
Sérgio Alves
Zé Eduardo</p>
</div>
</div>
</div>
</div>

 

 

 

<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

 

 

 

 

 

 

</body>
</html>