<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
</head>
<body>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p> É um clube brasileiro de desportos, situado no bairro da Ilha do Retiro, cidade do Recife, estado de Pernambuco. Foi fundado em 13 de maio de 1905, por Guilherme de Aquino Fonseca, um pernambucano que viveu por muitos anos na Inglaterra, onde estudou na Universidade de Cambridge e regressou a Pernambuco trazendo consigo o apreço pelo novo esporte daquele país: o futebol.
É conhecido pelo seu símbolo maior: o leão; suas cores oficiais são o preto e o encarnado e, desde o ano de 1937, manda seus jogos na Ilha do Retiro onde é apoiado pela massa sportista. O Leão da Ilha é um dos clubes mais populares do Brasil, tendo rivalidades históricas com o América Futebol Clube, com quem duela no Clássico dos Campeões, o primeiro clássico pernambucano em notoriedade; com o Clube Náutico Capibaribe, no confronto conhecido como o Clássico dos Clássicos, sendo este o terceiro clássico mais antigo do país e o mais antigo da Região Nordeste; e com o Santa Cruz Futebol Clube.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
<p>Campeonato Brasileiro  1 1987
<hr>
  Copa do Brasil  1 2008
<hr>
Campeonato Brasileiro - Série B 1 1990
<hr>
  Torneio Norte-Nordeste  1 1968
<hr>
  Copa do Nordeste  3 1994, 2000 e 2014

 

  Campeonato Pernambucano 42  1916, 1917,1920, 1923, 1924, 1925, 1928, 1938, 1941, 1942, 1943, 1948, 1949, 1953, 1955, 1956, 1958, 1961, 1962, 1975, 1977, 1980, 1981 1982, 1988, 1991, 1992, 1994, 1996, 1997, , 1999, 2000, 2003, 2006, 2007, 2008, 2009, 2010, 2014, 2017, 2019, 2023.
<hr>
  Copa Pernambuco 3 1998, 2003 e 2007
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Diego Souza, Roberto Coração de Leão, Magrão, Durval e Leonardo</p>
</div>
</div>
</div>
</div>

 

 

 

 

 
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

 

 

 

 

</body>
</html>