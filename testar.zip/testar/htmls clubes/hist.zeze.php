<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>A colônia italiana de Belo Horizonte almejava fundar um clube esportivo e resolveu aproveitar a passagem do cônsul da Itália pela cidade. Surgiu a Societá Sportiva Palestra Italia, em 2 de janeiro de 1921. As cores eram as mesmas da bandeira italiana, com camisa verde, calção branco e meias vermelhas. Durante a Segunda Guerra Mundial, o governo brasileiro proibiu o uso de termos relacionados às nações inimigas. Assim, em 1942, o time passava a se chamar Palestra Mineiro. No mesmo ano, jogou uma partida como Ypiranga, para depois adotar definitivamente o nome de Cruzeiro Esporte Clube, em homenagem a um dos principais símbolos do Brasil: a constelação Cruzeiro do Sul. Em outros esportes, o Cruzeiro se destaca também no Vôlei, em 2009 firmou parceria com a Associação Social e Esportiva Sada para formar uma equipe masculina de voleibol, o Sada Cruzeiro, que tem sido uma das mais importantes do país, sendo a única equipe brasileira a ter conquistado o Campeonato Mundial de Clubes de Voleibol, entre vários títulos importantes, como: quatro Mundiais de Clubes de Voleibol, sete Sul-Americanos de Voleibol, seis Superligas Nacionais, seis Copas Brasil de Voleibol, três Supercopas Brasileiras de Voleibol e doze Campeonatos Mineiros. No atletismo o Cruzeiro também tem um time forte, fazem parte de sua equipe vários atletas importantes, disputando as mais diversas corridas de nível nacional e mundial. Seu maior rival é o Atlético MG.</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>
</p>
2 Copa Libertadores da América: 1976, 1997
<hr>
2 Supercopa dos Campeões da Libertadores da América: 1991, 1992
<hr>
1 Recopa Sul-Americana: 1998
<hr>
1 Copa Ouro: 1995
<hr>
1 Copa Master da Supercopa: 1995



4 Campeonato Brasileiro: 1966, 2003, 2013, 2014
<hr>
6 Copa do Brasil: 1993, 1996, 2000, 2003, 2017, 2018
<hr>
1 Campeonato Brasileiro - Série B: 2022

<hr>

2 Copa Sul-Minas: 2001, 2002
<hr>
1 Copa Centro-Oeste: 1999
<hr>


38 Campeonato Mineiro: 1926, 1928, 1929, 1930, 1940, 1943, 1944, 1945, 1956, 1959, 1960, 1961, 1965, 1966, 1967, 1968 ,1969, 1972, 1973, 1974, 1975, 1977, 1984, 1987, 1990, 1992, 1994, 1996, 1997, 1998, 2002, 2003, 2004, 2006, 2008, 2009, 2011, 2014, 2019
<hr>
2 Copa dos Campeões Mineiros: 1991, 1999
<hr>
1 Supercampeonato Mineiro: 2002
<hr>
5 Taça Minas Gerais: 1973, 1982, 1983, 1984, 1985
<hr>
1 Copa Belo Horizonte: 1960
<hr>
10 Torneio Início: 1926, 1927, 1929, 1938, 1940, 1941, 1943, 1944, 1948, 1966
 </p>


</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>Dirceu Lopes
Joãozinho
Nelinho
Palhinha
Perfumo
Piazza
Raul
Sorín
Tostão
Zé Carlos</p>
      </div>
    </div>
  </div>
</div>





<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>











</body>
</html>


