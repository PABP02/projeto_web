<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Papo de Torcedores</title>
</head>

<body style="background-color: white;">
    <nav class="navbar navbar-expand-lg bg-black">
        <div class="container-fluid">
            <a class="navbar-brand text-"><img src="../teste.PNG" width="250px"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">
                    <li class="nav-item dropdown">
                        <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Opções
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
                            <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a>
                            </li>
                            <li><a class="dropdown-item text-" href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
                            <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
                            <li><a class="dropdown-item text-" href="#">História dos clubes</a></li>
                            <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
  </nav>


<h1 style="color: blue;">Escolha um clube:</h1>
<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit">  <a class="navbar-brand text-primary" href="hist.america.html"><img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/6154.png" width="180px">
</button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.goianiense.html"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTw4w_oECN8NnSa27u7biMXDrVefa8FqO0FAJYmQpypFySqG0uvNdGltSS1izunXY-jBeE&usqp=CAU" width="240px"></button>


<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.galo.html"><img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/7632.png" width="180px"></button>


<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.cap.html"><img src="https://static.athletico.com.br/wp-content/uploads/2019/08/29154056/escudo_rgb_cor_pos-protecao.png"width="150px"></button>


<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.avai.html"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Avai_FC_%2805-E%29_-_SC.svg/1200px-Avai_FC_%2805-E%29_-_SC.svg.png" width="150px"></button>





<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.fogao.html"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/Botafogo_de_Futebol_e_Regatas_logo.svg/1200px-Botafogo_de_Futebol_e_Regatas_logo.svg.png"width="150px"></button>


<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.rbb.html"> <img src="https://upload.wikimedia.org/wikipedia/pt/9/9e/RedBullBragantino.png"width="150px"></button>


<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.vovo.html"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Cear%C3%A1_Sporting_Club_logo.svg/1200px-Cear%C3%A1_Sporting_Club_logo.svg.png"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.chape.html"><img src="https://upload.wikimedia.org/wikipedia/pt/e/e4/Novo_escudo_da_Associa%C3%A7%C3%A3o_Chapecoense_de_Futebol.png"width="150px"></button>



<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.sccp.html"><img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/874.png"width="150px"></button>


<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.coxa.html"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Coritiba_FBC_%282011%29_-_PR.svg/800px-Coritiba_FBC_%282011%29_-_PR.svg.png"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.zeze.html"><img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/2022.png" width="150px"></button>


<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="hist.cuia.html"><img src="https://upload.wikimedia.org/wikipedia/pt/2/20/Cuiab%C3%A1EC2020.png"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histflu.html"><img src="https://s5.static.brasilescola.uol.com.br/be/2023/09/escudo-do-fluminense.jpg"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histfec.html"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/FortalezaEsporteClube.svg/1200px-FortalezaEsporteClube.svg.png"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histgoias.html"><img src="https://upload.wikimedia.org/wikipedia/commons/f/ff/Goi%C3%A1sLogo21.png"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histgremio.html"><img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/6273.png"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histdvd.html"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Escudo_do_Sport_Club_Internacional.svg/1200px-Escudo_do_Sport_Club_Internacional.svg.png"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histjec.html"><img src="https://s5.static.brasilescola.uol.com.br/be/2023/09/escudo-do-juventude.jpg"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histsemmundial.html"><img src="https://a.espncdn.com/i/teamlogos/soccer/500/2029.png"width="150px"></button>


  <button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histspfc.html"><img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/2026.png"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histsantos.html"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Santos_logo.svg/1200px-Santos_logo.svg.png"width="150px"></button>



<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histspor.html"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbsQUSTR71H3SRJrgFLqEGL3TY0KthHpUrNJiCFpfHBclXz4XoJmhkSf7rK1qALSF0UKg&usqp=CAU"width="150px"></button>

<button class="btn btn-outline-" type="submit"><button class="btn btn-outline-" type="submit"> <a class="navbar-brand text-primary" href="histgigantedacolina.html"><img src="https://upload.wikimedia.org/wikipedia/pt/a/ac/CRVascodaGama.png"width="150px"></button>


<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
  
</body>
</html>