<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>Sport Club Internacional surgiu como uma opção para os não-germânicos poderem disputar futebol em Porto Alegre. Foi fundado em 4 de abril de 1909, pelos irmãos José, Henrique Poppe Leão e Luiz Madeira Poppe. O nome Internacional, uma homenagem ao homônimo paulista, indicava a abertura da agremiação a pessoas de todas as origens. A primeira taça veio em 1913, no Campeonato Metropolitano de Porto Alegre. Desde então, a equipe colorada ganhou diversos títulos. Entre eles, o Mundial, duas Copas Libertadores, a Recopa e a Copa Sul-Americana - conquistadas na década de 2000 - e três Campeonatos Brasileiros - na década de 1970, com time liderado por Falcão. No futebol, é um dos clubes mais vitoriosos do Brasil e das Américas, sendo o terceiro maior campeão internacional do país, com sete conquistas oficiais, superado somente por Santos e São Paulo. Suas maiores conquistas foram as do Mundial de Clubes da FIFA, em 2006, e os dois títulos da Copa Libertadores da América, em 2006 e 2010, além de uma Copa Sul-Americana de forma invicta, em 2008, dois títulos da Recopa Sul-Americana, em 2007 e 2011, e uma Levain Cup/CONMEBOL (Copa Suruga Bank), em 2009. Seu maior rival é o Gremio.</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>
Copa do Mundo de Clubes da FIFA	1	2006
<hr>
Levain Cup/CONMEBOL	1	2009
<hr>
Copa Dubai	1	2008
<hr>
	Copa Libertadores da América	2	2006 e 2010
	<hr>
	Copa Sul-Americana	1	2008
	<hr>
	Recopa Sul-Americana	2	2007 e 2011
	<hr>

	Campeonato Brasileiro	3	1975, 1976 e 1979
	<hr>
	Copa do Brasil	1	1992
<hr>
	Torneio Heleno Nunes	1	1984
<hr>
	Campeonato Gaúcho	45	1927, 1934, 1940, 1941, 1942, 1943, 1944, 1945,1947, 1948, 1950, 1951, 1952, 1953, 1955, 1961, 1969, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1978, 1981, 1982, 1983, 1984, 1991, 1992, 1994, 1997, 2002, 2003, 2004, 2005, 2008, 2009, 2011, 2012, 2013, 2014, 2015 e 2016
	<hr>
	Copa FGF	2	2009 e 2010
	<hr>
	Recopa Gaúcha	2	2016 e 2017
 </p>


</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>Falcão
Fernandão
Figueroa
Gamarra
Manga
Oreco
Paulo César Carpegiani
Taffarel
Tesourinha
Valdomiro</p>
      </div>
    </div>
  </div>
</div>










<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>






</body>
</html>



