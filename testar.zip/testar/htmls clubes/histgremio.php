<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p>O Grêmio Foot-Ball Porto Alegrense foi fundado em 15 de setembro de 1903, em um restaurante da região central de Porto Alegre. A equipe venceu o primeiro campeonato que disputou, a Taça Wanderpreiss, em 1905 - que voltaria a ganhar em outras sete oportunidades. O Grêmio é, junto ao Cruzeiro, o maior campeão da história da Copa do Brasil (quatro taças). O ano de 1983 foi um dos mais marcantes da história da equipe, com as conquistas da Copa Libertadores e do Mundial, com o então atacante Renato Gaúcho tendo marcado os gols da vitória diante do Hamburgo, da Alemanha. Em 2005, no título da Série B, o time teve jogo histórico contra o Náutico, a "Batalha dos Aflitos". Seu maior rival é o Internacional.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
<p>Copa Intercontinental  1 1983
<hr>
Copa Libertadores da América  3 1983, 1995 e 2017
<hr>
Recopa Sul-Americana  2 1996 e 2018
<hr>
  Campeonato Brasileiro 2 1981 e 1996
<hr>
  Copa do Brasil  5 1989, 1994, 1997, 2001 e 2016
<hr>
  Supercopa do Brasil 1 1990
<hr>
  Campeonato Brasileiro - Série B 1 2005
<hr>
  Copa Sul  1 1999
<hr>
  Campeonato Sul-Brasileiro 1 1962
<hr>
  Campeonato Gaúcho 41  1921, 1922, 1926, 1931, 1932, 1946, 1949, 1956, 1957, 1958, 1959, 1960, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1977, 1979, 1980, 1985, 1986, 1987, 1988, 1989, 1990, 1993, 1995, 1996, 1999, 2001, 2006, 2007, 2010, 2018, 2019, 2020, 2021, 2022, 2023.
<hr>
  Copa FGF  1 2006
<hr>
  Recopa Gaúcha 4 2019, 2021, 2022, 2023.
<hr>
  Campeonato Citadino de Porto Alegre 29  1911, 1912, 1913,[104] 1914, 1915, 1919, 1920, 1921, 1922, 1923, 1925, 1926, 1930, 1931, 1932, 1933, 1935, 1937, 1938, 1939, 1946, 1949, 1956, 1957, 1958, 1959, 1960, 1964 e 1965
</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Alcindo
Aírton
Arce
Calvet
Eurico Lara
Everaldo
Foguinho
Hugo de León
Ronaldinho
Renato Gaúcho</p>
</div>
</div>
</div>
</div>

 

 

 
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

 

 

 

 

 

 

</body>
</html>