<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p>O Clube Atlético Paranaense surgiu da união de duas agremiações: o International e o América. A fusão foi concluída em 26 de março de 1924. O primeiro título da equipe já veio no ano seguinte: o Paranaense de 1925. Foi o primeiro de 21 troféus estaduais do Atlético - mais um Supercampeonato, em 2002. O principal título da história do clube foi o Campeonato Brasileiro de 2001, conquistado diante do São Caetano, com boas atuações do atacante Alex Mineiro. O time rubro-negro tem uma das melhores estruturas de trabalho do País, com o Estádio Arena da Baixada e o CT do Caju, e é o único clube do Estado a ter alcançado uma final de Copa Libertadores, em 2005.
  Do futebol paranaense, o Athletico é o único que conquistou títulos internacionais oficiais, dentre seus principais títulos, possui uma Levain Cup (2019), duas Copas Sul-Americana (2018 e 2021), um Campeonato Brasileiro (2001), uma Copa do Brasil (2019), uma Seletiva para a Libertadores (1999) e outros vinte e seis títulos paranaenses, tendo disputado mais de 4 545 jogos em sua história. Seu maior rival é o Coritiba.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
  Copa Sul-Americana  2 2018 e 2021

 

<hr>
  Campeonato Brasileiro 1 2001
<hr>
<hr>
  Seletiva da Libertadores  1 1999
<hr>
  Campeonato Brasileiro - Série B 1 1995

 

  Campeonato Paranaense 27  1925, 1929, 1930, 1934, 1936, 1940, 1943, 1945, 1949, 1958, 1970, 1982, 1983, 1985, 1988, 1990, 1998, 2000, 2001, 2002, 2005, 2009, 2016, 2018, 2019, 2020, 2023
<hr>
  Taça Caio Junior  1 2018
<hr>
  Taça Dirceu Krüger  1 2019
<hr>
  Copa Paraná 2 1998 e 2003
<hr>
  Torneio Início  6 1936, 1947, 1955, 1958, 1987 e 1988</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Alex Mineiro
Assis
Caju
Cireno
Djalma Santos
Jackson
Alberto Gottardi
Sicupira
Zanetti
Washington</p>
</div>
</div>
</div>
</div>

 

 <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

 

</body>
</html>