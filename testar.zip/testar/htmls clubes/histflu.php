<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p>O Fluminense Football Club surgiu em 21 de julho de 1902, no bairro das Laranjeiras, no Rio de Janeiro, como oprimeiro clube do Estado fundado só para o futebol. A equipe tricolor carioca foi a maior campeã do Estadual do Rio noséculo XX. Seu estádio, Manuel Schwartz, sediou jogos da Seleção Brasileira entre 1919 e 1932. Entre os principaistítulos do Fluminense estão a Copa Rio de 1952, os Torneios Rio-São Paulo de 1957 e 1960, o Torneio RobertoGomes Pedrosa de 1970, o Campeonato Brasileiro de 1984, 2010 e 2012 e a Copa do Brasil de 2007. O time maisfamoso da história do clube foi a chamada "Máquina Tricolor", liderado por Rivellino no fim da década de 1970. Um dos quatro grandes clubes do Rio de Janeiro, primeiro entre os doze grandes do futebol brasileiro a entrar em campo e a ostentar a palavra futebol no nome, o Fluminense é o clube que mais disputou campeonatos estaduais no Brasil, tendo sido a sua primeira participação em 1906, e a de 2022 a sua 118ª,s inspirando pelo menos outros 72 clubes que utilizam o seu nome, além do continente americano, na Europa e na África, sem considerar clubes que o homenagearam no uniforme ou no escudo.
Com os grandes títulos conquistados e a história construída desde a sua fundação, consolidou-se então entre os 12 maiores clubes de futebol.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
Copa Rio Internacional  1 1952
<hr>
  Campeonato Brasileiro 4 1970, 1984, 2010 e 2012
<hr>
  Copa do Brasil  1 2007
<hr>
  Campeonato Brasileiro - Série C 1 1999
<hr>
Taça Ioduran  1 1919
<hr>
  Torneio Rio-São Paulo 2 1957 e 1960
<hr>
Taça Brasil - Zona Sul  1 1960
<hr>
  Primeira Liga 1 2016
<hr>

 

  Campeonato Carioca  33  1906, 1907, 1908, 1909, 1911, 1917, 1918, 1919, 1924, 1936, 1937, 1938, 1940, 1941, 1946, 1951, 1959, 1964, 1969, 1971, 1973, 1975, 1976, 1980, 1983, 1984, 1985, 1995, 2002, 2005, 2012, 2022, 2023.
<hr>
  Copa Rio Estadual 1 1998
<hr>
  Taça Guanabara Independente 3 1966, 1969 e 1971
<hr>
  Torneio Início  9 1916, 1924, 1925, 1940, 1941, 1943, 1954, 1956 e 1965
<hr>
  Torneio Municipal do Rio de Janeiro 2 1938 e 1948
<hr>
  Torneio Extra 1 1941
<hr>
  Torneio Aberto do Rio de Janeiro  1 1935
<hr>
  Taça Guanabara  9 1975, 1983 , 1985 , 1991, 1993 , 2012, 2017, 2022, 2023
<hr>
  Taça Rio  4 1990, 2005, 2018 e 2020

 <hr> 
 Libertadores da América 1 2023

 

</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Assis
Branco
Carlos Alberto Torres
Castilho
Didi
Edinho
Fred
Gérson
Paulo César Caju
Rivellino
Telê Santana</p>
</div>
</div>
</div>
</div>

 

 <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

 

 

 

 

 

 

 

 

</body>
</html>