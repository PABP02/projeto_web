<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p>No dia 02 de abril de 1937, os jovens idealistas Edison Hermano, Nicanor Gordo, Afonso Gordo, Alberto Gordo, Armando, Benjamim Roriz, Ondomar Sarti, João de Brito Guimarães, João Batista Gonçalves, se reuniram no Bairro de Campinas no salão do sobrado do Hotel Pouso Alto, na Avenida 24 de outubro, em frente a Praça Joaquim Lúcio, e decididos fundaram o que é hoje o clube mais antigo de Goiânia, o Atlético Clube Goianiense.  As cores do clube foram uma homenagem a Flamengo e São Paulo, clubes que nutriam a torcida de parte dos fundadores do Atlético.

 

O Atlético é um clube de origem popular, sua fundação está ligada diretamente a uma iniciativa comunitária, fruto da ação de moradores e pequenos comerciantes do tradicional Bairro de Campinas e da Vila Operária. O bairro anteriormente era uma cidade e passa à condição de bairro para se tornar a principal base de apoio para a fundação da capital, Goiânia, que ocorreu em 1933.

 

No início de sua trajetória o Atlético teve como grande rival o Goiânia. Sendo os times mais antigos da capital tiveram uma rivalidade e hegemonia que se deu entre o final dos anos 30 até fim dos anos 50. Só nas décadas de 60, o Vila Nova, e na de 70, o Goiás, entram no cenário das disputas e conquistas.

 

O Atlético também foi o primeiro time a ter um campo de futebol próprio, o Estádio Antônio Accioly, ao qual celebra jogos desde os anos 30. Seu maior rival é o Goiás.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
Campeonato Brasileiro - Série C
2 títulos
1990 e 2008
<hr>

 

Campeonato Goiano
13 títulos
1944, 1947, 1949, 1955, 1957, 1964, 1970, 1985
1988, 2007, 2010, 2011, 2023.
<hr>

 

Torneio Integração
1 título
1971
<hr>
Campeonato Goiano Segunda Divisão
1 título
2005
<hr>
Copa Goiás
1 título
1998 </p>

 

 

</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Lindomar, Júlio César Imperador, Pedro Bala, Epitácio, Marçal, Márcio Defendi.</p>
</div>
</div>
</div>
</div>

 
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

</body>
</html>