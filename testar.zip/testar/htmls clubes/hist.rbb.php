<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>Fundação do Clube Atlético Bragantino aconteceu no dia 08 de janeiro de 1928 por dissidentes do Bragança Futebol Clube. Em sua primeira década teve uma alternância praticamente anual de presidentes. O primeiro deles foi Ismael de Aguiar Leme.

Como único representante da cidade, o Bragantino estreou no profissionalismo em 1949, terceira temporada da Lei do Acesso, quando disputou a 2ª Divisão do Campeonato Paulista. Após um breve período de instabilidade, o time firmou-se na divisão em 1956, disputando-a por 10 temporadas seguidas.

Foi neste período, em 1958, que chegou à presidência Nabi Abi Chedid. Sob seu comando, em 1965, o time conquistou o título da 1ª Divisão (equivalente à atual A2) e o acesso à elite do futebol paulista.
MUDANÇA DE NOME PARA RED BULL BRAGANTINO

Formado a partir da fusão do Red Bull Brasil, que foi representado pelo CEO Thiago Scuro, e pelo Bragantino, que teve o presidente Marquinhos Chedid como homem de frente no início de 2019; o departamento de futebol do Bragantino foi integralmente assumido pela Red Bull, que passou a tomar as decisões sobre o tema, assumindo também os custos da equipe. Inicialmente, a equipe disputou a Série B do Brasileiro (conquistou o título) apenas com nome Bragantino. Em 2020 passou a se chamar definitivamente Red Bull Bragantino, sofrendo algumas modificações, principalmente no escudo. Podemos dizer que seu maior rival é a Ponte Preta.</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>
Campeonato Brasileiro Série B (2ª Divisão): 1989 e 2019
<hr>

Campeonato Brasileiro Série C (3ª Divisão): 2007
<hr>

Campeonato Paulista Série A (1ª Divisão): 1990
<hr>
Troféu Interior do Campeonato Paulista: 2020
<hr>
Torneio Início do Camp. Paulista Série A (1ª Divisão): 1991
<hr>
Campeonato Paulista Série B (2ª Divisão): 1965, 1988
<hr>
Campeonato Paulista 5ª Divisão (Série B-2): 1979
 </p>


</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>Gil Baiano, Mauro Silva, Vanderlei Luxemburgo e Carlos Alberto Parreira.</p>
      </div>
    </div>
  </div>
</div>

<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>



</body>
</html>









