<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingOne">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
</button>
</h2>
<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
<div class="accordion-body">

<p>O Atlético-MG foi fundado em 25 de março de 1908, por 22 jovens que se reuniram no Parque Municipal, em Belo Horizonte. O time foi o vencedor da primeira edição do Campeonato Brasileiro, em 1971 - seu único título na competição. Também foi vice-campeão nacional em 1977 (invicto), 80 e 99. O Atlético conquistou ainda a primeira edição do Campeonato Mineiro, que era chamado de Campeonato da Cidade à época. A equipe alvinegra é a maior campeã do Estadual de MG, com 40 taças - 19 na versão antiga e 21 na atual. O principal ídolo alvinegro é o atacante Reinaldo, que atuou por 12 anos no clube e é omaior artilheiro, com 255 gols. Embora tenha atuado em outras modalidades esportivas ao longo dos anos, seu reconhecimento e suas principais conquistas foram alcançados no futebol. O clube é o maior campeão do Campeonato Mineiro com 47 troféus, além de ser o maior vencedor do Clássico Mineiro, com uma grande vantagem contra seu rival, o Cruzeiro.</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
</button>
</h2>
<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
<div class="accordion-body">
<p>
  1 Conmebol Libertadores 2013
<hr>
  Copa Conmebol 2 1992 e 1997
<hr>
  Recopa Sul-Americana  1 2014
<hr>

 

  Campeonato Brasileiro 2 1971 e 2021
<hr>
  Copa do Brasil  2 2014 e 2021
<hr>
  Supercopa do Brasil 1 2022
<hr>
  Copa dos Campeões do Brasil 1 1978
<hr>
  Campeonato Brasileiro - Série B 1 2006
<hr>
  Torneio dos Campeões Estaduais  1 1937
<hr>

 

 

  Campeonato Mineiro  48

 

 

1915, 1926, 1927, 1931, 1932, 1936, 1938, 1939, 1941, 1942, 1946, 1947, 1949, 1950, 1952, 1953, 1954, 1955, 1956, 1958, 1962, 1963, 1970, 1976, 1978, 1979, 1980, 1981, 1982, 1983, 1985, 1986, 1988, 1989, 1991, 1995, 1999, 2000, 2007, 2010, 2012, 2013, 2015, 2017, 2020, 2021, 2022, 2023.
  Taça Minas Gerais 5 1975, 1976, 1979, 1986 e 1987
<hr>
  Taça Belo Horizonte 3 1970, 1971 e 1972
<hr>
  Torneio dos Campeões da FMF 1 1974
<hr>
  Torneio Incentivo Mineiro - FMF 1 1993
<hr>
  Torneio Início  8 1928, 1931, 1932, 1939, 1947, 1949, 1950 e 1954
</p>
</div>
</div>
</div>
<div class="accordion-item">
<h2 class="accordion-header" id="panelsStayOpen-headingThree">
<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
</button>
</h2>
<div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
<div class="accordion-body">
<p>Victor
Ronaldinho Gaúcho
Leonardo Silva</p>
</div>
</div>
</div>
</div>

 

 <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

 

</body>
</html>