<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>O Sport Club Corinthians Paulista foi fundado em 1º de setembro de 1910. O nome acabou definido posteriormente, em homenagem ao time inglês Corinthian FC, que estava excursionando pelo Brasil na época. Outras ideias de nome foram Santos Dumont e Carlos Gomes. A equipe é a maior campeã da história do Campeonato Paulista, com 26 taças. O Corinthians ainda tem no histórico um título mundial, quatro Campeonatos Brasileiros e três Copas do Brasil. Uma das conquistas mais comemoradas pela torcida foi a do Estadual de 1977, com o famoso gol de Basílio, quebrando um tabu de 22 anos e oito meses sem títulos. Suas cores tradicionais são o branco e o preto. Desde 2014, manda suas partidas de futebol na Neo Química Arena. Seus rivais históricos são o Palmeiras, com quem disputa o Derby Paulista; o São Paulo, com quem disputa o Majestoso; e o Santos, com quem disputa o Clássico Alvinegro. Sua torcida é conhecida como "Fiel"e seus torcedores são estimados em aproximadamente 30 milhões espalhados por todo o Brasil e pelo mundo, atrás nacionalmente somente do carioca Flamengo.a sua torcida é considerada também uma das maiores torcidas do mundo.

De modalidades esportivas importantes ao longo da história corintiana, destacam-se o basquete, onde o clube desfrutou de relativo sucesso, especialmente durante as décadas de 1950 e 1960, com a conquista de títulos paulistas, brasileiros e até sul-americanos, a natação que rendeu quatro conquistas do Troféu Brasil de Natação, atual Troféu Maria Lenk, e o futsal, a partir da década de 1970, que rendeu conquistas em torneios estaduais e nacionais. A influência do remo na história do clube modificou o escudo original, que aludia meramente ao futebol, com o acréscimo do par de remos e da âncora como aparecem até os dias de hoje.</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>
MUNDIAL FIFA INTERCLUBES (2)
2000
2012
  <hr>
LIBERTADORES DA AMÉRICA (1)
2012
  <hr>

RECOPA SUL-AMERICANA (1)
2013
  <hr>
CAMPEONATO BRASILEIRO (7)
1990
1998
1999
2005
2011
2015
2017
<hr>
  
COPA DO BRASIL (3)
1995
2002
2009
  <hr>

  
TAÇA RIO-SÃO PAULO (5)
1950
1953
1954
1966
2002
  <hr>
CAMPEONATO PAULISTA (30)
1914
1916
1922
1923
1924
1928
1929
1930
1937
1938
1939
1941
1951
1952
1954
1977
1979
1982
1983
1988
1995
1997
1999
2001
2003
2009
2013
2017
2018
2019

  <hr>
CAMPEONATO BRASILEIRO SÉRIE B (1)
2008
 </p>


</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>Casagrande
Cláudio
Luizinho
Marcelinho
Neto
Rivellino
Gylmar dos Santos Neves
Sócrates
Wladimir
Zé Maria
Cássio
Renato Augusto</p>
      </div>
    </div>
  </div>
</div>

<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>



</body>
</html>











