<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>No dia 1º de setembro de 1923, em uma reunião na casa do Sr. Amadeu Horn, os jovens atletas decidiram, em conjunto com o comerciante, fundar um clube de futebol. O nome do novo time seria “Independência” e teria como presidente o próprio Sr. Amadeu Horn.

Quando tudo já estava praticamente decidido, o Sr. Arnaldo Pinto de Oliveira chegou à reunião trazendo novas idéias e acabou influenciando os participantes a mudar o nome do time que estava sendo fundado. O argumento do Sr. Arnaldo era que Independência seria um nome complicado para a torcida gritar em apoio ao time e até terminar de falar “Independencia” o outro time já teria empatado o jogo. Como estava lendo um livro sobre a história do Brasil, ele propôs o nome Avahy, em referência à Batalha do Avahy.

Neste momento, todos apoiaram a ideia e começaram a gritar Avahy, Avahy, Avahy! E desta maneira, entusiasmada e convicta, teve início a história cheia vitórias e conquistas do então Avahy Foot-ball Club.
 Avaí é o clube com a maior torcida de Santa Catarina, com cerca de meio milhão de torcedores, segundo diferentes pesquisas recentes elaboradas pelo instituto Pluri junto ao IBGE na Região Sul do Brasil, entre os anos de 2012, 2013 e 2014, seu maior rival é a Chapecoense.</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>
– Campeão Brasileiro da Série C

1998
<hr>
– Vice-Campeão Brasileiro da Série B
2016
<hr>


– 18 vezes Campeão Catarinense de Futebol
1924, 1926, 1927, 1928 (Tri), 1930, 1942, 1943, 1944, 1945 (Tetra), 1973, 1975, 1988, 1997, 2009, 2010 (Bi-campeão), 2012, 2019 e 2021.
<hr>
– Campeão Catarinense da 2ª Divisão
1994
<hr>
– 02 vezes Campeão da Taça Governador do Estado de Santa Catarina
1983, 1985
<hr>
– Campeão da Copa Santa Catarina
1995
<hr>
– 12 vezes Campeão do Torneio Início

1925, 1926 (Bi), 1933, 1936, 1938, 1942, 1943, 1944 (Tri), 1946, 1955, 1960, 1963</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>César Silva, Jorge Fossati e Eduardo Martini.


Deodato, Loló e Émerson.


Balduino, Beck, Belmonte, Zenon, Adilson Heleno e Marquinhos Santos.


Cavallazzi, Décio Antônio, Evando, Juti, Toninho Quintino e Saul Oliveira.</</p>
      </div>
    </div>
  </div>
</div>




<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>