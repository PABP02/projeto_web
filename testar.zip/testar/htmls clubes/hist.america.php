<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>
<body>
<div class="accordion mt-4" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
       História 
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
       
<p>Em 30 de abril de 1912, jovens da elite mineira reuniram-se para formar um clube. Tanto o nome América Foot-Ball Club (posteriormente, mudou-se a grafia), quanto as cores verde e branca foram escolhidas por meio de sorteio. Até hoje detém, junto ao ABC, o recorde brasileiro de títulos estaduais consecutivos: dez, entre 1916 e 1925. Entre os principais títulos da história do América estão o Campeonato Brasileiro da Série B de 1997, a Série C de 2009 e a Copa Sul-Minas de 2000. Além das dez taças consecutivas do Campeonato Mineiro, o time alviverde conquistou o Estadual em outras cinco ocasiões: em 1948, 57, 71, 93 e 2001.
O clube é proprietário do Estádio Independência, sendo o único de Belo Horizonte a mandar seus jogos em estádio próprio, com o América possuindo a terceira maior torcida entre clubes de Minas Gerais, seu maior rival é o Atlético-MG.</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
        TÍTULOS:
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
        <p>Campeonato Brasileiro - Série B
1 título
1997
<hr>
Campeonato Brasileiro - Série C
1 título
2009
<hr>
Campeonato Mineiro
15 títulos
1916, 1917, 1918, 1919, 1920, 1921, 1922
1923, 1924, 1925, 1948, 1957, 1971, 1993
2001
<hr>
Copa Sul-Minas
1 título
2000
<hr>
Campeonato Mineiro - Módulo II
1 título
2008
<hr>
Taça Minas Gerais
1 título
2005</p>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
        Ídolos
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        <p>Neneca, Estevam, Zé Horta, Vander e Cláudio Mineiro; Pedro Omar, Zuca, Juca Show e Jair Bala; Euller e Fred.</p>
      </div>
    </div>
  </div>
</div>
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>



