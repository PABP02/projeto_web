<!DOCTYPE html>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:white;">
	<nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
              <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="estaduais.php">Classificações e estatísticas estaduais</a></li>
                <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>


            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
   <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <thead>

      <tr>
          <th scope="col">Colocação</th>
          <th scope="col">Time</th>
          <th scope="col">Pts</th>
          <th scope="col">SG</th>
          <th scope="col">Vitórias</th>
          <th scope="col">Derrotas</th>
        
      </thead>
      <h1>GRUPO A</h1>
  <div class="row">
<tr>
     <th scope="row" style="color: blue;">1</th>
      <td>Atlético</td>
      <td>20</td>
      <td>10</td>
      <td>6</td>
      <td>0</td>
    </tr>
    
    <tr>
      <th scope="row"  style="color: blue;">2</th>
      <td>Athletic</td>
      <td>15</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
     
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Vila Nova</td>
      <td>10</td>
      <td>-6</td>
      <td>3</td>
      <td>4</td>
    </tr>
      <tr>
      <th scope="row">4</th>
      <td>Pouso Alegre</td>
      <td>10</td>
      <td>-3</td>
      <td>2</td>
      <td>2</td>

    </tr>
  </div>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <thead>

      <tr>
          <th scope="col">Colocação</th>
          <th scope="col">Time</th>
          <th scope="col">Pts</th>
          <th scope="col">SG</th>
          <th scope="col">Vitórias</th>
          <th scope="col">Derrotas</th>
        
      </thead>
      <h1>GRUPO B</h1>
  <div class="row">
<tr>
     <th scope="row" style="color: blue;">1</th>
      <td>América </td>
      <td>18</td>
      <td>6</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th scope="row" >2</th>
      <td>Caldense</td>
      <td>5</td>
      <td>-6</td>
      <td>1</td>
      <td>5</td>
    </tr>
         <tr>
      <th scope="row">3</th>
      <td>Patrocinense</td>
      <td>4</td>
      <td>-5</td>
      <td>1</td>
      <td>6</td>

    </tr>
     <tr>
      <th scope="row">4</th>
      <td>Democrata SL</td>
      <td>4</td>
      <td>-6</td>
      <td>0</td>
      <td>4</td>
     
    </tr>

  </div>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <thead>

      <tr>
          <th scope="col">Colocação</th>
          <th scope="col">Time</th>
          <th scope="col">Pts</th>
          <th scope="col">SG</th>
          <th scope="col">Vitórias</th>
          <th scope="col">Derrotas</th>
        
      </thead>
      <h1>GRUPO C</h1>
  <div class="row">

    <tr>
      <th scope="row" style="color:blue;">1</th>
      <td>Cruzeiro</td>
      <td>12</td>
      <td>4</td>
      <td>3</td>
      <td>2</td>
    </tr>
    </tr>
      <tr>
      <th scope="row">2</th>
      <td>Tombense</td>
      <td>11</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>

    </tr>
    <tr>
     <th scope="row" >3</th>
      <td>Democrata</td>
      <td>10</td>
      <td>-2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th scope="row" >4</th>
      <td>Ipatinga</td>
      <td>9</td>
      <td>-2</td>
      <td>2</td>
      <td>3</td>
     </tr>
    
  </div>

  
</table>
</table>
<p style="color: blue;">Texto em azul = classificação para as semis de finais</p>
<hr>
SEMI FINAS
(AGREDADO, IDA E VOLTA)

América-MG 4 X 1 Cruzeiro
Atlético-MG 1 X 1 Athletic(Atlético-MG classificado por melhor campanha.)
 FINAS
(AGREDADO, IDA E VOLTA)
Atlético-MG 5 X 2 América-MG
<hr>
<h1><STRONG>Atlético-MG CAMPEÃO!</STRONG></h1>
<div vw class="enabled">
 <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</div>
</body>
</html>