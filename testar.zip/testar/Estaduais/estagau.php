<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
        <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="estaduais.php">Classificações e estatísticas estaduais</a></li>
                <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
<li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>
            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
  
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de Gols </th>
      <th scope="col">Time</th>
   
    </tr>
    <tbody>
   
    <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Pedro Henrique</td>
      <td>8</td>
      <td>Internacional</td>

    </tr>
        <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Luis Suárez</td>
      <td>7</td>
      <td>Gremio</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Rodrigo Rodrigues</td>
      <td>6</td>
      <td>Juventude</td>
    </tr>

    <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Erick</td>
      <td>5</td>
      <td>Ypiranga</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Luiz Baio</td>
      <td>5</td>
      <td>Ypiranga</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Carlos Henrique</td>
      <td>5</td>
      <td>Avenida</td>
    </tr>
     <tr>
      <th scope="row">5</th>
      <td>Zagueiro</td>
      <td>Matheus Pivo</td>
      <td>4</td>
      <td>São José</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Eron</td>
      <td>4</td>
      <td>Caxias</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Maurício</td>
      <td>4</td>
      <td>Internacional</td>
    </tr>
   

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Alan Patrick</td>
      <td>4</td>
      <td>Internacional</td>
    </tr>
     
   
    
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
   
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Cristaldo</td>
      <td>5</td>
      <td>Gremio</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Wanderson</td>
      <td>5</td>
      <td>Internacional</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Jean Dias</td>
      <td>5</td>
      <td>Caxias</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>De Pena</td>
      <td>4</td>
      <td>Internacional</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>Maurício</td>
      <td>3</td>
      <td>Internacional</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Bitello</td>
      <td>3</td>
      <td>Gremio</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Luis Suárez</td>
      <td>3</td>
      <td>Gremio</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Meia</td>
      <td>Jadson</td>
      <td>2</td>
      <td>Juventude</td>
    </tr>
  
   
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Fernando Boldrin</td>
      <td>2</td>
      <td>Juventude</td>
    </tr>
    <tr>
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Luiz Adriano</td>
      <td>2</td>
      <td>Internacional</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Zagueiro</td>
      <td>2</td>
      <td>Juventude</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Patrick</td>
      <td>2</td>
      <td>Ypiranga</td>
    </tr>
    
     
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos </th>
      <th scope="col">Time</th>
 
   <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Jean </td>
      <td>7</td>
      <td>Juventude</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Kanemmann</td>
      <td>7</td>
      <td>Gremio</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Karl</td>
      <td>6</td>
      <td>São José</td>
    </tr>
   
   
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Lusa</td>
      <td>6</td>
      <td>Esportivo</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Grafite</td>
      <td>5</td>
      <td>Avenida</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Dumas</td>
      <td>5</td>
      <td>Brasil de Pelotas</td>
    </tr>

    <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Thiaguinho</td>
      <td>4</td>
      <td> Esportivo</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>João Gabriel</td>
      <td>4</td>
      <td>Esportivo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Alemão</td>
      <td>4</td>
      <td>Internacional</td>
    </tr>
   


   
   
   


  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
     <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Marciel</td>
      <td>2</td>
      <td>Caxias</td>
    </tr>
   
<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Dionathã</td>
      <td>2</td>
      <td>Novo Hamburgo</td>
    </tr>
<tr>
      <th scope="row">2</th>
      <td>Goleiro</td>
      <td>Jhon Victor</td>
      <td>1</td>
      <td>Internacional</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Moacir</td>
      <td>1</td>
      <td>Caxias</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Marco</td>
      <td>1</td>
      <td>São José</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Baralhas</td>
      <td>1</td>
      <td>Internacional</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Moledo</td>
      <td>1</td>
      <td>Internacional</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Jean </td>
      <td>1</td>
      <td>Juventude</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Alan Patrick </td>
      <td>1</td>
      <td>Internacional</td>
    </tr>

   <tr>
      <th scope="row"></th>
      <td>Lateral-esquerdo</td>
      <td>Diogo Barbosa</td>
      <td>1</td>
      <td>Gremio</td>
    </tr>
    <div vw class="enabled">
 <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>