<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Papo de Torcedores</title>
</head>

<body style="background-color: white;">
    <nav class="navbar navbar-expand-lg bg-black">
        <div class="container-fluid">
            <a class="navbar-brand text-"><img src="../teste.PNG" width="250px"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">
                    <li class="nav-item dropdown">
                        <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Opções
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
                            <li><a class="dropdown-item text-" href="#">Classificações e estatísticas de estaduais</a>
                            </li>
                            <li><a class="dropdown-item text-" href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
                            <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
                            <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
                            <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
  </nav>

  <style>
  
    body {
      background-color: #f5f5f5;
      font-family: Arial, sans-serif;
    }

    .navbar {
      background-color: #343a40; 
    }

    .navbar-brand img {
      width: 250px;
      height: auto;
    }

    .nav-link {
      color: #ffffff; 
    }



    .container {
      padding: 20px;
    }

    hr {
      background-color: #343a40;
    }

    .container img {
      max-width: 100%;
      height: auto;
    }

    .container a {
      display: block;
      margin: 20px 0;
    }
  </style>

</head>


  <div class="container">
    <img src="https://tntsports.com.br/__export/1617985108576/sites/esporteinterativo/img/2021/04/09/paulistao-2020-488x338_1.png">
    <a class="dropdown-item text-primary" href="class paulistao.php">Classificação Paulistão</a>
    <a class="dropdown-item text-primary" href="estapaulis.php">Estatísticas Paulistão</a>
    <hr>
    <img src="https://media.gazetadopovo.com.br/2011/03/670d140bcee7b021a3223a4bb6519ad3-gpLarge.jpg">
    <a class="dropdown-item text-primary" href="classpr.php">Classificação Paranaense</a>
    <a class="dropdown-item text-primary" href="estapr.php">Estatísticas Paranaense</a>
    <hr>
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABnlBMVEU2NDX/////ySlGtlTeMzn4ljMjbkX1ygE3NTbt7e37+/sWEhQyMDEzMjU2LDQmKTZMRDRGulU/fEXFpBgsgEfpwQodb0UuLC0mJCXkLzjfSDf5mjNLZkK0tLTk5OR/fn4pNDX/zygjICFxb3BAlErJoyw5Vz1rXDIlLDQ/hEcAAAArKDOiiB4dGhs3dLe1kS1YVlfW1ta7urq0NDfGfDNFQ0RQTk9nZWanpqZsTTQpXkCEhITIyMiXlpcrVz2fNDcAZ8MAYzPMNDiwcDTc7t5lMzXNtkKjoWvcvis7aD+zQjZGQDTkPUXfU1biYWTgamzeU0P2jhg1s0UHdzVGgGCGppOnwLDI18/67eT43MX3yqT1tYDynD9gvGuj1Kj66sL52YHo8+n679SMzJT70FiIzo9EOSAzQTgtSzpETzyAVzNZRDM2JTLpuiqUei96ZzFDo06gQTY3JwD702jJ5sxFjVr1o1V5n4jrgYb24uTvvsDqp6jcGSFQfqJoiJKEk4Imb71Ne6jRuD5jhZqYm3yrpmG5rFl/kYcAZcO5rUwaEoYtAAALYklEQVR4nO2d/3/axhnHRbwESRzO6OrcpQ5oPpbUcSoKtAKtoM5ZO0Obpq1Zu2bp8j2dm25Js3XfuiUOdowd/uvdPXcSAoSN26RW0L1/8MsC3Vn30XPPPffcSdY0hUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoXiZWF+iCzwy4Bl4GSY7FFf8Qtn/oNfhTjxDufcWz4fvg2cDXNp5kWZfyUX4tUTjFNnTv9M8triccbisQFLx36eBE3mAqbQ5JjSRGmiNAGUJuMoTcZRmoyjNBlHaTKO0mQcpck4SpNxlCbjKE3GUZqMM0GT04DU5HjCNTl18eLFMx9d/vgTxseXP11cX19PtJ3kOr//7PM/fGEYppkCTPPKlT9e/fJPSdWkk7t2/X2pxSjmjZvJ0yTXuXb9VrQePrdvJkqTXOfO+/sLIq3lblI06XTuRJmIGdWPbt9NhiZfhRUxjYrrFcs6sRnYKVtevmKEVblx98+zrgmpVQbtNaqNMrYJxsj/GmFMba3uVUJG4xK0X40vO8j2Bm2t1hHFkc1FhOiNgXaFGvmpL/SnA+vNoJ0epVh2Clgb5b/wtdGs+BDhjJMPjKVBj+qSXzS4VvAVaVB567Pz+sbX9976reTD9775y/KylIU6eV+U/IyKQsr+ffcw5h9k5/+68e4743PAt7/JioVzRGu+YTUzR3vxLwZcl82r6GAj2fmNVx5OmBcvnf02u8xPQhlLClnBR3v5LwJUk41zKfjV+Y3zc/usoS/dfyBUIY50ts3Zc7S27AVF8AzzWabI/vmTpfvfQg9CuCpK1mfOUnQRopXhbs+fm8sdnFNaOnvpAj874wpDmTU/ixsgSY3f6+z8+dxUebalY6+f5IVtEMWcNTdLoFl5W+PhyMPcWJ5tQu5x6QEXBTngi466Dc8b2hSDMJNEDySZIh+79CYXhUJgU5+xGN8OWjX/MJRom2Lv1oNlX9HGjDlZApPdGtKy9wbp2Kny9meZoRAIaL0ZG40xaMLMJHvmkGsZ90/63sidMU000ITwvaCHXd+5kNWwN4ua6KAJ/SFrXvpAE8i0YDwjfuVHaHIp0CTT8Mo2bjRmxdkGfef8yJ7hU6cGmpz254AheD5WasJnPs0a+2EfdWueC8itMriP/eB8iHfe5dz7jc/f3gPeDMPtxOKlg2yKMSMRLaFU5JF+0DMImJVeYZqIpFT+ZXK2CBMymmJFA5+IhtwjDuWmh0pOOI2wwK3osB8Ffbj68b8ZGxDR6g3XbdR1GrpEXLesojyhbFmWE5zODoqi7YjKkogbAC6yb4IaHHZQFke6jupWsVELVY9prei5nlUmsXS7xHHlwoxRrQ2m9TDgiLZDNFr0L57yM21RMu+XdHWs2fzAPwsX2UHV7ysZ/pUVNB/ZRX/Ro9Cw42crtBFex3N9UcSI0RRtd8Oa2Lwl/HM7XNK0KEyNfBVAE99/YAuykH7daLAMwD924mYq1JVtku1rygsUM1o+0YnUJOPH7YOS3spETWRlMuGGHEMWFCXNcrxEIZ4w/brjlL3CYA4LTeLWz+9tpCaypMdK1qHzTdbEr0xmZjEoVGmUnZoFBmM6ceo+qAyXpxHEIKyZ/npMhodZrKWmjqI1QTVopS5Kss6Qtyf2HZ4xAJuAtlMIVxpszEEIU5CrEqdYDvIbzcDL0aJsEuLrF1VuCXz+FuVP7KGSiHpYm6QJyNf05LG4DZbvWwgcFuPTe5AzYrmBODzlXueZQ0OLthNIXeuhwVUb1gQNNAHDsDCrzPQFrg4MAxxajNY7IAENLkNjAZSAH0AetUDAipiDidBkZVAyADRZyUjKA014N6Qgs0eENymHbgMor2txgYg7qGlyYsJwg4GmgWEFsEAjNXFT4YBDfMFbWwjwNQFn7BHoQQZBOpc7XNCu+ONbLCDQRQIVOAV+hGSngcut4yhNqsN3G77wV9oDhCbcVWPpuyzipGR44wOfl2OmCW/skCYQr7k2G08scKRRmuRTYwt80ZpA/8zzyriHqVDoluFOZ8dMEzclM8hDmkAkXizX63VYK67RCE281FjuGTSp+Ph9h3Bbs3hlZQMab4y4D1LwR+lYAA5DBAfcx65UQBMRiQ+oDjsPCuNOMSWi2RDCx9qCTF1oEuxKkDRXKsOeSDit+IzFIitv+bfbFprYleFmmDo3f38mBPFFk1JuQY3AUBCb80bGJ7Q5XFkK+lJhYGHw1+KUxYYuI9fHRfBaQKN3lvURHowYSJh3hjfSE37XrEuhSK3g4ChNIAIawqX8PjQzojYE6+xmfIYdBgK/2MAUY0J5hy9gCCRcS8L9hgGRfsVhJ1HheHR/4cfTKCFU97iPyERoAvFa3q+Md0qTiElymRL2Jx2x9BqrnQe4DnPTQr7RgEwy0wRiKOwDclhgOmbV81zQkM+KZEmj6bpNkKcSMQekPBox7aAysLEVkZ+tuA2vCXU04zTdYZCRnpKH/RGD/g0OV4RoARUUUbLgRNhJxkuF9/nBh8wS80MlmzFysAIcTvAUijaFvjHo3zAw1zNeuA1Ilhw4Y5OFMxH+BHxHyFmIgRnb1mDLtenFzEo4yK5XC9zEC9Ui8xgN0zDCExnsGewDQmp5OMloFoM2IFqsGlDSdSgfQdiZQVq7zupxi+xHeH4HtbMPMPZgJ7pR8fQYDTkh2EDqlMsOc7QaTyjrwxMyxD5weCYbs5NqGg1bOqaoxkoSsYtcnCjRfaIq4yX1WrnmkHgqAvDMEBr5Lfxd9Dfhb6OrnFjZPgVjgz4N07cBTVfhC2zQjwdbrKMfyPThpl6YorpD1Hck6KkpmDrepO7BlaXiNBuOhIzOSyKZcqurSGA/r9qOjNHJ8ASsqeKr0VnkBGKUmY4EOYa5P9AMc5qxgooA76D6CjE3Ex66ZfZl5TNoaOXghsiJ9e2/719hJobx6yGZP38dmnrwHBZB4G4m4rnRzi3hBQ4YQDPCW99MhCa5a8Kn1PZ1jXLSeyMZzxfnOnegucZ+myOkf72SkOfQc3Md4VIK+kRR5DO35v3EaDLX+YewlEmiSCtJfZeU9xXwPcMd8Q4HoxzpaP2Q/maC3mvBEaKYxfEhGfmPDt5M0rs+ADEip7zRvXnEKQxJkiRNZPdJNZ1w/0HUf6A4eFNOgjSZywlHmzKsTGAqRJcPzprfJe7dQcJSrqd8UxFeBWf8baHm3WPJ1GSu85W/M9bVCcKk6O+yuBF+ViVZmsx1/vmFVMF0nWKQLbl6LMGa5F69+LkvRLCZ+sq/1pOtyYmLJ3xTkdJ8uZ74dxueOHHx37cGilw9vq7egQnPA/7neyHJfz9dV+8FlZo8evTJ9ynjfx89Uu9KDb8r9dHlR4/U+2OnfZZWaaI0UZpwlCbjjP7vqlPwHLrPa4uLxxeHn0Nfmn1NshvnQny9Afwu4NfA62HivbvkuZC9MM5ywMlxZt5MtJNvLByS2e87J99IH5KkaNJ6XCptbj4ubSpNNKnJk26p1O0vbHVbShNNaLLNJCl1t7ZK3W2liSY02eGaPF3b65Z4m3d2lCbp9CaTpNROb3a5O1ko7az1Wq10r9/utdrbOzvtfq/VSy+0nvTSu09aSdGE95xeOi3cyfZqe7O71213ezure71Sb3Wbud5SutTr9p48fbKVEE3a3RK3kO1ut800aXXT3V5ra2114fFmutTaKbVLu3t7e5tr3f7qwtZeQjRpdbulBSbGKow6T5+2uzvdtZ1u+lk/3WX9qf9sobT7+PEWk2nv2W5CNFnr9daYGH0x6PTbrdJuO722trC7kN7ur7Xb/XRvod1nJtLf7i8kRJNRWhFRyu7jvWSNO4dj9jVZfvCLQzL7/w9dy0akA/Zl9iVRKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUMwc/weIVxLru62hMwAAAABJRU5ErkJggg==">
    <a class="dropdown-item text-primary" href="classgauchao.php">Classificação Gaúcho</a>
    <a class = "dropdown-item text-primary" href="estagau.php">Estatísticas Gaúcho</a>
    <hr>
    <img src="https://upload.wikimedia.org/wikipedia/pt/5/57/Carioca_2023_FERJ.jpg">
    <a class="dropdown-item text-primary" href="classrj.php">Classificação Carioca</a>
    <a class="dropdown-item text-primary" href="estarj.php">Estatísticas Carioca</a>
    <hr>
    <img src="https://a3.espncdn.com/combiner/i?img=%2Fi%2Fleaguelogos%2Fsoccer%2F500%2F2360.png">
    <a class="dropdown-item text-primary" href="classmg.php">Classificação Mineiro</a>
    <a class="dropdown-item text-primary" href="estamg.php">Estatísticas Mineiro</a>
  </div>
  <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>

</html>
