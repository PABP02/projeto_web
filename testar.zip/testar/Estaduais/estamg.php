<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de Gols </th>
      <th scope="col">Time</th>
   
    </tr>
    <tbody>
          <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Hulk</td>
      <td>11</td>
      <td>Atlético - MG</td>

    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Daniel Amorim</td>
      <td>10</td>
      <td>Tombense</td>
    </tr>

     <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Neto Costa</td>
      <td>5</td>
      <td>Patrocinense</td>
    </tr>
     <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Aloísio</td>
      <td>4</td>
      <td>América - MG</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Wellington Paulista</td>
      <td>4</td>
      <td>América - MG</td>
    </tr>

 
        <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Dodozinho</td>
      <td>4</td>
      <td>Vila-Nova</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Luan</td>
      <td>4</td>
      <td>Vila-Nova</td>
    </tr>

   

    <tr>
      <th scope="row">4</th>
      <td>Meia</td>
      <td>Benítez</td>
      <td>3</td>
      <td>América - MG</td>
    </tr>
     
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Gilberto</td>
      <td>3</td>
      <td>Cruzeiro</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Wellinton Torrão</td>
      <td>3</td>
      <td>Athletic</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Jonathan</td>
      <td>3</td>
      <td>Athletic</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Brandão</td>
      <td>3</td>
      <td>Democrata</td>
    </tr>
          <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Patrick</td>
      <td>3</td>
      <td>Caldense</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Mayco Félix</td>
      <td>3</td>
      <td>Caldense</td>
    </tr>
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
   
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Juninho</td>
      <td>4</td>
      <td>América - MG</td>
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Matheus Frizzo</td>
      <td>4</td>
      <td>Tombense</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Nael</td>
      <td>3</td>
      <td>Democrata GV</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Dodozinho</td>
      <td>3</td>
      <td>Vila Nova</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Gabriel Galhardo</td>
      <td>3</td>
      <td>Patrocinense</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Márcio Jr.</td>
      <td>2</td>
      <td>Ipatinga</td>
    </tr>
   
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Matheusinho</td>
      <td>2</td>
      <td>América - MG</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Benítez</td>
      <td>2</td>
      <td>América - MG</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Mayco Félix</td>
      <td>2</td>
      <td>Caldense</td>
    </tr>
 
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Erick Salles</td>
      <td>2</td>
      <td>Caldense</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Bruno Rodrigues</td>
      <td>2</td>
      <td>Cruzeiro</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Fabrício Bigode</td>
      <td>2</td>
      <td>Tombense</td>
    </tr>
    <tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Paulinho</td>
      <td>2</td>
      <td>Atlético - MG</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Carlinhos</td>
      <td>2</td>
      <td>Pouso Alegre</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Daniel Costa</td>
      <td>2</td>
      <td>Caldense</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Meia</td>
      <td>Patrick</td>
      <td>1</td>
      <td>Atlético - MG</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Otávio</td>
      <td>1</td>
      <td>Atlético - MG</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Rubens</td>
      <td>1</td>
      <td>Atlético - MG</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Vargas</td>
      <td>1</td>
      <td>Atlético - MG</td>
    </tr>
 
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Hulk</td>
      <td>1</td>
      <td>Atlético - MG</td>
    </tr>
   
   
    <tr>
      <th scope="row"></th>
      <td>Lateral-esquerdo</td>
      <td>Marlon</td>
      <td>1</td>
      <td>América - MG</td>
    </tr>
   
     
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos </th>
      <th scope="col">Time</th>
  <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Heitor</td>
      <td>8</td>
      <td>Pouso Alegre</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Luan</td>
      <td>8</td>
      <td>Vila Nova</td>
    </tr>
       <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Bruno Silva</td>
      <td>7</td>
      <td>Vila Nova</td>
    </tr>
        <tr>
      <th scope="row">3</th>
      <td>Zagueiro</td>
      <td>Léo Carioca</td>
      <td>5</td>
      <td>Democrata GV</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Renato Vischi</td>
      <td>5</td>
      <td>Pouso Alegre</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Juliano</td>
      <td>5</td>
      <td>Democrata SL</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>João Vitor</td>
      <td>5</td>
      <td>Caldense</td>
    </tr>
   
      <tr>
      <th scope="row">3</th>
      <td>Zagueiro</td>
      <td> Luizão</td>
      <td>5</td>
      <td>Vila Nova</td>
    </tr>
      <tr>
      <th scope="row">3</th>
      <td>Zagueiro</td>
      <td>Gabriel Marques</td>
      <td>5</td>
      <td>Democrata GV</td>
    </tr>
   
   <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Dadá Belmonte </td>
      <td>4</td>
      <td>América - MG</td>
    </tr>
 <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Hulk </td>
      <td>4</td>
      <td>Atlético - MG</td>
    </tr>
   
   
   
   
   
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Alason Carioca </td>
      <td>4</td>
      <td>Athletic</td>
    </tr>



   
   
   
<tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Guilherme Santos</td>
      <td>3</td>
      <td>Tombense</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Marcão</td>
      <td>3</td>
      <td>Democrata SL</td>
    </tr>
   

  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
     <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Davó</td>
      <td>1</td>
      <td>Cruzeiro</td>
    </tr>
   
<tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Suélinton</td>
      <td>1</td>
      <td>Caldense</td>
    </tr>
<tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Matheus Andrade</td>
      <td>1</td>
      <td>Tombense</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Kayo Soares</td>
      <td>1</td>
      <td>Caldense</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Douglas Dias </td>
      <td>1</td>
      <td>Democrata GV</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Thiaguinho</td>
      <td>1</td>
      <td>Democrata GV</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Amarildo</td>
      <td>1</td>
      <td>Pouso Alegre</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Bruno Silva</td>
      <td>1</td>
      <td>Tombense</td>
    </tr>
    <div vw class="enabled">
    <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>