<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-"><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
        <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="estaduais.php">Classificações e estatísticas estaduais</a></li>
                <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
  
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de Gols </th>
      <th scope="col">Time</th>
   
    </tr>
    <tbody>
   
    <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Pablo</td>
      <td>9</td>
      <td>Athletico</td>

    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Mingotti</td>
      <td>7</td>
      <td>Operário</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Lucas Coelho</td>
      <td>6</td>
      <td>Cascavel</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Robinho</td>
      <td>6</td>
      <td>Cascavel</td>
    </tr>
     <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Luiz Fernando</td>
      <td>5</td>
      <td>Cianorte</td>
    </tr>
     <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Rodrigo Pinha</td>
      <td>5</td>
      <td>Coritiba</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Felipe Augusto</td>
      <td>5</td>
      <td>Operário</td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td>Meia</td>
      <td>Vitor Bueno</td>
      <td>4</td>
      <td>Athletico</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Alef Manga</td>
      <td>4</td>
      <td>Coritiba</td>
    </tr>
   

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Terans</td>
      <td>4</td>
      <td>Athletico</td>
    </tr>
     
   <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Lucas Vieira</td>
      <td>4</td>
      <td>Azuriz</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Anderson Tanque</td>
      <td>4</td>
      <td>São Joseense</td>
    </tr>
    
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
   
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Terans</td>
      <td>7</td>
      <td>Athletico</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Mingotti</td>
      <td>4</td>
      <td>Operário</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Vitinho</td>
      <td>3</td>
      <td>Athletico</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Cannobio</td>
      <td>3</td>
      <td>Athletico</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Vitor Bueno</td>
      <td>3</td>
      <td>Athletico</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Fernandinho</td>
      <td>3</td>
      <td>Athletico</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Matheus Bianqui</td>
      <td>3</td>
      <td>Maringá</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Roque</td>
      <td>2</td>
      <td>Athletico</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Rodrigo Alves</td>
      <td>2</td>
      <td>Cascavel</td>
    </tr>
    <tr>
   
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Gui Sales</td>
      <td>2</td>
      <td>Maringá</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Mirandinha</td>
      <td>2</td>
      <td>Maringá</td>
    </tr>
    
     
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos </th>
      <th scope="col">Time</th>
 
   <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Luiz Fernando </td>
      <td>6</td>
      <td>Cianorte</td>
    </tr>

    <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Lagoa</td>
      <td>6</td>
      <td>Aruko</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Caique</td>
      <td>6</td>
      <td>Maringá</td>
    </tr>
   
   
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Vilar</td>
      <td>6</td>
      <td>Maringá</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>César Morais</td>
      <td>6</td>
      <td>Cascavel</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Victor Hugo</td>
      <td>5</td>
      <td>Londrina</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Vinicius Diniz</td>
      <td>5</td>
      <td>Operário</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Zezinho</td>
      <td>5</td>
      <td> Azuriz</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Max</td>
      <td>5</td>
      <td>Maringá</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>Gama</td>
      <td>5</td>
      <td>Cascavel</td>
    </tr>
   


   
   
   
<tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Igor Moraes</td>
      <td>5</td>
      <td>Cianorte</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Ferreira</td>
      <td>5</td>
      <td>Operário</td>
    </tr>
   

  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
     <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Fabricio</td>
      <td>1</td>
      <td>Coritiba</td>
    </tr>
   
<tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Pedro Henrique</td>
      <td>1</td>
      <td>Athletico</td>
    </tr>
<tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Thiago Heleno</td>
      <td>1</td>
      <td>Athletico</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Christian</td>
      <td>1</td>
      <td>Athletico</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Bruno Lope</td>
      <td>1</td>
      <td>Maringá</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Caliel </td>
      <td>1</td>
      <td>Rio Branco</td>
    </tr>
    <div vw class="enabled">
      <div vw-access-button class="active"></div>
   <div vw-plugin-wrapper>
     <div class="vw-plugin-top-wrapper"></div>
   </div>
 </div>
 
 <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
 <script>
   new window.VLibras.Widget({
       rootPah: '/app',
       personalization: 'https://vlibras.gov.br/config/default_logo.json',
       opacity: 0.5,
       position: 'L',
       avatar: 'random',
   });
 </script>
</body>
</html>