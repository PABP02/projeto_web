<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de Gols </th>
      <th scope="col">Time</th>
   
    </tr>
    <tbody>
   
    <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Róger Guedes</td>
      <td>8</td>
      <td>Corinthians</td>

    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Galoppo</td>
      <td>8</td>
      <td>São Paulo</td>
    </tr>
      <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Bruno Mezenga</td>
      <td>7</td>
      <td>Água Santa</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>John Kenedy</td>
      <td>6</td>
      <td>Ferroviária</td>
    </tr>
 
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Rony</td>
      <td>6</td>
      <td>Palmeiras</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Alerrandro</td>
      <td>4</td>
      <td>Bragantino</td>
    </tr>
     <tr>
      <th scope="row">5</th>
      <td>Atacante</td>
      <td>Salatiel</td>
      <td>4</td>
      <td>Botafogo</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Barletta</td>
      <td>4</td>
      <td>São Bernardo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Mendoza</td>
      <td>4</td>
      <td>Santos</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Zé Roberto</td>
      <td>4</td>
      <td>Mirassol</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Yuri Alberto</td>
      <td>4</td>
      <td>Corinthians</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Vitinho</td>
      <td>4</td>
      <td>São Bernardo</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Robinho </td>
      <td>4</td>
      <td>Botafogo</td>
    </tr>
  <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Marcos Leonardo</td>
      <td>4</td>
      <td>Santos</td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td>Atacante</td>
      <td>Pedrinho</td>
      <td>3</td>
      <td>São Paulo</td>
    </tr>
   

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Adson</td>
      <td>3</td>
      <td>Corinthians</td>
    </tr>
     


 
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Matheus Régis</td>
      <td>3</td>
      <td>São Bernardo</td>
    </tr>


    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Bill</td>
      <td>3</td>
      <td>Mirassol</td>
    </tr>
   
   
   

 
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
   
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Veiga</td>
      <td>5</td>
      <td>Palmeiras</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Lateral-direito</td>
      <td>Hurtardo</td>
      <td>5</td>
      <td>Bragantino</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Yuri Alberto</td>
      <td>4</td>
      <td>Corinthians</td>
    </tr>
         <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Vitinho</td>
      <td>4</td>
      <td>São Bernardo</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>Giuliano</td>
      <td>3</td>
      <td>Corinthians</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Renato Augusto</td>
      <td>3</td>
      <td>Corinthians</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Wellington Rato</td>
      <td>3</td>
      <td>São Paulo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-direito</td>
      <td>Fagner</td>
      <td>3</td>
      <td>Corinthians</td>
    </tr>
   
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Alerrandro</td>
      <td>3</td>
      <td>Bragantino</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Camilo</td>
      <td>3</td>
      <td>Mirassol</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Negueba</td>
      <td>3</td>
      <td>Mirassol</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>João Carlos</td>
      <td>3</td>
      <td>São Bernardo</td>
    </tr>
 
    <tr>
      <th scope="row">4</th>
      <td>Meia</td>
      <td>Lucas Lima</td>
      <td>2</td>
      <td>Santos</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-esquerdo</td>
      <td>Luan Candido</td>
      <td>2</td>
      <td>Bragantino</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Galoppo</td>
      <td>2</td>
      <td>São Paulo</td>
    </tr>
    <tr>
   
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Rony</td>
      <td>2</td>
      <td>Palmeiras</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Giovani</td>
      <td>2</td>
      <td>Palmeiras</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Calleri</td>
      <td>2</td>
      <td>São Paulo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Alan Franco</td>
      <td>2</td>
      <td>São Paulo</td>
    </tr>
   

   
   
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos </th>
      <th scope="col">Time</th>
 
   <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Rodrigo Souza </td>
      <td>9</td>
      <td>São Bernardo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Luiz Otávio</td>
      <td>6</td>
      <td>Mirassol</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td>Madison</td>
      <td>6</td>
      <td>Portuguesa</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Igor Henrique</td>
      <td>6</td>
      <td>Água Santa</td>
    </tr>
   
   <tr>
      <th scope="row"></th>
      <td>Lateral-direito</td>
      <td>Pará</td>
      <td>6</td>
      <td>Portuguesa</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Tauã Belo</td>
      <td>6</td>
      <td>Portugesa</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>Yuri Lima</td>
      <td>5</td>
      <td>Mirassol</td>
    </tr>
 <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Bruno Leonardo</td>
      <td>5</td>
      <td>Portugesa</td>
    </tr>
   
   
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Pablo Maia</td>
      <td>5</td>
      <td>São Paulo</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Matheus Fernandes </td>
      <td>5</td>
      <td>Bragantino</td>
    </tr>
   
 <tr>
      <th scope="row">4</th>
      <td>Meia</td>
      <td>Pablo</td>
      <td>4</td>
      <td>Ferroviária</td>
    </tr>
 <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Bernardo</td>
      <td>4</td>
      <td>Ferroviária</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>John Kenedy</td>
      <td>4</td>
      <td>Ferroviária</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Vitinho</td>
      <td>4</td>
      <td>São Bernardo</td>
    </tr>
   


  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Rodrigo Sam</td>
      <td>2</td>
      <td>Água Santa</td>
    </tr>
     <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Jadson</td>
      <td>1</td>
      <td>Bragantino</td>
    </tr>
   
<tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Nathan</td>
      <td>1</td>
      <td>Bragantino</td>
    </tr>
<tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Pablo Maia</td>
      <td>1</td>
      <td>São Paulo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Raul</td>
      <td>1</td>
      <td>Bragantino</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Luan Patrick</td>
      <td>1</td>
      <td>Bragantino</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Rodrigo Souza</td>
      <td>1</td>
      <td>São Bernardo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Luciano Cástan</td>
      <td>1</td>
      <td>Guarani</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Nathan</td>
      <td>1</td>
      <td>Bragantino</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-esquerdo</td>
      <td>Lucas Pires</td>
      <td>1</td>
      <td>Santos</td>
    </tr>
    <div vw class="enabled">
     <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>