!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="150px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
   <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         
         
          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
              <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
                <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>
         
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">
          <button class="btn btn-outline- text-info" type="submit">Buscar</button>
        </form>
      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
 <thead>
        <tr>

         <th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<tr>
<th scope="row" style="color: blue;">1</th>
<td>Girona</td>
<td>34</td>
<td>15</td>
<td>11</td>
<td>1</td>
</tr>
<tr>
<th scope="row" style="color: blue;">2</th>
<td>Real Madrid</td>
<td>32</td>
<td>19</td>
<td>10</td>
<td>1</td>
</tr>
<tr>
<th scope="row" style="color: blue;">3</th>
<td>Barcelona</td>
<td>30</td>
<td>13</td>
<td>9</td>
<td>1</td>
</tr>
<tr>
<th scope="row" style="color: blue;">4</th>
<td>Atletico de Madrid</td>
<td>28</td>
<td>17</td>
<td>9</td>
<td>2</td>
 
</tr>
<tr>
<th scope="row" style="color: orange;">5</th>
<td>Athletic Bilbao</td>
<td>24</td>
<td>8</td>
<td>7</td>
<td>3</td>
</tr>
 
 
<tr>
<th scope="row" style="color: green;">6</th>
<td>Real Sociedade</td>
<td>22</td>
<td>7</td>
<td>6</td>
<td>3</td>
</tr>
 
</tr>
<tr>
<th scope="row">7</th>
<td>Betis</td>
<td>22</td>
<td>1</td>
<td>5</td>
<td>2</td>
</tr>
 
<tr>
<th scope="row">8</th>
<td>Las Palmas</td>
<td>18</td>
<td>-1</td>
<td>5</td>
<td>5td>
</tr>
<tr>
<th scope="row">9</th>
<td>Valencia</td>
<td>18</td>
<td>-2</td>
<td>5</td>
<td>5</td>
</tr>
 
<tr>
<th scope="row">10</th>
<td>Rayo Vallecanno</td>
<td>18<td>
<td>-2</td>
<td>4</td>
<td>3</td>
</tr>
 
<tr>
<th scope="row">11</th>
<td>Getafe</td>
<td>16</td>
<td>-2</td>
<td>3</td>
<td>3</td>
</tr>
<tr>
<th scope="row">12</th>
<td>Osasuna</td>
<td>14</td>
<td>-6</td>
<td>3</td>
<td>5</td>
</tr>
 
<tr>
<th scope="row">13</th>
<td>Sevilla</td>
<td>12</td>
<td>1</td>
<td>2</td>
<td>4</td>     
</tr>
 
<tr>
<th scope="row" >14</th>
<td>Vilarreal</td>
<td>12</td>
<td>-6</td>
<td>3</td>
<td>7</td>
</tr>
 
<tr>
<th scope="row" >15</th>
<td>Alavés</td>
<td>12</td>
<td>-7</td>
<td>3</td>
<td>7</td>
</tr>
 
<tr>
<th scope="row" >16</th>
<td>Cádiz</td>
<td>10</td>
<td>-7</td>
<td>2</td>
<td>6</td>
</tr>  
 
<tr>
<th scope="row">17</th>
<td>Mallorca</td>
<td>9</td>
<td>-6</td>
<td>1</td>
<td>5</td>
</tr>
 
<tr>
<th scope="row" style="color: red;">18</th>
<td>Celta de Vigo</td>
<td>7</td>
<td>-10</td>
<td>1</td>
<td>8</td>
</tr>
 
<tr>
<th scope="row" style="color: red;">19</th>
<td>Granada</td>
<td>7</td>
<td>-12</td>
<td>1</td>
<td>8</td>
</tr>
 
<tr>
<th scope="row" style="color: red;">20</th>
<td>Almeria</td>
<td>3</td>
<td>-20</td>
<td>0</td>
<td>10</td>
</td>
</tr>
 
 
 
</tbody>
</table>

     <p style="color: blue;">Texto em azul:Classificação para a Champions League</p>
<p style="color: orange;">Texto em laranja: Classificação para a Europa League</p>
<p style="color: green;">Texto em verde: Classificação para a Conference League</p>
<p style="color: red;">Texto em vermelho: Rebaixado</p>

 <div vw class="enabled">
  <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

</body>
</html>






