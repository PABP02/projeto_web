

<!DOCTYPE html>

<html>

<head>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

 

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Papo de Torcedores</title>

</head>

 

<body style="background-color: gainsboro;">

   <nav class="navbar navbar-expand-lg bg-black">

    <div class="container-fluid">

      <a class="navbar-brand text-"><img src="../teste.PNG" width="150px"></a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

        <span class="navbar-toggler-icon"></span>

      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <ul class="navbar-nav me-auto mb-2 mb-lg-0">



          <li class="nav-item dropdown">

            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">

              Opções

            </button>

 

            <ul class="dropdown-menu">

              <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>

             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>

              <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="Classificação.php">Classificações de nacionais</a></li>


              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
<li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>
 

            </ul>

          </li>


        </ul>        <form class="d-flex" role="search">

          <input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">

          <button class="btn btn-outline- text-info" type="submit">Buscar</button>

        </form>

      </div>

    </div>

  </nav>

 

<h1>OITAVAS DE FINAIS</h1>

<p>Bahia 1(4) x (3)1 Santos</p>

<p>Cruzeiro 1 x 2 Grêmio</p>

<p> Flamengo 2 x 0 Fluminense</p>

<p>Botafogo 3(2) x (4)3 Athletico-PR</p>

<p>Internacional 3(4) x (5)3 América-MG</p>

<p>Atlético-MG 2(3) x (1)2 Corinthians</p>

<p>São Paulo 3(5) x (3)3 Sport</p>

<p> Fortaleza 1 x 3 Palmeiras</p>

 

     

<h1>QUARTAS DE FINAIS</h1>

<p>Grêmio 1(4) x (3)1 Bahia</p>

<p>Athletico-PR 1 x 4 Flamengo</p>

<p> Corinthians 3(3) x (1)3 América-MG</p>

<p>Palmeiras 1 x 3 São Paulo</p>

 

<h1>SEMIFINAIS</h1>

<p>Grêmio 0 x 3 Flamengo</p>

<p> Corinthians 2 x 3 São Paulo</p>

 

<h1>FINAL</h1>

<p> São Paulo 2 x 1 Flamengo</p>

 <div vw class="enabled">
  <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

</body>

</html>