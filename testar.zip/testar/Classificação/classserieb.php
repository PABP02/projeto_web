<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro; ">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="150px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         
         
          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
              <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
                <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>
         
        </ul>        <form class="d-flex" role="search">
          <input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">
          <button class="btn btn-outline- text-info" type="submit">Buscar</button>
        </form>
      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <thead>

     <tr>
         <th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>
</tr>
</thead>
<tbody>
<tr>
<th scope="row" style="color: blue;"> 1</th>
<td>Vitória</td>
<td>69</td>
<td>20</td>
<td>21</td>
<td>9</td>
</tr>
<tr>
<th scope="row" style="color: blue">2</th>
<td>Criciúma</td>
<td>61</td>
<td>11</td>
<td>18</td>
<td>11</td>
</tr>
<tr>
<th scope="row" style="color: blue">3</th>
<td>Juventude</td>
<td>61</td>
<td>9</td>
<td>17</td>
<td>9</td>
</tr>
 
 
            <th scope="row" style="color: blue">4</th>
<td>Atlético-GO</td>
<td>61</td>
<td>11</td>
<td>16</td>
<td>7 </td>
</tr>
<tr>
<th scope="row">5</th>
<td>Sport</td>
<td>60</td>
<td>17</td>
<td>16</td>
<td>8</td>
</tr>
<tr>
<th scope="row">6</th>
<td>Vila Nova</td>
<td>58</td>
<td>18</td>
<td>16</td>
<td>10</td>
</tr>
<tr>
<th scope="row">7</th>
<td>Novorizontino</td>
<td>57</td>
<td>15</td>
<td>17</td>
<td>13</td>
</tr>
 
        <tr>
<th scope="row">8</th>
<td>Mirassol</td>
<td>57</td>
<td>7</td>
<td>16</td>
<td>11</td>
</tr>
 
 
         <tr>
<th scope="row">9</th>
<td>Guarani</td>
<td>57</td>
<td>13</td>
<td>15</td>
<td>9</td>
</tr>
<th scope="row">10</th>
<td>CRB</td>
<td>54</td>
<td>7</td>
<td>15</td>
<td>12</td>
</tr>
<tr>
<th scope="row">11</th>
<td>Ceará</td>
<td>50</td>
<td>-1</td>
<td>13</td>
<td>12</td>
</tr>
<tr>
<th scope="row">12</th>
<td>Botafogo SP</td>
<td>47</td>
<td>-13</td>
<td>12</td>
<td>13</td>
</tr>
<tr>
<th scope="row">13</th>
<td>Avaí</td>
<td>43</td>
<td>-13</td>
<td>10</td>
<td>13</td>
</tr>
<tr>
<th scope="row">14</th>
<td>Ituano</td>
<td>40</td>
<td>-5</td>
<td>9</td>
<td>14</td>
</tr>  
<tr>
<th scope="row">15</th>
<td>Ponte Preta</td>
<td>48</td>
<td>-14</td>
<td>8</td>
<td>14</td>
</tr>
<tr>
<th scope="row">16</th>
<td>Tombense</td>
<td>37</td>
<td>-10</td>
<td>9</td>
<td>17</td>
</tr>
<tr>
<th scope="row">17</th>
<td>Chapecoense</td>
<td>36</td>
<td>-7</td>
<td>8</td>
<td>16</td>
</tr>
 
        <tr>
<th scope="row" style="color: red">18</th>
<td>Sampaio Corrêa</td>
<td>36</td>
<td>-13</td>
<td>7</td>
<td>14</td>
</tr>
<tr>
<th scope="row" style="color: red">19</th>
<td>Londrina</td>
<td>28</td>
<td>-27</td>
<td>6</td>
<td>20</td>
</tr>
<tr>
<th scope="row" style="color: red">20</th>
<td>ABC</td>
<td>22</td>
<td>-25</td>
<td>3</td>
<td>20</td>
</tr>
</tbody>
</table>
 

     <p style="color: blue;">Texto em azul:Classificação para a Champions League</p>
<p style="color: orange;">Texto em laranja: Classificação para a Europa League</p>
<p style="color: green;">Texto em verde: Classificação para a Conference League</p>
<p style="color: red;">Texto em vermelho: Rebaixado</p>

 <div vw class="enabled">
 <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

</body>
</html>