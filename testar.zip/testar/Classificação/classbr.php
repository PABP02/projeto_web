<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

 

  <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Papo de Torcedores</title>
</head>

 

<body style="background-color:gainsboro;">
<nav class="navbar navbar-expand-lg bg-black">
<div class="container-fluid">
<a class="navbar-brand text-" ><img src="../teste.PNG" width="150px"></a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav me-auto mb-2 mb-lg-0">


<li class="nav-item dropdown">
<button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
</button>

 

            <ul class="dropdown-menu">
<li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
<li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
<li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
<li><a class="dropdown-item text-" href="Classificação.php">Classificações de nacionais</a></li>

<li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
<li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

 

            </ul>
</li>

</ul>
<form class="d-flex" role="search">
<input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">
<button class="btn btn-outline- text-info" type="submit">Buscar</button>
</form>
</div>
</div>
</nav>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<thead>
<tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</tr>
</thead>
<tbody>
<tr>
  <th scope="row" style="color: blue">1<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWhXddd3OXCW52v7faoq-N7Ip4cpGlatV4NobKI7YD9A&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"> </th>
  <td>Palmeiras</td>
  <td>70</td>
  <td>31</td>
  <td>20</td>
  <td>8</td>
  </tr>
  <tr>
  <th scope="row" style="color: blue">2<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTW85-4n8snSZnLIqAmR-ZHgkM_MsAwzrYIqoBYQt3w_Q&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Grêmio</td>
  <td>68</td>
  <td>7</td>
  <td>21</td>
  <td>12</td>
  </tr>
   
  <tr>
  <th scope="row" style="color: blue">3<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfTcXUlTfVRcYy9q8ZI_MDr3h-4kU2DRy0JgvOnHd97g&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Atlético-MG</td>
  <td>66</td>
  <td>20</td>
  <td>19</td>
  <td>10</td>
  </tr>
   
  <tr>
  <th scope="row" style="color: blue">4<img src="https://static.dicionariodesimbolos.com.br/upload/8f/ec/simbolo-do-flamengo-13_xl.jpeg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Flamengo</td>
  <td>66</td>
  <td>14</td>
  <td>19</td>
  <td>10</td>
  </tr>
   
  <tr>
  <th scope="row" style="color: orange">5<img src="https://upload.wikimedia.org/wikipedia/commons/c/cb/Escudo_Botafogo.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Botafogo</td>
  <td>64</td>
  <td>21</td>
  <td>18</td>
  <td>10</td>
  </tr>
   
  <tr>
  <th scope="row" style="color: orange">6<img src="https://s2-ge.glbimg.com/B86Y3fAlfLO0Ny_fQOiLEvmcsfk=/0x0:960x960/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2020/X/b/OSdKnnQE60uyBYHXuO8w/escudo-rb-bragantino.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>RB Bragantino</td>
  <td>62</td>
  <td>14</td>
  <td>17</td>
  <td>10</td>
  </tr>
  <tr>
  <th scope="row" style="color: orange">7<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTrWzH8UGTqXNM50HivIw_3Z9UqKV_lHdO6auDtwv3Xg&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Fluminense</td>
  <td>56</td>
  <td>4</td>
  <td>16</td>
  <td>14</td>
  </tr>
  <tr>
  <th scope="row" style="color: green">8<img src="https://logodetimes.com/times/atletico-paranaense/logo-atletico-paranaense-4096.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Athletico</td>
  <td>56</td>
  <td>8</td>
  <td>14</td>
  <td>10</td>
  </tr>
  <tr>
  <th scope="row" style="color: green">9<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgdRYn3rbJ7x6DrAUlNWYc3tOvi5PWwTeCTDbU1R4c2Q&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Internacional</td>
  <td>55</td>
  <td>1</td>
  <td>15</td>
  <td>13</td> 
  </tr>
  <tr>
  <th scope="row" style="color: blue" >10<img src="https://upload.wikimedia.org/wikipedia/commons/9/9e/Escudo_do_Fortaleza_EC.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Fortaleza</td>
  <td>55</td>
  <td>1</td>
  <td>15</td>
  <td>14</td>
  </tr>
  <tr>
  <th scope="row" style="color: green">11<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Brasao_do_Sao_Paulo_Futebol_Clube.svg/2054px-Brasao_do_Sao_Paulo_Futebol_Clube.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>São Paulo</td>
  <td>53</td>
  <td>2</td>
  <td>14</td>
  <td>13</td>
  </tr>
  <tr>
  <th scope="row" style="color: green" >12<img src="https://logodetimes.com/wp-content/uploads/cuiaba.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Cuiaba</td>
  <td>51</td>
  <td>1</td>
  <td>14</td>
  <td>15</td>
  </tr>
  <tr>
  <th scope="row" style="color: green">13<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNm8AWsmRyn9dyN-EbCj9enNaUPP9VPcOJrWgk45Ubvg&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Corinthians</td>
  <td>50</td>
  <td>-1</td>
  <td>12</td>
  <td>12</td>
  </tr>
  <tr>
  <th scope="row">14<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Cruzeiro_Esporte_Clube_%28logo%29.svg/1200px-Cruzeiro_Esporte_Clube_%28logo%29.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Cruzeiro</td>
  <td>47</td>
  <td>3</td>
  <td>11</td>
  <td>13</td>
  </tr>
  <tr>
  <th scope="row">15<img src="https://static.dicionariodesimbolos.com.br/upload/60/81/conheca-o-significado-do-escudo-do-vasco-da-gama-5_xl.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Vasco da Gama</td>
  <td>45</td>
  <td>-10</td>
  <td>15</td>
  <td>17</td>
  </tr>  
   
  <tr>
  <th scope="row">16<img src="https://img.elo7.com.br/product/zoom/2B70220/simbolo-do-time-do-bahia-em-mdf-3d-time-do-nordeste.jpg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Bahia</td>
  <td>44</td>
  <td>-3</td>
  <td>12</td>
  <td>18</td>
  </tr>
   
  <tr>
  <th scope="row" style="color: red">17<img src="https://upload.wikimedia.org/wikipedia/commons/1/15/Santos_Logo.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Santos</td>
  <td>43</td>
  <td>-25</td>
  <td>11</td>
  <td>17</td>
  </tr>
  <tr>
  <th scope="row" style="color: red">18<img src="https://upload.wikimedia.org/wikipedia/commons/f/ff/Goi%C3%A1sLogo21.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Goiás</td>
  <td>38</td>
  <td>-17</td>
  <td>9</td>
  <td>18</td>
  </tr>
  <tr>
  <th scope="row" style="color: red">19<img src="https://img.elo7.com.br/product/zoom/2B70491/simbolo-do-time-do-coritiba-em-mdf-3d-parana.jpg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>Coritiba</td>
  <td>30</td>
  <td>-22</td>
  <td>8</td>
  <td>24</td>
  </tr> 
  <tr>
  <th scope="row" style="color: red">20<img src="https://upload.wikimedia.org/wikipedia/commons/a/ac/Escudo_do_America_Futebol_Clube.svg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
  <td>América-MG</td>
  <td>24</td>
  <td>-39</td>
  <td>5</td>
  <td>24</td>
  </tr>
  </tbody>
  </table>


<h1 style="color: blue;">Colocação em Azul: Classificação para a fase de grupos da Copa Libertadores 2024</h1>
<h1 style="color: orange;">Colocação em laranja: Classificação para a pré-Libertadores</h1>
<h1 style="color: green;">Colocação em verde: Classificação para a Copa Sudamericana 2024</h1>
<h1 style="color: red;">Colocação em vermelho: Rebaixamento para o Brasileirão Série B 2024</h1>
</tbody>
</table>
<div vw class="enabled">
  <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

  </body>
</html>