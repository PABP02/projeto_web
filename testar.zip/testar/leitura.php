<html>
<head>
  <title>Cadastro de Times</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
</head>
<body>

	<h1 style="text-align:center;" class="my-3">Cadastros</h1>
	<div class="d-flex justify-content-center my-3">
		<a href="indexx.php" class="btn btn-primary">Novo Cadastro</a>
	</div>

	<?php 
include "PDO.php";

$pdo = new usePDO();
 $pdo->createDB();
$pdo->createTableTimess();


$results = $pdo->selectAsterisco();

echo '<div class="container">
        <table class="table table-striped text-center align-middle">
          <thead>
            <tr class="table-dark">
              <th scope="col">id</th>
              <th scope="col">Time</th>
              <th scope="col">História</th>
              <th scope="col">Ídolo</th>
              <th scope="col">abs</th>
              <th scope="col">Editar</th>
              <th scope="col">Excluir</th>
            </tr>
          </thead>
          <tbody>';

foreach ($results as $time) {
    echo "<tr>
            <td>{$time['ID']}</td>
            <td>{$time['clube']}</td>
            <td>{$time['historia']}</td>
            <td>{$time['idolo']}</td>
            <td>{$time['img']}</td>
            
            <td>
              <a href='update.php?id={$time['ID']}'>
                <i class='bi bi-pencil text-primary'></i>
              </a>
            </td>
            <td>
              <a href='deletar.php?id={$time['ID']}'>
                <i class='bi bi-trash-fill text-danger'></i>
              </a>
            </td>
          </tr>";
}

echo '</tbody></table></div>';
?>
    <div vw class="enabled">
     <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>
