<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página do Sistema</title>
   
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
       
    </style>
</head>

<body>
<?php
session_start();
include "PDO.php";
$pdo = new usePDO(); 
$pdo->createDB();
$pdo->createTableTimecoracao();
if ((!isset($_SESSION['email'])) || (!isset($_SESSION['nome']))) {
    unset($_SESSION['email']);
    unset($_SESSION['nome']);
    session_unset();
    header('location:login.php?erro');
    exit;
}

$nome = $_SESSION['nome'];

if ($_SESSION['email'] === 'admin@times') {

    header('Location: login.php?erro');
    exit();
}

$resultado = NULL;


$resultado = $pdo->selectTimeCoracao($_SESSION['ID']);
?>


    <div class="container mt-5">
        <h1>Bem-vindo, <?php echo $nome; ?>!</h1>
           <?php
if ($resultado != NULL) {
    echo '
        <form method="POST" class="needs-validation" novalidate action="updattime.php">
            <div class="input-box">
            <input type="text" name="ID" hidden value="'.$resultado['ID'].'">
                <label for="time">Time </label>
                <select id="timecoracao" name="timecoracao" onchange="mostrarCampoOutro()">
              <option value="semtime" id="Sem time"></option>
                    <option value="Flamengo" id="flamengo">Flamengo</option>
                    <option value="Corinthians" id="corinthians">Corinthians</option>
                    <option value="São Paulo" id="sãopaulo">São Paulo</option>
                    <option value="Palmeiras" id="palmeiras">Palmeiras</option>
                    <option value="Vasco" id="vasco">Vasco</option>
                    <option value="Santos" id="santos">Santos</option>
                    <option value="Fluminense" id="fluminense">Fluminense</option>
                    <option value="Botafogo" id="botafogo">Botafogo</option>
                    <option value="Atlético-MG" id="atlético-mg">Atlético-MG</option>
                           <option value="Atlético-GO" id="atlético-go">Atlético-GO</option>
                                           <option value="América-MG" id="américa-mg">América-MG</option>
                    <option value="Athletico" id="athletico">Athletico</option>
                    <option value="Bahia" id="bahia">Bahia</option>
                    <option value="Internacional" id="internacional">Internacional</option>
                    <option value="Grêmio" id="grêmio">Grêmio</option>
                    <option value="Sport" id="sport">Sport</option>
                    <option value="Fortaleza" id="fortaleza">Fortaleza</option>
                    <option value="Vitória" id="vitória">Vitória</option>
                    <option value="Remo" id="remo">Remo</option>
                    <option value="Paysandu" id="paysandu">Paysandu</option>
                    <option value="Coritiba" id="coritiba">Coritiba</option>
                    <option value="Ceará" id="ceará">Ceará</option>
                    <option value="Goiás" id="goiás">Goiás</option>
                    <option value="Chapecoense" id="chapecoense">Chapecoense</option>
                    <option value="Juventude" id="juventude">Juventude</option>
                    <option value="Avaí" id="avaí">Avaí</option>
                    <option value="Criciúma" id="criciúma">Criciúma</option>
                    <option value="Vila Nova" id="vilanova">Vila Nova</option>
                    <option value="Figueirense" id="figueirense">Figueirense</option>
                    <option value="Outro" id="outro">Outro</option>
              
                </select>
                <input type="text" id="campoOutro" name="digite" style="display: none;" placeholder="Digite o time" value="'.$resultado['timecoracao'].'">
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    ';
} else {
    echo '
        <form method="POST" class="needs-validation" novalidate action="processando.php">
            <div class="input-box">
                <label for="time">Time</label>
                <select id="timecoracao" name="timecoracao" onchange="mostrarCampoOutro()">
                <option value="semtime" id="Sem time"></option>
                    <option value="Flamengo" id="flamengo">Flamengo</option>
                    <option value="Corinthians" id="corinthians">Corinthians</option>
                    <option value="São Paulo" id="sãopaulo">São Paulo</option>
                    <option value="Palmeiras" id="palmeiras">Palmeiras</option>
                    <option value="Vasco" id="vasco">Vasco</option>
                    <option value="Santos" id="santos">Santos</option>
                    <option value="Fluminense" id="fluminense">Fluminense</option>
                    <option value="Botafogo" id="botafogo">Botafogo</option>
                    <option value="Atlético-MG" id="atlético-mg">Atlético-MG</option>
                           <option value="Atlético-GO" id="atlético-go">Atlético-GO</option>
                                           <option value="América-MG" id="américa-mg">América-MG</option>
                    <option value="Athletico" id="athletico">Athletico</option>
                    <option value="Bahia" id="bahia">Bahia</option>
                    <option value="Internacional" id="internacional">Internacional</option>
                    <option value="Grêmio" id="grêmio">Grêmio</option>
                    <option value="Sport" id="sport">Sport</option>
                    <option value="Fortaleza" id="fortaleza">Fortaleza</option>
                    <option value="Vitória" id="vitória">Vitória</option>
                    <option value="Remo" id="remo">Remo</option>
                    <option value="Paysandu" id="paysandu">Paysandu</option>
                    <option value="Coritiba" id="coritiba">Coritiba</option>
                    <option value="Ceará" id="ceará">Ceará</option>
                    <option value="Goiás" id="goiás">Goiás</option>
                    <option value="Chapecoense" id="chapecoense">Chapecoense</option>
                    <option value="Juventude" id="juventude">Juventude</option>
                    <option value="Avaí" id="avaí">Avaí</option>
                    <option value="Criciúma" id="criciúma">Criciúma</option>
                    <option value="Vila Nova" id="vilanova">Vila Nova</option>
                    <option value="Figueirense" id="figueirense">Figueirense</option>
                    <option value="Outro" id="outro">Outro</option>
                   
                </select>
                <input type="hidden" name="timecoracao" value="" id="timecoracao-hidden"> 
                <input type="text" id="campoOutro" name="digite" style="display: none;" placeholder="Digite o time">
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    ';
}
?>
        
         
        </form>
    </div>
<?php  if ($resultado != NULL) {
    $timeIDSelect = strtolower($resultado['timecoracao']);
    $timeIDSelect = str_replace(" ","", $timeIDSelect);
    echo "<script> 
        var selectTime = document.getElementById('timecoracao');
        selectTime.options['". $timeIDSelect ."'].selected = true;
    </script>";
 } ?>
<script>
function mostrarCampoOutro() {
    var select = document.getElementById("timecoracao");
    var campoOutro = document.getElementById("campoOutro");
    var timecoracaoHidden = document.getElementById("timecoracao-hidden"); 

    if (select.value === "Outro") {
        campoOutro.style.display = "block";
        timecoracaoHidden.value = campoOutro.value; 
    } else {
        campoOutro.style.display = "none";
        timecoracaoHidden.value = select.value; 
    }
}
</script>

</script>


    <script>
        (function () {
            'use strict'

            var forms = document.querySelectorAll('.needs-validation');

            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        var time = document.getElementById('time');

                        if (!form.checkValidity()) {
                            time.classList.add('is-invalid');
                            event.preventDefault();
                            event.stopPropagation();
                        }

                        form.classList.add('was-validated');
                    }, false);
                });
        })();
    </script>
    <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>

</html>


