<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-primary" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
               <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-"  href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
              
                    <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>

              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
                 <li><a class="dropdown-item text-" href="#">Acesso ao blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
     <main>
    <article >
      <h2>O QUE É DIREITO AUTORAL</h2>
      <p>São normas estabelecidas pela legislação para proteger as relações entre o CRIADOR e a utilização de suas CRIAÇÕES, sejam elas criações artísticas, literárias ou cientificas, como por exemplo textos, livros, pinturas, músicas, ilustrações, fotografias etc.</p>
    </article>

    <article >
      <h2>Como a IA pode contribuir para o direito?</h2>
      <p>Análise de documentos e contratos:  Algoritmos de processamento de linguagem natural (PLN) podem ser treinados para identificar e extrair informações relevantes de documentos legais. Além disso, a IA também pode identificar inconsistências e erros em contratos, garantindo maior precisão e segurança jurídica.</p>
      <p>Pesquisa e análise jurídica:Plataformas baseadas em IA podem realizar buscas em bancos de dados jurídicos, analisar casos semelhantes e identificar padrões relevantes.  Com acesso rápido a informações atualizadas, os advogados podem tomar decisões mais informadas e construir argumentos mais sólidos.</p>
      <p>Atendimento ao cliente e suporte jurídico: Chatbots alimentados podem ser implementados em sites e aplicativos para fornecer respostas automáticas a perguntas comuns e orientar os clientes em relação a procedimentos legais básicos. </p>
    </article>

    <article >
      <h2>QUEM DETÉM OS DIREITOS DOS CONTEÚDOS GERADOS POR IA?</h2>
      <p>
O Criador da IA: Alguns argumentam que o criador da IA deve deter os direitos do conteúdo gerado por ela.</p>
<p>O Operador da IA: Outros argumentam que o operador da IA – a pessoa ou entidade que usa a IA para gerar conteúdo – deve deter os direitos;</p>
<p>A como Entidade Autônoma: Uma perspectiva mais radical é que a própria IA deve ser considerada a detentora dos direitos do conteúdo que cria. Isso pressupõe que a IA tem algum nível de autonomia e criatividade de ter direitos legais, o que é um tópico que ainda não é amplamente aceito;</p>
<p>
Ninguém: Alguns argumentam que o conteúdo gerado por IA não deve ser protegido por direitos de propriedade intelectual. Essa visão se baseia na ideia de que a propriedade intelectual é destinada a proteger a criatividade humana.</p>
    </article>

    <article>
      <h2>PODE SER UTILIZADA PARA MELHORAR A PROTEÇÃO DOS DIREITOS AUTORAIS EXISTENTES?</h2>
      <p>

- Detectar e bloquear o compartilhamento não autorizado de material protegido por direitos autorais online 

- Identificar e rastrear infratores de direitos autorais

- Ajudar os detentores de direitos autorais a gerenciar seus direitos e licenças

- As inteligências são treinadas a detectar arquivos, imagens, áudios e qualquer outro tipo de dado, que possa conter direitos autorais e bloqueá-los, ou redirecionar a monetização, punir a pessoa que fraudou o direito.</p>
    </article>
      <article>
      <h2>COMO PROTEGER COM DIREITOS AUTORAIS OS PRODUTOS GERADOS PELO SISTEMA DE IA?</h2>
      <p>Não é possível proteger com direitos autorais dos produtos gerados pelo sistema de inteligência artificial, já que o criador deve ser pessoa física.</p>
    </article>
  </main>


  <div vw class="enabled">
    <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
   <style type="text/css">

body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  line-height: 1.6;
}

header {
  background-color: #333;
  color: #fff;
  padding: 20px;
  text-align: center;
}

nav ul {
  list-style: none;
  padding: 0;
}

nav ul li {
  display: inline;
  margin-right: 20px;
}

nav ul li a {
  color: #fff;
  text-decoration: none;
}

main {
  padding: 20px;
}

article {
  margin-bottom: 30px;
}

footer {
  background-color: #333;
  color: #fff;
  text-align: center;
  padding: 10px 0;
  position: fixed;
  bottom: 0;
  width: 100%;
}

</style>
</body>

</html>
