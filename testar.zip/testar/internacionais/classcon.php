
<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-"><img src="../teste.PNG" width="150px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         
         
          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
              <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
              <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>
         
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">
          <button class="btn btn-outline- text-info" type="submit">Buscar</button>
        </form>
      </div>
    </div>
  </nav>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <thead>

 

      <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO A</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1 <img src="https://www.racingclub.com.ar/img/escudo/escudo2004.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Racing</td>
        <td>13</td>
        <td>7</td>
        <td>4</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: blue">2 <img src="https://static.dicionariodesimbolos.com.br/upload/8f/ec/simbolo-do-flamengo-13_xl.jpeg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Flamengo</td>
        <td>11</td>
        <td>6</td>
        <td>3</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">3 <img src="https://upload.wikimedia.org/wikipedia/commons/9/9f/%C3%91ublense.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Nublense</td>
        <td>5</td>
        <td>-7</td>
        <td>1</td>
        <td>3</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4 <img src="https://upload.wikimedia.org/wikipedia/pt/d/d2/SDAucas.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Aucas</td>
        <td>4</td>
        <td>-6</td>
        <td>1</td>
        <td>4</td>
        </tr>
        </div>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO B</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Escudo_do_Sport_Club_Internacional.svg/2048px-Escudo_do_Sport_Club_Internacional.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Internacional</td>
        <td>12</td>
        <td>4</td>
        <td>3</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: blue">2 <img src="https://logodetimes.com/times/nacional-uruguai/logo-nacional-uruguai-4096.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Nacional</td>
        <td>11</td>
        <td>2</td>
        <td>3</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">3 <img src="https://logodetimes.com/wp-content/uploads/independiente-medellin.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Ind. Medéllin</td>
        <td>10</td>
        <td>1</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4 <img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/13481.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Metropolitanos</td>
        <td>0</td>
        <td>-7</td>
        <td>0</td>
        <td>6</td>
        </tr>
        
         
        
            </tr>
        </div>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO C</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1 <img src="https://img.elo7.com.br/product/zoom/274E5EB/escudos-de-times-d-futebol-do-brasil-51-matrizes-d-bordado.jpg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Palmeiras</td>
        <td>15</td>
        <td>10</td>
        <td>5</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: blue">2 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Escudo_de_Club_Bol%C3%ADvar.svg/1795px-Escudo_de_Club_Bol%C3%ADvar.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Bolivar</td>
        <td>14</td>
        <td>4</td>
        <td>4</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">3 <img src="https://logodetimes.com/wp-content/uploads/barcelona-de-guayaquil.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Barcelona-EQU</td>
        <td>4</td>
        <td>-5</td>
        <td>1</td>
        <td>4</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Escudo_del_Club_Cerro_Porte%C3%B1o.svg/1200px-Escudo_del_Club_Cerro_Porte%C3%B1o.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Cerro</td>
        <td>4</td>
        <td>-9</td>
        <td>1</td>
        <td>4</td>
        </tr>
        </div>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO D</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1 <img src="https://imagepng.org/wp-content/uploads/2018/02/escudo-fluminense-fc-1.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Fluminense</td>
        <td>10</td>
        <td>4</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: blue">2 <img src="https://logodetimes.com/times/river-plate/logo-river-plate.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>River Plate</td>
        <td>10</td>
        <td>0</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">3 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Escudo_del_Club_Sporting_Cristal.svg/1255px-Escudo_del_Club_Sporting_Cristal.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Sporting Cristal</td>
        <td>8</td>
        <td>-2</td>
        <td>2</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4 <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRln2HPFSbdZWU5KTnGOop5LNYXriZxSbGEWllXMLzS7PT8Cf4wvZ38kFwU3MMZIJEL3fU&usqp=CAU"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>The Strongest</td>
        <td>6</td>
        <td>-2</td>
        <td>2</td>
        <td>4</td>
        </tr>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO E</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1 <img src="https://upload.wikimedia.org/wikipedia/commons/9/99/Independiente-del-Valle-Logo-2.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Indepediente Del Valle</td>
        <td>12</td>
        <td>5</td>
        <td>4</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: blue">2 <img src="https://upload.wikimedia.org/wikipedia/commons/5/57/Asociacion_Atletica_Argentinos_Juniors.svg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Argentinos Jrs</td>
        <td>11</td>
        <td>2</td>
        <td>3</td>
        <td>1</td>
          </tr>
        
            <tr>
        <th scope="row" style="color: yellow">3 <img src="https://upload.wikimedia.org/wikipedia/pt/b/b4/Corinthians_simbolo.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Corinthians</td>
        <td>7</td>
        <td>1</td>
        <td>2</td>
        <td>3</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4 <img src="https://upload.wikimedia.org/wikipedia/pt/1/1e/Liverpool_F%C3%BAtbol_Club.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Liverpool-URU</td>
        <td>4</td>
        <td>-8</td>
        <td>1</td>
        <td>4</td>
        </tr>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO F</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Boca_Juniors_logo18.svg/1730px-Boca_Juniors_logo18.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Boca JRS</td>
        <td>13</td>
        <td>7</td>
        <td>4</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: blue">2 <img src="https://seeklogo.com/images/D/Deportivo_Pereira-logo-2D79C939D5-seeklogo.com.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Deportivo Pereira</td>
        <td>8</td>
        <td>0</td>
        <td>2</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">3 <img src="https://s2-ge.glbimg.com/laCo6Bc6jDbXjI0TgrTzzB48SWo=/0x0:497x498/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2018/e/E/njxDfmQz6jysY2UQZ86A/escudo-colo-colo.jpg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Colo Colo</td>
        <td>6</td>
        <td>-2</td>
        <td>1</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4 <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/Tercer_Escudo.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Monagas</td>
        <td>5</td>
        <td>-5</td>
        <td>1</td>
        <td>3</td>
        </tr>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO G</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1 <img src="https://upload.wikimedia.org/wikipedia/pt/c/c7/Club_Athletico_Paranaense_2019.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Athletico</td>
        <td>13</td>
        <td>5</td>
        <td>4</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: blue">2 <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfTcXUlTfVRcYy9q8ZI_MDr3h-4kU2DRy0JgvOnHd97g&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Atlético-MG</td>
        <td>10</td>
        <td>2</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">3 <img src="https://upload.wikimedia.org/wikipedia/pt/e/e6/17830.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Libertad</td>
        <td>7</td>
        <td>-1</td>
        <td>2</td>
        <td>3</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Escudo_Alianza_Lima.svg/1200px-Escudo_Alianza_Lima.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Alianza Lima</td>
        <td>4</td>
        <td>-6</td>
        <td>1</td>
        <td>4</td>
        </tr>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO H</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1 <img src="https://upload.wikimedia.org/wikipedia/commons/6/61/Club_Olimpia.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Olimpia</td>
        <td>14</td>
        <td>9</td>
        <td>4</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: blue">2 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Escudo_de_Atl%C3%A9tico_Nacional.png/418px-Escudo_de_Atl%C3%A9tico_Nacional.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Atlético Nacional</td>
        <td>10</td>
        <td>0</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">3 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Escudo_del_Club_Atl%C3%A9tico_Patronato_de_la_Juventud_Cat%C3%B3lica_%282022%29.svg/1200px-Escudo_del_Club_Atl%C3%A9tico_Patronato_de_la_Juventud_Cat%C3%B3lica_%282022%29.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Patronato</td>
        <td>6</td>
        <td>-5</td>
        <td>2</td>
        <td>4</td>
        
         
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4 <img src="https://upload.wikimedia.org/wikipedia/pt/2/26/Foot_Ball_Club_Melgar.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Melgar</td>
        <td>4</td>
        <td>-4</td>
        <td>1</td>
        <td>4</td>
        </tr>
        
        </div>
        </tr>
        
         
        
        </thead>
        </table>
        </table>
        </table>
        
         
        
        <h1>OITAVAS DE FINAIS</h1>
        <p>Boca JRS 2(4) x (2)2 Nacional</p>
        <p>Racing 5 x 4 Atlético Nacional</p>
        <p>Independente del Valle 1 x 2 Deportivo Pereira</p>
        <p>Palmeiras 1 x 0 Atlético-MG</p>
        <p>Fluminnse 3 x 1 Argentinos JRS</p>
        <p>Olimpia 3 x 1 Flamengo</p>
        <p>Athletico-PR 3(4) x (5)3 Bolivar</p>
        <p>Internacional 3(9) x (8)3 River Plate</p>
        
         
        
        <h1>QUARTAS DE FINAIS</h1>
        <p>Boca JRS 1(4) x (1)1 Racing</p>
        <p>Palmeiras 4 x 0 Deportivo Pereira</p>
        <p>Olimpia 1 x 5 Fluminense</p>
        <p>Internacional 3 x 0 Bolivar</p>
        
        <h1>SEMIFINAIS</h1>
        <p>Palmeiras 1(2) x (4)1 Boca JRS</p>
        <p>Internacional 3 x 4 Fluminense</p>
        
         
        
        <h1>FINAL</h1>
        <p>Fluminense 2 x 1 Boca JRS</p>
        
         <h1>CAMPEÃO FLUMINENSE <img src="https://tntsports.com.br/__export/1699135975679/sites/esporteinterativo/img/2023/11/03/flu-campexo-liberta-portal.png_1758632412.png"   style="max-width: 300px; max-height: 300px; margin-left: 5px;"></h1>
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
 

</body>
</html>