<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-"><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
          <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
              <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>

<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
<thead>
<tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de Gols </th>
<th scope="col">Time</th>

 

</tr>
<tbody>

 

<tr>
<th scope="row">1</th>
<td>Atacante</td>
<td>G.Cano</td>
<td>13</td>
<td>Fluminense</td>

 

 

    </tr>
<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Pabon</td>
<td>6</td>
<td>Nacional</td>
</tr>
<tr>
<th scope="row">3</th>
<td>Atacante</td>
<td>Artur</td>
<td>5</td>
<td>Palmeiras</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Alan Patrick</td>
<td>5</td>
<td>Internacional</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Bentancourt</td>
<td>4</td>
<td>Liverpool</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Valencia</td>
<td>4</td>
<td>Internacional</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Triverio</td>
<td>4</td>
<td>Strongest</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Paiva</td>
<td>4</td>
<td>Olimpia</td>
</tr>

 

<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Vitor Roque</td>
<td>4</td>
<td>Athletico Paranaense</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>John Kenedy</td>
<td>4</td>
<td>Fluminense</td>
</tr>
<tr>
<th scope="row"></th>
<td>Lateral-direito</td>
<td>Advincula</td>
<td>4</td>
<td>Boca Juniors</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Fernandez</td>
<td>4</td>
<td>Bolivar</td>
</tr>

 

<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Matias Rojas</td>
<td>3</td>
<td>Racing(Corinthians)</td>
</tr>

 

 

<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Bruno Henrique</td>
<td>3</td>
<td>Flamengo</td>
</tr>

 

 

  </tbody>

 

<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<hr>
<h2>Assistentes</h2>
<thead>
<tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de assistências </th>
<th scope="col">Time</th>

 

</tr>
<tr>
<th scope="row">1</th>
<td>Meia</td>
<td>Alan Patrick</td>
<td>5</td>
<td>Internacional</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Keno</td>
<td>5</td>
<td>Fluminense</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Rony</td>
<td>4</td>
<td>Palmeira</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Candelo</td>
<td>3</td>
<td>Nacional</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>De La Cruz</td>
<td>3</td>
<td>River Plate</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Jhon Kennedy</td>
<td>3</td>
<td>Fluminense</td>
</tr>

<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Raphael Veiga</td>
<td>3</td>
<td>Palmeiras</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Zabala</td>
<td>3</td>
<td>Olimpia</td>
</tr>
<th scope="row"></th>
<td>Meia</td>
<td>A. Silva</td>
<td>3</td>
<td>Olimpia</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Jhon Arias </td>
<td>3</td>
<td>Fluminense</td>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Tonino</td>
<td>2</td>
<td>Bolivar</td>
</tr>
<tr>
<th scope="row">3</th>
<td>Atacante</td>
<td>Marinho</td>
<td>2</td>
<td>Flamengo</td>
</tr>
<tr>

 

 

</thead>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<h2>Cartões amarelos</h2>
<thead>
<tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de cartões amarelos </th>
<th scope="col">Time</th>
<tr>
<th scope="row">1</th>
<td>Zagueiro</td>
<td>Villalba</td>
<td>6</td>
<td>Argentinos Juniors</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Villamíl</td>
<td>5</td>
<td>Bolivar</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Meia</td>
<td>Nicolas Figal</td>
<td>5</td>
<td>Boca Juniors</td>
</tr>
<tr>
<th scope="row"></th>
<td>Lateral-direito</td>
<td>Fernandez</td>
<td>5</td>
<td>Bolivar</td>
</tr>
<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>F.Melo</td>
<td>4</td>
<td>Fluminense</td>
</tr>

 

 


<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>G.Gomez</td>
<td>4</td>
<td>Palmeiras</td>
</tr>

 

 

<tr>
<th scope="row">2</th>
<td>Meia</td>
<td>Bentaberry</td>
<td>4</td>
<td>Bolivar</td>
</tr>
<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>Angelo Rodriguez</td>
<td>4</td>
<td>Deportivo Pereira</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Ortiz</td>
<td>4</td>
<td>Olimpia</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Rodriguez</td>
<td>4</td>
<td>Nacional</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Pallerano</td>
<td>4</td>
<td>Del Valle</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>John Kenedy</td>
<td>4</td>
<td>Fluminense</td>
</tr>

<tr>
<th scope="row">3</th>
<td>Meia</td>
<td>Alan Patrick</td>
<td>4</td>
<td>Internacional</td>
</tr>


</thead>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<h2>Cartões vermelhos</h2>

 

 

  <thead>

 

 

    <tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de cartões vermelhos </th>
<th scope="col">Time</th>

 

<tr>
<th scope="row">1</th>
<td>Lateral-Direito</td>
<td>Santiago Montiel</td>
<td>2</td>
<td>Argentinos Juniors</td>
</tr>
<tr>
<th scope="row">1</th>
<td>Zagueiro </td>
<td>Bruno Valdez</td>
<td>2</td>
<td>Boca Juniors</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>R.Ríos</td>
<td>1</td>
<td>Palmeiras</td>
</tr>

 

 

<tr>
<th scope="row"></th>
<td>Lateral-Direio</td>
<td>Samuel Xavier</td>
<td>1</td>
<td>Fluminense</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Cardozo</td>
<td>1</td>
<td>Olimpia</td>
</tr>
<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>Hauche</td>
<td>1</td>
<td>Racing</td>
</tr>
<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>Quintero</td>
<td>1</td>
<td>Deportivo</td>
</tr>
<tr>
<th scope="row"></th>
<td>Lateral-Esquerdo</td>
<td>Marcelo</td>
<td>1</td>
<td>Fluminense</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>John Kenedy</td>
<td>1</td>
<td>Fluminense</td>
</tr>
<tr>
<th scope="row"></th>
<td>Lateral-Esquerdo</td>
<td>Fabra</td>
<td>1</td>
<td>Boca Juniors</td>
</tr>
</tr>
</thead>
</table>
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>