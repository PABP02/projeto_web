<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-"><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
           <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
              <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>
            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de Gols </th>
      <th scope="col">Time</th>
   
    </tr>
    <tbody>
   
      <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Mastriani</td>
      <td>9</td>
      <td>América Mineiro</td>

    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>N. Fernandez</td>
      <td>8</td>
      <td>Defensa y Justicia</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>A.Bareiro</td>
      <td>6</td>
      <td>San Lorenzo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Rollheiser</td>
      <td>6</td>
      <td>Estudiantes</td>
    </tr>
     <tr>
      <th scope="row">4</th>
      <td>Atacante</td>
      <td>Eduardo Sasha</td>
      <td>5</td>
      <td>RB Bragantino</td>
    </tr>
<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Santander</td>
      <td>5</td>
      <td>Guarani</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Sorriso</td>
      <td>5</td>
      <td>RB Bragantino</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Togni</td>
      <td>5</td>
      <td>Defensa y Justicia</td>
    </tr>
   
    <tr>
      <th scope="row">5</th>
      <td>Atacante</td>
      <td>Guilherme</td>
      <td>4</td>
      <td>Fortaleza</td>
   <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Carrilo</td>
      <td>4</td>
      <td>Estudiantes</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Portillo</td>
      <td>4</td>
      <td>Newell's Old Boys</td>
    </tr>
  
   
   
    <tr>
      <th scope="row">6</th>
      <td>Atacante</td>
      <td>Tiquinho Soares</td>
      <td>3</td>
      <td>Botafogo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Edson Caríus</td>
      <td>3</td>
      <td>Tacuary</td>
    </tr>
  
  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
   
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>Togni</td>
      <td>6</td>
      <td>Defensa y Justicia</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Meia</td>
      <td>Benítez</td>
      <td>4</td>
      <td>America-MG</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>L. Godoy</td>
      <td>4</td>
      <td>Estudiantes</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-esquerdo</td>
      <td>A. Soto</td>
      <td>4</td>
      <td>Defensa y Justicia</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Eduardo Sasha</td>
      <td>3</td>
      <td>RB Bragantino</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-esquerdo</td>
      <td>Juninho Capixaba</td>
      <td>3</td>
      <td>RB Bragantino</td>
    </tr>
<th scope="row"></th>
      <td>Meia</td>
      <td>Juninho</td>
      <td>3</td>
      <td>América-MG</td>
    </tr>
    <tr>
    <th scope="row"></th>
      <td>Meia</td>
      <td>E. Martínez</td>
      <td>3</td>
      <td>América-MG</td>
    </tr>
     <tr>
    <th scope="row"></th>
      <td>Meia</td>
      <td>Nestor</td>
      <td>3</td>
      <td>São Paulo</td>
    </tr>
     <tr>
    <th scope="row"></th>
      <td>Atacante</td>
      <td>Luciano</td>
      <td>3</td>
      <td>São Paulo</td>
    </tr>
    <tr>
    <th scope="row"></th>
      <td>Atacante</td>
      <td>Polo</td>
      <td>3</td>
      <td>Universitario</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Pikachu</td>
      <td>3</td>
      <td>Fortaleza</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Quinonez </td>
      <td>3</td>
      <td>LDU</td>
      <tr>
     </tr>
       <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Villalba </td>
      <td>3</td>
      <td>Libertad</td>
      <tr>
     </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>David Silva</td>
      <td>3</td>
      <td>Millonarios</td>
    </tr>
          <th scope="row">4</th>
      <td>Lateral-esquerdo</td>
      <td>Guilherme</td>
      <td>2</td>
      <td>RB Bragantino</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Marinho</td>
      <td>2</td>
      <td>Marinho</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Renato Augusto</td>
      <td>2</td>
      <td>Corinthians</td>
    </tr>
   
     
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos </th>
      <th scope="col">Time</th>
    <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Lollo</td>
      <td>5</td>
      <td>Estudiantes</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Caio Alexandre</td>
      <td>5</td>
      <td>Fortaleza</td>
    </tr>

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Rodrigo Nestor</td>
      <td>5</td>
      <td>São Paulo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Zagueiro</td>
      <td>Cuesta</td>
      <td>4</td>
      <td>Botafogo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Brítez</td>
      <td>5</td>
      <td>Fortaleza</td>
    </tr>

<tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Quinonez</td>
      <td>4</td>
      <td>LDU</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Adé</td>
      <td>4</td>
      <td>LDU</td>
    </tr>
    

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Benedetti </td>
      <td>4</td>
      <td>Estudiantes de Mérida</td>
    </tr>
   
   
<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Bareiro</td>
      <td>4</td>
      <td>San Lorenzo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>G. Hernandez</td>
      <td>4</td>
      <td>San Lorenzo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>G. Gil Romero</td>
      <td>4</td>
      <td>Guarani </td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro </td>
      <td>Luciatti</td>
      <td>4</td>
      <td>Tigre</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>C. Romero </td>
      <td>4</td>
      <td>Blooming</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Rios</td>
      <td>4</td>
      <td>Tolima</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Salas</td>
      <td>4</td>
      <td>Palestino</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Meia</td>
      <td>Zé Welisson</td>
      <td>3</td>
      <td>Fortaleza</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-direito</td>
      <td>Rafinha</td>
      <td>3</td>
      <td>São Paulo</td>
    </tr>
    
    </tr>
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
     <tr>
      <th scope="row">1</th>
      <td>Lateral-direito </td>
      <td>L. Riascos</td>
      <td>2</td>
      <td>Tolima</td>
    </tr>
      <tr>
      <th scope="row">2</th>
      <td>Meia </td>
      <td>Ascacíbar</td>
      <td>1</td>
      <td>Estudiantes</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Vilanueva</td>
      <td>1</td>
      <td>Magallanes</td>
    </tr>
   
   
<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Munder</td>
      <td>1</td>
      <td>Cobresal</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Matheus Araújo</td>
      <td>1</td>
      <td>Corinthians</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Ryan</td>
      <td>1</td>
      <td>Corinthians</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Joaquim</td>
      <td>1</td>
      <td>Santos</td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Jairo Velez</td>
      <td>1</td>
      <td>César Vallejo</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Goleiro</td>
      <td>Uraezana</td>
      <td>1</td>
      <td>Blooming</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Juan Mercado</td>
      <td>1</td>
      <td>Oriente Petrolero</td>
    </tr>
         <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Cardoso</td>
      <td>1</td>
      <td>Libertad</td>
    </tr>
         <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Marcelo Benevenuto</td>
      <td>1</td>
      <td>Fortaleza</td>
    </tr>
 
   
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>