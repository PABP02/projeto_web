<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Papo de Torcedores</title>
</head>

<body style="background-color: white;">
    <nav class="navbar navbar-expand-lg bg-black">
        <div class="container-fluid">
            <a class="navbar-brand text-"><img src="../teste.PNG" width="250px"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">
                    <li class="nav-item dropdown">
                        <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Opções
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item text-" href="#">Classificações e estatísticas de campeonatos internacionais</a></li>
                            <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a>
                            </li>
                            <li><a class="dropdown-item text-" href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
                            <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
                            <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História dos clubes</a></li>
                            <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
     <style>
  
    body {
      background-color: #f5f5f5;
      font-family: Arial, sans-serif;
    }

    .navbar {
      background-color: #343a40; 
    }

    .navbar-brand img {
      width: 250px;
      height: auto;
    }

    .nav-link {
      color: #ffffff; 
    }



    .container {
      padding: 20px;
    }

    hr {
      background-color: #343a40;
    }

    .container img {
      max-width: 100%;
      height: auto;
    }

    .container a {
      display: block;
      margin: 20px 0;
    }
  </style>
   <div class="container">
<img src="https://a3.espncdn.com/combiner/i?img=%2Fi%2Fleaguelogos%2Fsoccer%2F500%2F2310.png" width="180 px" height="100px"><a class="dropdown-item text-primary" href="classuel.php">Classificação Uefa Europa League</a>
<a class="dropdown-item text-primary" href="estatisticasuel.php">Estatísticas Uefa Europa League</a>
    <hr>
     <img src="https://www.mktesportivo.com/wp-content/uploads/2018/10/champions_premios.jpg" width="180 px" height="100px"><a class="dropdown-item text-primary" href="tabelaucl.php">Classificação Champions League</a>
     <a class = "dropdown-item text-primary" href="estatisticasucl.php">Estatísticas Champions League</a>
    <hr>
 
  <img src="https://s2.glbimg.com/4XO2Yzzu2xdRSpgG5y-1yEFGPic=/0x0:1470x2300/984x0/smart/filters:strip_icc()/s.glbimg.com/es/ge/f/original/2018/06/04/636637610807425204.jpg" width="180 px" height="100px"><a class="dropdown-item text-primary" href="classcon.php">Classificação Libertadores</a>
<a class="dropdown-item text-primary" href="estacon.php">Estatísticas Libertadores</a>
          <hr>
      <img src="https://diariodonordeste.verdesmares.com.br/image/contentid/policy:1.3070509:1618936719/Copa-Sul-Americana.jpg?f=default&$p$f=b44fc55" width="180 px" height="100px"><a class="dropdown-item text-primary" href="classula.php">Classificação Sul-americana</a>
       <a class="dropdown-item text-primary" href="estasula.php">Estatísticas Sul-americana</a>
  </div>
    <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>

</html>
