
<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="150px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         
         
          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
        <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
              <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>
         
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">
          <button class="btn btn-outline- text-info" type="submit">Buscar</button>
        </form>
      </div>
    </div>
  </nav>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <thead>

 

      <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO A</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_vWFDkt_sFIo6aA69GGLrSUxAkihKvThCH2neGD54bA&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>LDU</td>
        <td>12</td>
        <td>8</td>
        <td>3</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">2<img src="https://upload.wikimedia.org/wikipedia/commons/c/cb/Escudo_Botafogo.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Botafogo</td>
        <td>10</td>
        <td>5</td>
        <td>2</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">3<img src="https://upload.wikimedia.org/wikipedia/commons/8/83/Escudo_Deportes_Magallanes.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Magallanes</td>
        <td>4</td>
        <td>-5</td>
        <td>0</td>
        <td>2</td>
        </tr>
        <tr>
        <th scope="row" style="color: red">4<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Universidad_Cesar_Vallejo.svg/1200px-Universidad_Cesar_Vallejo.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>César Vallejo</td>
        <td>4</td>
        <td>-8</td>
        <td>1</td>
        <td>4</td>
        </tr>
        
        </div>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO B</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1<img src="https://logodetimes.com/wp-content/uploads/guarani-paraguai.png"  style="max-width: 80px; max-height: 80px; margin-left: 5px;"></th>
        <td>Guarani</td>
        <td>11</td>
        <td>2</td>
        <td>3</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">2<img src="https://upload.wikimedia.org/wikipedia/pt/3/39/CSEmelec.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Emelec</td>
        <td>9</td>
        <td>0</td>
        <td>2</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">3<img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/4817.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Danubio</td>
        <td>7</td>
        <td>-1</td>
        <td>2</td>
        <td>3</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSyy0gViPQxjsultQtOCWNX758ixTN26zBN346xdAprYg&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Huracan</td>
        <td>5</td>
        <td>-1</td>
        <td>1</td>
        <td>3</td>
        </tr>
        
        </div>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO C</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1<img src="https://s2-ge.glbimg.com/e-xWda3x6xVrxn9PMp1BhlwN5DY=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2020/X/b/OSdKnnQE60uyBYHXuO8w/escudo-rb-bragantino.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Bragantino</td>
        <td>14</td>
        <td>18</td>
        <td>4</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">2<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/da/Escudo_de_Estudiantes_de_La_Plata.svg/1200px-Escudo_de_Estudiantes_de_La_Plata.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Estudiantes </td>
        <td>14</td>
        <td>13</td>
        <td>4</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">3<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Logo_de_Tacuary_2022_PNG_HD.png/800px-Logo_de_Tacuary_2022_PNG_HD.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Tacuary</td>
        <td>6</td>
        <td>-13</td>
        <td>4</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS78EqPstTS8gP3a_vjpPKVgIMywX0ptSbBTWf0lwXwNA&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Oriente Petrolero</td>
        <td>0</td>
        <td>-18</td>
        <td>0</td>
        <td>6</td>
        </tr>
        
        </div>
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO D</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDt-2kUWthohMKyV8ZL7_hhLONULHcZ0LjqCqv3A0s4A&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>São Paulo</td>
        <td>16</td>
        <td>13</td>
        <td>5</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">2<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Escudo_del_Club_Atl%C3%A9tico_Tigre_-_2019.svg/1200px-Escudo_del_Club_Atl%C3%A9tico_Tigre_-_2019.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Tigre </td>
        <td>10</td>
        <td>1</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">3<img src="https://upload.wikimedia.org/wikipedia/commons/4/41/Escudo_Deportes_Tolima_Sin_A%C3%B1o_2.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Tolima</td>
        <td>8</td>
        <td>-2</td>
        <td>2</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4<img src="https://a.espncdn.com/combiner/i?img=/i/teamlogos/soccer/500/18995.png&h=200&w=200"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Academia Puerto Cabello</td>
        <td>0</td>
        <td>-12</td>
        <td>0</td>
        <td>6</td>
        </tr>
        
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO E</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Escudo_del_Club_Atl%C3%A9tico_Newell%27s_Old_Boys_de_Rosario.svg/1200px-Escudo_del_Club_Atl%C3%A9tico_Newell%27s_Old_Boys_de_Rosario.svg.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Newell's Old Boys</td>
        <td>16</td>
        <td>7</td>
        <td>5</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">2<img src="https://upload.wikimedia.org/wikipedia/commons/e/eb/Audax_Italiano_Escudo.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Audax Italiano</td>
        <td>11</td>
        <td>3</td>
        <td>3</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">3<img src="https://s2-ge.glbimg.com/za19TUuxPdZJjx7fccXZVoDmw7A=/0x0:583x587/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2019/K/F/aldv82SQSFO9RDd1wj5g/escudosantos03.jpg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Santos</td>
        <td>5</td>
        <td>-2</td>
        <td>1</td>
        <td>3</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEAcO4E5XnmVnVtlmBGIMtXlop1GMc-N8qFjRXlrtnfA&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Blooming</td>
        <td>1</td>
        <td>-8</td>
        <td>0</td>
        <td>5</td>
        </tr>
        
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO F</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1<img src="https://upload.wikimedia.org/wikipedia/commons/d/db/EscudoDefensayjustica.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Defensa Y Justiça</td>
        <td>15</td>
        <td>7</td>
        <td>5</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">2<img src="https://upload.wikimedia.org/wikipedia/commons/a/ac/Escudo_do_America_Futebol_Clube.svg"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>América-MG</td>
        <td>10</td>
        <td>4</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">3<img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Escudo_de_Millonarios_temporada_2022.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Millionarios</td>
        <td>10</td>
        <td>3</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjZ1MuQ3sNHR-k80SWgFJdT3CIomj8_ZzpY7cycgrgYA&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Penarol</td>
        <td>0</td>
        <td>-14</td>
        <td>0</td>
        <td>6</td>
        </tr>
        
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO G</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8Ofg8X5tKMxpRep_PTE9Dr1VbE69aYawBUd5Wmjgglg&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Goias</td>
        <td>12</td>
        <td>4</td>
        <td>3</td>
        <td>0</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">2<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Logo_oficial_de_Universitario.png/640px-Logo_oficial_de_Universitario.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Universitario</td>
        <td>10</td>
        <td>1</td>
        <td>3</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">3<img src="https://upload.wikimedia.org/wikipedia/commons/5/58/Escudo_de_Independiente_Santa_Fe.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Santa Fé</td>
        <td>7</td>
        <td>-1</td>
        <td>2</td>
        <td>3</td>
        </tr>
        
         
        
              <tr>
        <th scope="row" style="color: red">4<img src="https://upload.wikimedia.org/wikipedia/pt/thumb/d/d3/Gimnasia_y_Esgrima_escudo.png/150px-Gimnasia_y_Esgrima_escudo.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Gimnasia</td>
        <td>4</td>
        <td>-4</td>
        <td>1</td>
        <td>4</td>
        </tr>
        
        <table style="border: solid; border-width: 2px;"><table border="1">
        <table class="table">
        <thead>
        
         
        
              <tr>
        <th scope="col">Colocação</th>
        <th scope="col">Time</th>
        <th scope="col">Pts</th>
        <th scope="col">SG</th>
        <th scope="col">Vitórias</th>
        <th scope="col">Derrotas</th>
        
        </thead>
        <h1>GRUPO H</h1>
        <div class="row">
        <tr>
        <th scope="row" style="color: blue">1<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSO7KYWIp8CSeA9yhTrZ0YL-cjdsa4HBr4fpNX55UFxLg&s"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Fortaleza</td>
        <td>15</td>
        <td>12</td>
        <td>5</td>
        <td>1</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: yellow">2<img src="https://upload.wikimedia.org/wikipedia/commons/6/62/Escudo_del_Club_Atl%C3%A9tico_San_Lorenzo_de_Almagro.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>San Lorenzo</td>
        <td>8</td>
        <td>1</td>
        <td>2</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">3<img src="https://upload.wikimedia.org/wikipedia/pt/7/72/CDPalestino.png"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Palestino</td>
        <td>8</td>
        <td>0</td>
        <td>2</td>
        <td>2</td>
        
         
        
            </tr>
        <tr>
        <th scope="row" style="color: red">4<img src="https://upload.wikimedia.org/wikipedia/pt/7/77/EstudiantesDeM%C3%A9ridaFC.pngs"  style="max-width: 50px; max-height: 50px; margin-left: 5px;"></th>
        <td>Estudiantes de Mérida</td>
        <td>3</td>
        <td>-13</td>
        <td>1</td>
        <td>5</td>
        </tr>
        
        </div>
        </tr>
        </thead>
        </table>
        </table>
        </table>
        
         
        
        <br></br>
        
         
        
        <p style="color: blue;">Texto em azul = classificação para as oitavas de finais</p>
        <p style="color: yellow;">Texto em amarelo = classificação para o play-off</p>
        <p style="color: red;"> Texto em vermelho = eliminado</p>
        
         
        
        <br></br>
        
         
        
        <h1>PLAYOFFS DE OITAVAS DE FINAIS</h1>
        <p>Universitario 1 x 2 Corinthians</p>
        <p>Estudiantes 5 x 2 Barcelona Guayaquil</p>
        <p>América-MG 6 x 3 Colo Colo</p>
        <p>Tigre 1 x 3 Libertad</p>
        <p>Audax Italiano 0 x 1 Nublense</p>
        <p>San Lorenzo 3 x 0 Independiente Medelin</p>
        <p>Patronato 1 x 3 Botafogo</p>
        <p>Emelec 1 x 0 Sporting Cristal</p>
        
         
        
        <h1>OITAVAS DE FINAIS</h1>
        <p>Newell's Old Boys 1 x 2 Corinthians</p>
        <p>Goiás 0 x 5 Estudiantes</p>
        <p>Bragantino 4(3) x (4)4 América-MG</p>
        <p>Fortaleza 2 x 1 Libertad</p>
        <p>LDU 3(4) x (3)3 Nublense</p>
        <p>São Paulo 2 x 1 San Lorenzo</p>
        <p>Guarani-PAR 1 x 2 Botafogo</p>
        <p>Defensa y Justiça 3 x 1 Emelec</p>
        
         
        
        <h1>QUARTAS DE FINAIS</h1>
        <p>Estudiantes 1(2) x (3)1 Corinthians</p>
        <p>Fortaleza 5 x 2 América-MG</p>
        <p>São Paulo 2(5) x (4)2 LDU</p>
        <p>Defensa y Justiça 3 x 2 Botafogo</p>
        
         
        
        <h1>SEMIFINAIS</h1>
        <p>Fortaleza 3 x 1 Corinthians</p>
        <p>Defensa y Justiça 0 x 3 LDU</p>
        
         
        
        <h1>FINAL</h1>
        <p>Fortaleza 1(3) x 1(4) LDU</p>
        
        
        <h1>CAMPEÃO LDU <img src="https://jogada10.com.br/wp-content/uploads/2023/10/F9kCmcXXkAANScv_Easy-Resize.com_-1200x799.jpg"   style="max-width: 300px; max-height: 300px; margin-left: 5px;"></h1>
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>