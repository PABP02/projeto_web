<!DOCTYPE html>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro ">
   <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-"><img src="../teste.PNG" width="150px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         
         
          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
              <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
              <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>
         
        </ul>        <form class="d-flex" role="search">
          <input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">
          <button class="btn btn-outline- text-info" type="submit">Buscar</button>
        </form>
      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
  <thead>

 

      <tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<h1>GRUPO A</h1>
<div class="row">
<tr>
<th scope="row" style="color: blue">1</th>
<td>West Ham</td>
<td>9</td>
<td>3</td>
<td>3</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: green">2</th>
<td>Freiburg</td>
<td>9</td>
<td>7</td>
<td>3</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: yellow">3</th>
<td>Olympiacos</td>
<td>4</td>
<td>-1</td>
<td>1</td>
<td>2</td>

 

    </tr>
<tr>
<th scope="row" style="color: red">4</th>
<td>Backa Topola</td>
<td>1</td>
<td>-9</td>
<td>0</td>
<td>3</td>
</tr>
</div>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<thead>

 

      <tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<h1>GRUPO B</h1>
<div class="row">
<tr>
<th scope="row" style="color: blue">1</th>
<td>Olympique Marsella</td>
<td>8</td>
<td>4</td>
<td>2</td>
<td>0</td>

 

    </tr>
<tr>
<th scope="row" style="color: green">2</th>
<td>Brighton</td>
<td>7</td>
<td>3</td>
<td>2</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: yellow">3</th>
<td>AEK</td>
<td>4</td>
<td>-3</td>
<td>1</td>
<td>2</td>

 

    </tr>
<tr>
<th scope="row" style="color: red">4</th>
<td>Ajax</td>
<td>2</td>
<td>-4</td>
<td>0</td>
<td>2</td>
</tr>

 

    </tr>
</div>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<thead>

 

      <tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<h1>GRUPO C</h1>
<div class="row">
<tr>
<th scope="row" style="color: blue">1</th>
<td>Betis</td>
<td>9</td>
<td>4</td>
<td>3</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: green">2</th>
<td>Rangers</td>
<td>7</td>
<td>1</td>
<td>2</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: yellow">3</th>
<td>Sparta Praga</td>
<td>4</td>
<td>-1</td>
<td>1</td>
<td>2</td>

 

    </tr>
<tr>
<th scope="row" style="color: red">4</th>
<td>Aris Limassol</td>
<td>3</td>
<td>-4</td>
<td>1</td>
<td>3</td>
</tr>
</div>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<thead>

 

      <tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<h1>GRUPO D</h1>
<div class="row">
<tr>
<th scope="row" style="color: blue">1</th>
<td>Atalanta</td>
<td>10</td>
<td>4</td>
<td>3</td>
<td>0</td>

 

    </tr>
<tr>
<th scope="row" style="color: green">2</th>
<td>Sporting</td>
<td>7</td>
<td>1</td>
<td>2</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: yellow">3</th>
<td>Sturm</td>
<td>4</td>
<td>-1</td>
<td>1</td>
<td>2</td>

 

    </tr>
<tr>
<th scope="row" style="color: red">4</th>
<td>Rakow</td>
<td>1</td>
<td>-4</td>
<td>0</td>
<td>3</td>
</tr>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<thead>

 

      <tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<h1>GRUPO E</h1>
<div class="row">
<tr>
<th scope="row" style="color: blue">1</th>
<td>Liverpool</td>
<td>9</td>
<td>7</td>
<td>3</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: green">2</th>
<td>Toulouse</td>
<td>7</td>
<td>-2</td>
<td>2</td>
<td>1</td>

 

    </tr>

 

    <tr>
<th scope="row" style="color: yellow">3</th>
<td>Union S.</td>
<td>4</td>
<td>-4</td>
<td>1</td>
<td>2</td>

 

    </tr>
<tr>
<th scope="row" style="color: red">4</th>
<td>Lask</td>
<td>3</td>
<td>-1</td>
<td>1</td>
<td>3</td>
</tr>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<thead>

 

      <tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<h1>GRUPO F</h1>
<div class="row">
<tr>
<th scope="row" style="color: blue">1</th>
<td>Rennes</td>
<td>9</td>
<td>5</td>
<td>3</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: green">2</th>
<td>Vilarreal</td>
<td>6</td>
<td>0</td>
<td>2</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: yellow">3</th>
<td>Panathinaikos</td>
<td>4</td>
<td>-1</td>
<td>1</td>
<td>2</td>

 

    </tr>
<tr>
<th scope="row" style="color: red">4</th>
<td>Maccabi Haifa</td>
<td>1</td>
<td>-4</td>
<td>0</td>
<td>2</td>
</tr>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<thead>

 

      <tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<h1>GRUPO G</h1>
<div class="row">
<tr>
<th scope="row" style="color: blue">1</th>
<td>Slavia Praha</td>
<td>9</td>
<td>8</td>
<td>3</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: green">2</th>
<td>Roma</td>
<td>9</td>
<td>5</td>
<td>3</td>
<td>1</td>

 

    </tr>
<tr>
<th scope="row" style="color: yellow">3</th>
<td>Servette</td>
<td>4</td>
<td>-5</td>
<td>1</td>
<td>2</td>

 

    </tr>
<tr>
<th scope="row" style="color: red">4</th>
<td>Sheriff</td>
<td>1</td>
<td>-8</td>
<td>0</td>
<td>3</td>
</tr>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<thead>

 

      <tr>
<th scope="col">Colocação</th>
<th scope="col">Time</th>
<th scope="col">Pts</th>
<th scope="col">SG</th>
<th scope="col">Vitórias</th>
<th scope="col">Derrotas</th>

</thead>
<h1>GRUPO H</h1>
<div class="row">
<tr>
<th scope="row" style="color: blue">1</th>
<td>Leverkusen</td>
<td>12</td>
<td>10</td>
<td>4</td>
<td>0</td>

 

    </tr>
<tr>
<th scope="row" style="color: green">2</th>
<td>Qarabag</td>
<td>6</td>
<td>-3</td>
<td>2</td>
<td>2</td>

 

    </tr>
<tr>
<th scope="row" style="color: yellow">3</th>
<td>Molde</td>
<td>0</td>
<td>4</td>
<td>2</td>
<td>2</td>

 

 

    </tr>
<tr>
<th scope="row" style="color: red">4</th>
<td>Hacken</td>
<td>0</td>
<td>-11</td>
<td>0</td>
<td>4</td>
</tr>

</div>
</tr>

 

</thead>
</table>
</table>
</table>

 <h1 style="color: blue">Texto em azul: Classificação para as Oitavas de Final </h1>
  <h1 style="color: green">Texto em verde: Classificação para a segunda fase</h1>
   <h1 style="color: yellow">Texto em amarelo: Classificação para a Conference League</h1>

           <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script> 
</body>
</html>