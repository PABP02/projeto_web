<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
        <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
              <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>
<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
   <h2>Artilharia</h2>
<thead>
<tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de Gols </th>
<th scope="col">Time</th>

 

</tr>
<tbody>
<tr>
<th scope="row">1</th>
<td>Atacante</td>
<td>João Pedro</td>
<td>3</td>
<td>Brighton</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Mojmir Chytil</td>
<td>2</td>
<td>Slavia</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Andrea Belotti</td>
<td>2</td>
<td>Roma</td>
</tr>
<tr>
<th scope="row">3</th>
<td>Atacante</td>
<td>Shavy Babicka</td>
<td>2</td>
<td>Aris Limassol</td>

 

 

    </tr>

 

<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Aubameyang</td>
<td>2</td>
<td>Olympique</td>
</tr>

 

 

    <tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Lukaku</td>
<td>2</td>
<td>Roma</td>
</tr>

 

 

    <tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Willian</td>
<td>2</td>
<td>Stutm Graz</td>
</tr>

 

 

 

    <tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>El Kaabi</td>
<td>2</td>
<td>Olympiacos</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Roland Sallai</td>
<td>2</td>
<td>Friburg</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>A.Sima</td>
<td>2</td>
<td>Rangers</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Meia</td>
<td>Gyõkeres</td>
<td>2</td>
<td>Sporting</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Ogbu</td>
<td>2</td>
<td>Slavia Praha</td>
</tr>

 

<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Krejcí</td>
<td>2</td>
<td>Sparta Praha</td>
<tr>
<th scope="row">2</th>
<td>Atacante</td>
<td>Pantovic</td>
<td>1</td>
<td>FK TSC</td>
</tr>

 

 

 

   

 

<tr>
<th scope="row">2</th>
<td>Meia</td>
<td>Pellegrin</td>
<td>1</td>
<td>Roma</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Meia</td>
<td>Schranz</td>
<td>2</td>
<td>Slavia Praha</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Meia</td>
<td>D.Vida</td>
<td>1</td>
<td>Athens</td>
</tr>
</tbody>

 

<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<hr>
<h2>Assistentes</h2>
<thead>
<tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de assistências </th>
<th scope="col">Time</th>

 

</tr>
<tr>
<th scope="row">1</th>
<td>Meia</td>
<td>Harit</td>
<td>3</td>
<td>Olympique</td>
</tr>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Ward-Prowse</td>
<td>3</td>
<td>West-Ham</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Meia</td>
<td>Bengtsson</td>
<td>2</td>
<td>Aris Limassol</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Zeki</td>
<td>2</td>
<td>Roma</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Konstantions</td>
<td>2</td>
<td>Olympiacos</td>
</tr>
<tr>
<th scope="row"></th>
<td>Lateral Esquerdo</td>
<td>Amine</td>
<td>2</td>
<td>B.Leverkusen</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Pellegrin</td>
<td>1</td>
<td>Roma</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Garcia</td>
<td>1</td>
<td>Athens</td>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Jarrod</td>
<td>1</td>
<td>West Ham
</td>
<tr>
<th scope="row"></th>
<td>Atacante</td>
<td>Borna Sosa</td>
<td>1</td>
<td>Ajax</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Horvath</td>
<td>1</td>
<td>Lask</td>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Matej Rynes</td>
<td>1</td>
<td>Sparta Praha</td>
<tr>

 

 

</thead>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<h2>Cartões amarelos</h2>
<thead>
<tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de cartões amarelos </th>
<th scope="col">Time</th>
<tr>
<th scope="row">1</th>
<td>Zagueiro</td>
<td>Alex Baena</td>
<td>2</td>
<td>Villareal</td>
</tr>
<tr>
<th scope="row">2</th>
<td>Zagueiro</td>
<td>Eriksen</td>
<td>2</td>
<td>Molde FK</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Pedraza</td>
<td>2</td>
<td>Villareal</td>
</tr>
<tr>
<th scope="row"></th>
<td>Zagueiro</td>
<td>Kiki</td>
<td>2</td>
<td>Sherif</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Jankovic</td>
<td>2</td>
<td>Qarabag</td>
</tr>
<tr>
<th scope="row">3</th>
<td>Zagueiro</td>
<td>Patrick Andrade</td>
<td>1</td>
<td>Qarabag</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Teixeira</td>
<td>1</td>
<td>Sturm Graz</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Darboa</td>
<td>1</td>
<td>Lask</td>
</tr>
<tr>
<th scope="row"></th>
<td>Meia</td>
<td>Petros Mantalos</td>
<td>1</td>
<td>Athens</td>
</tr>

 

 

 

</thead>
<table style="border: solid; border-width: 2px;"><table border="1">
<table class="table">
<h2>Cartões vermelhos</h2>

 

 

  <thead>

 

 

    <tr>
<th scope="col">Ranking</th>
<th scope="col">Posição</th>
<th scope="col">Jogador</th>
<th scope="col">Número de cartões vermelhos </th>
<th scope="col">Time</th>

 

<tr>
<th scope="row">1</th>
<td>Meia</td>
<td>Silvano</td>
<td>1</td>
<td>Ajax</td>
</tr>
<tr>
<th scope="row">1</th>
<td>Lateral Esquerdo</td>
<td>João Paulino</td>
<td>1</td>
<td>Sherif</td>
</tr>

 

 

<tr>
<th scope="row">1</th>
<td>Zagueiro</td>
<td>Andreas</td>
<td>1</td>
<td>Olympiacos</td>
</tr>
<tr>
<th scope="row">1</th>
<td>Zagueiro</td>
<td>Logan Costa</td>
<td>1</td>
<td>Toulose</td>
</tr>
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>

</body>
</html>