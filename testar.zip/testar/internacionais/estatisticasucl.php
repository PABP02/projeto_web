<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Papo de Torcedores</title>
</head>

<body style="background-color:gainsboro;">
  <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="../teste.PNG" width="250px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="text-decoration: none;">


          <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>

            <ul class="dropdown-menu">
                   <li><a class="dropdown-item text-" href="../internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>
             <li><a class="dropdown-item text-" href="../Estaduais/estaduais.php">Classificações e estatísticas estaduais</a></li>
              <li><a class="dropdown-item text-"  href="../Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>
              <li><a class="dropdown-item text-" href="../Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="../htmls clubes/História do seu clube de coração.php">História do seu clube de coração</a></li>
              <li><a class="dropdown-item text-" href="../blog/iablog.php">Acesso ao um blog sobre IA</a></li>

            </ul>
          </li>

        </ul>

      </div>
    </div>
  </nav>

<table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Artilharia</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de Gols </th>
      <th scope="col">Time</th>
   
    </tr>
    <tbody>
       <tr>
      <th scope="row">1</th>
      <td>Atacante</td>
      <td>R.Hojlund</td>
      <td>5</td>
      <td>Manchester Alvarez</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Morata</td>
      <td>3</td>
      <td>Atl.Madrid</td>

    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Evanilson</td>
      <td>4</td>
      <td>Porto</td>
    </tr>
  <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Griezmann</td>
      <td>4</td>
      <td>Atl.Madrid.
                                                          </td>
    </tr>
       <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Haaland/td>
      <td>4</td>
      <td>Manchester City</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Kane</td>
      <td>4</td>
      <td>Bayern Munchen</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Alvarez</td>
      <td>3</td>
      <td>Manchester City</td>
    </tr>
      <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Becker </td>
      <td>2</td>
      <td>Union Berlin</td>
    </tr>
 
<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Bukari</td>
      <td>2</td>
      <td>Estrela Vermelha</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Sikan</td>
      <td>2</td>
      <td>Shaktar</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Gabriel Jesus</td>
      <td>2</td>
      <td>Arsenal</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Casemiro</td>
      <td>2</td>
      <td>Manchester United</td>
   <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Galeno</td>
      <td>2</td>
      <td>Porto</td>
    </tr>
   
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Brais Méndez</td>
      <td>2</td>
      <td>Real Sociedad</td>
    </tr>
 
   
   
    <tr>
      <th scope="row">3</th>
      <td>Atacante</td>
      <td>Vinicius Júnior</td>
      <td>1</td>
      <td>Real Madrid</td>
    </tr>

  </tbody>
 
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <hr>
    <h2>Assistentes</h2>
  <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de assistências </th>
      <th scope="col">Time</th>
       <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Davidson Sanchez</td>
      <td>2</td>
      <td>Galatasaray</td>
    </tr>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Saka</td>
      <td>2</td>
      <td>Arsenal</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Rashford</td>
      <td>3</td>
      <td>Manchester United</td>
    </tr>
   <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Gundogan</td>
      <td>2</td>
      <td>Barcelona</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-direito</td>
      <td>Molina</td>
      <td>2</td>
      <td>Atlético de Madrid</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Vermeeren</td>
      <td>2</td>
      <td>Antwerp</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Kampl</td>
      <td>2</td>
      <td>RB Leipzig</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Martial</td>
      <td>1</td>
      <td>Manchester United </td>
    </tr>
 
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Muller</td>
      <td>1</td>
      <td>Bayern de Munique</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Doku</td>
      <td>1</td>
      <td>Manchester City</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Guendouzi</td>
      <td>1</td>
      <td>Lazio</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-direito</td>
      <td>Mazraoui</td>
      <td>1</td>
      <td>Bayern de Munique</td>
    </tr>
   
     
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões amarelos</h2>
     <thead>
    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões amarelos </th>
      <th scope="col">Time</th>
    <tr>
      <th scope="row">1</th>
      <td>Meia</td>
      <td>Sergio Oliveira</td>
      <td>2</td>
      <td>Galatasaray</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Emre Can</td>
      <td>2</td>
      <td>Borussia Dortmund</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Schlotterbeck</td>
      <td>2</td>
      <td>Borussia Dortmund</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Romero</td>
      <td>4</td>
      <td>Tottenham</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Aslanni</td>
      <td>2</td>
      <td>Inter de Milão</td>
    </tr>
        <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Gavi</td>
      <td>2</td>
      <td>Barcelona</td>
    </tr>

<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Samuel Lino</td>
      <td>2</td>
      <td>Atlético de Madrid</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Musah</td>
      <td>2</td>
      <td>Milan</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Konoplya</td>
      <td>2</td>
      <td>Shaktar Donetsk</td>
    </tr>

<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Danylo Sikan</td>
      <td>2</td>
      <td>Shaktar Donetsk</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Lateral-esquerdo</td>
      <td>Meling</td>
      <td>2</td>
      <td>Copenhaguen</td>
    </tr>
   
   

    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Lerager</td>
      <td>2</td>
      <td>Copenhaguen</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Baidoo</td>
      <td>2</td>
      <td>Salzburg</td>
    </tr>
<tr>
      <th scope="row">2</th>
      <td>Atacante</td>
      <td>Ángel Correa</td>
      <td>1</td>
      <td>Atlético de Madrid</td>
    </tr>

<tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Raspadori</td>
      <td>1</td>
      <td>Napoli</td>
    </tr>

   
    </tr>
  </thead>
  <table style="border: solid; border-width: 2px;"><table border="1">
  <table class="table">
    <h2>Cartões vermelhos</h2>

  <thead>

    <tr>
      <th scope="col">Ranking</th>
      <th scope="col">Posição</th>
      <th scope="col">Jogador</th>
      <th scope="col">Número de cartões vermelhos </th>
      <th scope="col">Time</th>
   
     <tr>
      <th scope="row">1</th>
      <td>Zagueiro</td>
      <td>Esgaio</td>
      <td>1</td>
      <td>Celtic</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Odin Holm</td>
      <td>1</td>
      <td>Celtic</td>
    </tr>
   
   
<tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Gavi</td>
      <td>1</td>
      <td>Barcelona</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Meia</td>
      <td>Casemiro</td>
      <td>1</td>
      <td>Manchester United</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Atacante</td>
      <td>Pedro Gonçalves</td>
      <td>1</td>
      <td>Sporting</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td>Lateral Direito</td>
      <td>Jelert</td>
      <td>1</td>
      <td>Copenhaguen</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Zagueiro</td>
      <td>Antonio Silva</td>
      <td>1</td>
      <td>Benfica</td>
    </tr>
   </tr>
 </thead>
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>