<?php
include "PDO.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $pdo = new usePDO();

  $nome = $_POST['nome'];
  $email = $_POST['email'];
  $senha = $_POST['senha'];

  $umadminzeronao = 0; // valor padrão pro campo 
  $insertUser = $pdo->insertusers($nome, $email, $senha, $umadminzeronao);

    $insertPeople = $pdo->insertPeople($_POST['cpf'], $_POST['ddn'], $insertuser);
    $insertState = $pdo->insertState($_POST['estado']);
    $insertCity = $pdo->insertCity($_POST['cidade'], $insertState);
    $insertAddress = $pdo->insertAddress($_POST['cep'], $_POST['endereco'], $insertCity, $insertPeople);

    if ($insertUser) {
        header('location: login.php?sucesso');
    } else {
        header('location: cadastro.php?erro');
    }
}


	function validaCPF($cpf) {

$cpf = str_replace('.','',$cpf);
$cpf = str_replace('-','',$cpf);

    
  

    //$cpf = preg_replace("/[^0-9]/", "", $cpf);
    //$cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);
    

    if (strlen($cpf) != 11) {
      echo '<script type="text/javascript"> alert("CPF inválido");</script>';
    exit;
    }
    else if ($cpf == '000.000.000-00' || 
        $cpf == '111.111.111-11' || 
        $cpf == '222.222.222-22' || 
        $cpf == '333.333.333-33' || 
        $cpf == '444.444.444-44' || 
        $cpf == '555.555.555-55' || 
        $cpf == '666.666.666-66' || 
        $cpf == '777.777.777-77' || 
        $cpf == '888.888.888-88' || 
        $cpf == '999.999.999-99') {
         echo '<script type="text/javascript"> alert("CPF inválido");</script>';
        exit;
     } else {   
        
        for ($t = 9; $t < 11; $t++) {
            
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf[$c] * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ($cpf[$c] != $d) {
                    echo '<script type="text/javascript"> alert("CPF inválido");</script>';
               exit;
            }
        }
        validaCPF($_POST['cpf']);
}
}


 ?>
 <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>