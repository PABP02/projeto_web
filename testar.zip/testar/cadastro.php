<?php 
$title = 'Cadastro de novo usuário';
include 'cabecalho.php'; ?>
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>


    <script>
    $(document).ready(function(){

    $("#cpf").mask("000.000.000-00");

    $("#cep").mask("00000-000");
    });


</script>
</head>

 <script>
         function  buscaCEP(){
    var cep = document.getElementById('cep').value;
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://viacep.com.br/ws/' + cep + '/json/', true);
    console.log(xhr);

    xhr.onload = function(){
        if(xhr.status >= 200 && xhr.status < 400){
            var data = JSON.parse(xhr.responseText);
            if(data.erro){
                alert('Cep não encontrado');

            }
            else{
                document.getElementById('endereco').value = data.logradouro;
      
                document.getElementById('cidade').value = data.localidade;
                document.getElementById('estado').value = data.uf;
             
            }
        }
        else{
            alert('Erro ao tentar buscar o CEP');
        }
    };
    xhr.send();
}



</script>




<body>
<style type="text/css">
    
    body {
        background-color: ;
    }

    h1 {
        text-align: center;
        color: white;
        font-family: 'Lucida Sans', 'Lucina Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    }

    form {
        background-color: black;
        border-radius: 15px;
        box-shadow: 0px 0px 50px darkgrey;
        max-width: 500px;
        width: 70%;
        padding: 20px;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        color: white;
    }

    form input[type="text"],
    form input[type="email"],
    form input[type="number"],
        form input[type="date"],
    form input[type="password"] {
        width: calc(100% - 40px); 
        height: 27px;
        border: 1px solid #ccc;
        padding-left: 10px;
        margin: 10px 0;
    }

    form input[type="submit"] {
        width: 100%;
        height: 50px;
        cursor: pointer;
        background: white;
        color: white;
        border: 0;
        border-radius: 20px;
        transition: 1s;
    }

    form input[type="submit"]:hover {
        background-color: white;
    }
  a {
               width: 100%;
        height: 50px;
        cursor: pointer;
        background: white;
        color: white;
        border: 0;
        border-radius: 20px;
        transition: 1s;
    }
    form input[type="text"]:focus {
        outline: 05;
    }

    form input[type="password"]:focus {
        outline: 0;
    }

  
    .alert-danger {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
        padding: 10px;
        margin-top: 20px;
    }

    .alert-success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        padding: 10px;
        margin-top: 20px;
    }
   .small-input {
    width: calc(20% - 31px); 
}


    .input-group-text i {
        font-size: 1.0rem; 
        font-height: 1px
    }
    body {
    background-image: url('https://img.freepik.com/fotos-premium/fundo-do-estadio-de-futebol_1000348-1814.jpg');
    background-size: cover; 
    background-repeat: no-repeat; 
    background-attachment: fixed; 
}


.input-group i {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  z-index: 2;
}


.input-group i.bi-eye-fill {
  color: #aaa; 
}


.input-group i.bi-eye-slash-fill {
  color: #333; 
}

</style>
<?php
    include "PDO.php";

    $pdo = new usePDO();
    $pdo->createDB();


    $resultado = NULL;

    ?>
<div class="container">
       
        <form method="post" action="processa.php" id="formlogin" class="col-6 p-4 needs-validation" novalidate>
            <div class="input-group mb-3">
           
                <?php
                if ($resultado != NULL) {
                    echo '<input type="text" class="form-control small-input" placeholder="Nome Completo*" aria-label="nome" aria-describedby="basic-addon1" name="nome" id ="nome" required value="' . $resultado['nome'] . '">';
                } else {
                    echo '<input type="text" class="form-control small-input" placeholder="Nome Completo*" aria-label="nome" aria-describedby="basic-addon1" name="nome" id ="nome" required>';
                }
                ?>
                <div class="invalid-feedback">
                    Insira o seu nome!
                </div>
            </div>
            <div class="input-group mb-3">
           
                <?php
                if ($resultado != NULL) {
                    echo '<input type="email" class="form-control small-input" placeholder="E-mail*" aria-label="email" aria-describedby="basic-addon1" name="email" id = "email" required value="' . $resultado['email'] . '">';
                } else {
                    echo '<input type="email" class="form-control small-input" placeholder="E-mail*" aria-label="email" aria-describedby="basic-addon1" name="email"  id = "email" required>';
                }
                ?>
                <div class="invalid-feedback">
                    Insira o seu e-mail!
                </div>
            </div>
                      <div class="input-group mb-3">
                
                <?php
                if ($resultado != NULL) {
                    echo '<input type="text"  class="form-control small-input" placeholder="CPF*"   name="cpf" id = "cpf" maxlength="14" minlength="14" required value="' . $resultado['cpf'] . '">';
                } else {
                    echo '<input type="text" class="form-control small-input"  placeholder="CPF*"  name="cpf" id = "cpf" maxlength="14" minlength="14" required>';
                }
                ?>
                <div class="invalid-feedback">
                    Insira o seu CPF!
                </div>
            </div>

        <div class="input-group mb-3">
      
            <?php
            if ($resultado != NULL) {
                echo '<input type="date" class="form-control small-input" placeholder="Data de Nascimento" aria-label="ddn" aria-describedby="basic-addon1" name="ddn" id = "ddn" required value="' . $resultado['ddn'] . '">';
            } else {
                echo '<input type="date" class="form-control small-input" placeholder="Data de Nascimento" aria-label="ddn" aria-describedby="basic-addon1" name="ddn"   id = "ddn"  required>';
            }
            ?>
            <div class="invalid-feedback">
                Insira a data de nascimento!
            </div>
        </div>
           <div class="input-group mb-3">
          
            <?php
            if ($resultado != NULL) {
                echo '<input type="text" class="form-control small-input" placeholder="CEP*" aria-label="ddn" aria-describedby="basic-addon1" name="cep" id="cep" onblur="buscaCEP()" maxlength="9" minlength="9" required value="' . $resultado['cep'] . '">';
            } else {
                echo '<input type="text" class="form-control small-input" placeholder="CEP*" aria-label="ddn" aria-describedby="basic-addon1" name="cep" id="cep" onblur="buscaCEP()" maxlength="9" minlength="9" required>';
            }
            ?>
            <div class="invalid-feedback">
                Insira o seu CEP!
            </div>
        </div>
    
                <div class="input-group mb-3">
             
                <?php
                if ($resultado != NULL) {
                    echo '<input type="text" class="form-control small-input" placeholder="Endereço*" aria-label="endereco" aria-describedby="basic-addon1" name="endereco" id ="endereco" required value="' . $resultado['endereco'] . '">';
                } else {
                    echo '<input type="text" class="form-control small-input" placeholder="Endereço*" aria-label="endereco" aria-describedby="basic-addon1" name="endereco" id ="endereco" required>';
                }
                ?>
                <div class="invalid-feedback">
                    Insira o seu endereço!
                </div>
            </div>

   
       
            <div class="input-group mb-3">
            
                <?php
                if ($resultado != NULL) {
                    echo '<input type="text" class="form-control small-input" placeholder=" Cidade* " aria-label="cidade" aria-describedby="basic-addon1" name="cidade" id = "cidade"  required value="' . $resultado['cidade'] . '">';
                } else {
                    echo '<input type="text" class="form-control small-input" placeholder=" Cidade*" aria-label="cidade" aria-describedby="basic-addon1" name="cidade" id = "cidade" required>';
                }
                ?>
                <div class="invalid-feedback">
                    Insira a sua cidade!
                </div>
            </div>
            <div class="input-group mb-3">
           
                <?php
                if ($resultado != NULL) {
                    echo '<input type="text" class="form-control small-input" placeholder=" Estado* " aria-label="estado" aria-describedby="basic-addon1" name="estado" id = "estado" required value="' . $resultado['estado'] . '">';
                } else {
                    echo '<input type="text" class="form-control small-input" placeholder=" Estado* " aria-label="estado" aria-describedby="basic-addon1" name="estado" id = "estado" required>';
                }
                ?>
                <div class="invalid-feedback">
                    Insira o estado da sua cidade!
                </div>
            </div>
          <div class="input-group mb-3">
             
                <?php
                if ($resultado != NULL) {
                    echo '<input type="password" class="form-control small-input" placeholder="Senha*" aria-label="senha" aria-describedby="basic-addon1" name="senha" id = "senha" required value="' . $resultado['senha'] . '"> <i class="bi bi-eye-fill" id="btn-senha" onclick="mostrarSenha()"> </i>';
                } else {
                    echo '<input type="password" class="form-control small-input" placeholder="Senha*" aria-label="senha" aria-describedby="basic-addon1" name="senha"  id = "senha" required><i class="bi bi-eye-fill" id="btn-senha" onclick="mostrarSenha()"> </i>';
                }
                ?>
                   </div>
                <div class="invalid-feedback">
                    Insira a sua senha!
                </div>
         
            <div class="input-group mb-3">
            
                <input type="password" class="form-control small-input" placeholder="Confirme sua senha* " aria-label="Confirmar" aria-describedby="basic-addon1" name="confirm" id = "confirm" required><i class="bi bi-eye-fill" id="btn-confirm" onclick="confirmarSenha()"> </i>
                      </div>
                <div class="invalid-feedback">
                    Confirme sua senha!
                </div>
      
            <input type="submit" value="Cadastrar" class="btn btn-primary" style="color: black;">
          
                 <div>
    <a href="login.php"  class="btn btn-dark btn-block btn-lg">Já tem uma conta?</a>
            </div>
          
        </form>
        <div vw class="enabled">
  <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
        <?php
        if (isset($_GET["erro"])) {
            if (str_contains($_GET['erro'], 'email')) {
                echo '<script type="text/javascript"> alert("Email Duplicado");</script>';
            } else
                echo '<script type="text/javascript"> alert("Problemas ao salvar cadastro no servidor!");</script>';
        }
        ?>
    </div>


    <script>
        function mostrarSenha() {
    var inputPass = document.getElementById('senha');
      
    var btnShowPass = document.getElementById('btn-senha');

    if (inputPass.type === 'password') {
        inputPass.setAttribute('type', 'text');
        btnShowPass.classList.replace('bi-eye-fill', 'bi-eye-slash-fill');
    } else {
        inputPass.setAttribute('type', 'password');
        btnShowPass.classList.replace('bi-eye-slash-fill', 'bi-eye-fill');
    }
}
function confirmarSenha() {
    var inputPass = document.getElementById('confirm');
      
    var btnShowPass = document.getElementById('btn-confirm');

    if (inputPass.type === 'password') {
        inputPass.setAttribute('type', 'text');
        btnShowPass.classList.replace('bi-eye-fill', 'bi-eye-slash-fill');
    } else {
        inputPass.setAttribute('type', 'password');
        btnShowPass.classList.replace('bi-eye-slash-fill', 'bi-eye-fill');
    }
}
document.getElementById('formlogin').addEventListener('submit', function(event) {
    var senha = document.getElementById('senha').value;
    var confirmSenha = document.getElementById('confirm').value;

    if (senha !== confirmSenha) {
        event.preventDefault();
        alert('As senhas não coincidem. Por favor, insira senhas iguais nos campos "Senha" e "Confirmar Senha".');
    }
});

//se for password oculta o texto, se  nao texto visivel,  se for 'password' o código altera o tipo de entrada para text e torna o texto visível, e os <i> para mostrar ou nao a senha

      //Validação do formulário com bootstrap
        (function () {
            'use strict'

            

            

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    var senha = document.getElementsByName('senha')[0];
                    var confirm = document.getElementsByName('confirm')[0];
                    
                    
                    if (!form.checkValidity() || (senha.value != confirm.value)){
                        confirm.classList.add("is-invalid");
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    
                    form.classList.add('was-validated')
                }, false)
            })
        })()

    </script>
        
</body>
</html>



