<?php
session_start();

if ((!isset($_SESSION['email'])) || (!isset($_SESSION['nome'])) || (!isset($_SESSION['timecoracao']))) {
  
    unset($_SESSION['email']);
    unset($_SESSION['nome']);
    unset($_SESSION['timecoracao']);
      
    session_unset();
    header('location:login.php?erro');
    exit;
}

$nome = $_SESSION['nome'];
if ($_SESSION['email'] === 'admin@times') {

    header('Location: login.php?erro');
    exit();
}





$title = 'Página do Sistema';
include 'cabecalho.php';
?>
<body style="background-color: black ;">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <nav class="navbar navbar-expand-lg bg-black">
    <div class="container-fluid">
      <a class="navbar-brand text-" ><img src="teste.PNG" width="150px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
       
            <li class="nav-item dropdown">
            <button type="button" class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Opções
            </button>
         
            <ul class="dropdown-menu">
              <li><a class="dropdown-item text-" href="internacionais/internacionais.php">Classificações e estatísticas de campeonatos internacionais</a></li>

              <li><a class="dropdown-item text-"  href="Estaduais/estaduais.php">Classificações e estatísticas de estaduais</a></li>
             
                    <li><a class="dropdown-item text-"  href="Estatísticas/Estatísticas.php">Estatísticas de nacionais</a></li>

              <li><a class="dropdown-item text-" href="Classificação/Classificação.php">Classificações de nacionais</a></li>
             
              <li><a class="dropdown-item text-" href="hist.php">História dos clubes</a></li>
              <li><a class="dropdown-item text-" href="blog/iablog.php">Acesso ao um blog sobre IA</a></li>
                

            </ul>
          </li>
        </ul>
      </div>
    </div>
           <ul class="navbar-nav ms-3 me-5">
        <li class="nav-item dropdown me-5">
            <a class="btn btn-outline-secondary dropdown-toggle mt-2 text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Perfil
            </a>
            <ul class="dropdown-menu">
              <li><p class="dropdown-item"><?php echo "Olá $nome"; ?></p></li>
<li>
    <?php
    if (isset($_SESSION['timecoracao'])) {
        echo '<p class="dropdown-item">Clube de coração: ' . $_SESSION['timecoracao'] . ' <a href="timecoracao.php"><i class="bi bi-pencil-fill text-danger"></i></a></p>';
    }
    ?>
</li>


              <li><hr class="dropdown-divider"></li>
   
</li>
              <li><a class="dropdown-item" href="logout.php">Sair</a></li>
            </ul>
          </li>
        </ul>

        </ul>
        <form class="d-flex" role="search">
          <input class="form-control me-2" type="Digite" placeholder="Digite" aria-label="Digite">
          <button type="submit">Buscar</button>
        </form>
      </div>
    </div>
  </nav>



<div class="slideshow-container">
    <a href="new1.php">
        <div class="mySlides fade">
            <img src="https://a.espncdn.com/photo/2023/1208/r1263997_1280x720_16-9.jpg" style="width:100%">
            <div class="text">Corinthians não vai renovar com Renato Augusto, Gil, Giuliano e Cantillo</div>
        </div>
    </a>

    <a href="new2.php">
        <div class="mySlides fade">
            <img src="https://s2-ge.glbimg.com/EYBSdG1Hv6uXJprEcg6WcaER6Hc=/0x0:1024x698/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2022/M/5/PHNlBeTDOu2dMLBx4oEQ/gettyimages-1244135696.jpg" style="width:100% ">
            <div class="text">Brasil formaliza candidatura para sediar Copa do Mundo feminina de 2027 e disputará com cinco países. </div>
        </div>
    </a>

    <a href="new4.php">
        <div class="mySlides fade">
            <img src="https://s2-ge.glbimg.com/oGCvPjDn56uR372dH6o56aB4ZEA=/0x0:3820x2573/1000x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2023/f/A/RirKdPQ1OxHZ39RXEcdQ/2023-11-04t221244z-1528986335-up1ejb41pp6uy-rtrmadp-3-soccer-libertadores-boj-flu-report.jpg" style="width:100%">
            <div class="text">John Kennedy fala em realização de sonho em jogar o Mundial com o Fluminense: "Marcar mais a história"</div>
        </div>
    </a>
</div>

 <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>

<script type="text/javascript">
  let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex - 1].style.display = "block";
  setTimeout(showSlides, 4000);
}

function plusSlides(n) {
      showSlides(slideIndex += n);
    }

</script>
  <style type="text/css">.slideshow-container {
  position: relative;
  max-width: 1000px;
  margin: auto;
}

.mySlides {
  display: none;
}

.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

   .prev, .next {
      cursor: pointer;
      position: absolute;
      top: 50%;
      width: auto;
      padding: 16px;
      margin-top: -22px;
      color: white;
      font-weight: bold;
      font-size: 36px;
      transition: 0.6s ease;
      user-select: none;
      z-index: 1000;
    }

    .next {
      right: 0;
    }
</style>
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>