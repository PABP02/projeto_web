<?php
include "PDO.php";
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login']) && isset($_POST['senha'])) {
    $login = $_POST['login'];
    $senha = $_POST['senha']; 

    $pdo = new usePDO();
    $user = $pdo->selectUser($login);

    if ($user && $login === $user['email'] && password_verify($senha, $user['password_user'])) {
        // Ve c é admin
        if ($login === 'admin@times' && password_verify($senha, $user['password_user'])) {
            $_SESSION['email'] = $login;
            $_SESSION['nome'] = $user['nome'];
            $_SESSION['ID'] = $user['ID'];

            // Redireciona para a página 'Copa do mundo'
            header('Location: Copa do mundo.php');
            exit();
        } else {
            //  não  admin 'timecoracao.php'
            $_SESSION['email'] = $login;
            $_SESSION['nome'] = $user['nome'];
            $_SESSION['ID'] = $user['ID'];

            $time_coracao = $pdo->selectTimeCoracao($user['ID']);
            $_SESSION['timecoracao'] = $time_coracao['timecoracao'];

            header('Location: timecoracao.php');
            exit();
        }
    } else {
        header('Location: login.php?erro');
        exit();
    }
} else {
    header('Location: login.php?erro');
    exit();
}
?>
