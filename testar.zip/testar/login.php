
<?php
$title = 'Login';
include 'cabecalho.php'; 

if (isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['senha']) && !empty($_POST['senha'])) {

 

    $login = $_POST['login'];
   $senha = hash('sha256', $_POST['senha']);
   
       if ($u->insertusers($email, $senha) == true) {
           
           //  sessão admin é true
           if (isset($_SESSION['admin']) && $_SESSION['admin'] == true) {
               header("Location: Copa do mundo.php"); // Redirecionar para a página de admin
           } else {
               header("Location: timecoracao.php"); // Redirecionar para a página padrão do usuário
           }
       } else {
           header("Location: login.php?erro");
       }
   }
   
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
<body>
<style type="text/css">
   
    body {
        background-color: black;
    }

    h1 {
        text-align: center;
        color: white;
        font-family: 'Lucida Sans', 'Lucina Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    }

    form {
        background-color: grey;
        border-radius: 15px;
        box-shadow: 0px 0px 50px darkgrey;
        max-width: 500px;
        width: 70%;
        padding: 20px;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        color: white;
    }

    form input[type="text"],
    form input[type="email"],
    form input[type="number"],
    form input[type="password"] {
        width: calc(0% - 0px); 
        height: 42px;
        border: 1px solid #ccc;
        padding-left: 10px;
        margin: 10px 0;
    }

    form input[type="submit"] {
        width: 100%;
        height: 40px;
        cursor: pointer;
        background: red;
        color: white;
        border: 0;
        border-radius: 20px;
        transition: 1s;
    }

    form input[type="submit"]:hover {
        background-color: white;
    }

    form input[type="text"]:focus {
        outline: 05;
    }

    form input[type="password"]:focus {
        outline: 0;
    }

    .alert-danger {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
        padding: 10px;
        margin-top: 20px;
    }

    .alert-success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        padding: 10px;
        margin-top: 20px;
    }
   
   
    .input-group-text i {
        font-size: 1.5rem; 
    }
    .input-group i {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  z-index: 2;
}

.input-group i.bi-eye-fill {
  color: #aaa; 
}


.input-group i.bi-eye-slash-fill {
  color: #333; 
}

</style>
 <div class="container">
        <h1>ENTRE EM NOSSO SITE!</h1>
        <form method="post" action="autentica.php" id="formlogin" class="col-6 p-4 needs-validation" novalidate>
            <div class="input-group mb-3">
                <input type="email" class="form-control" placeholder="Email" aria-label="Email" aria-describedby="basic-addon1" name="login" required>
                <div class="invalid-feedback">
                    Insira um email válido!
                </div>
            </div>

             <div class="input-group mb-3">
         
            <input type="password" class="form-control" placeholder="Senha " aria-label="Senha" aria-describedby="basic-addon2" name = "senha" id = "senha" required ><i class="bi bi-eye-fill" id="btn-senha" onclick="mostrarSenha()"> </i>
       
        </div>

            <div class="input-group mb-3">
                <input type="submit" value="Acessar" aria-label="Acessar">
            </div>
            <div class="input-group mb-3">
                <a href="cadastro.php" class="btn btn-primary form-control mt-3" aria-label="Cadastre-se">Cadastre-se!</a>
            </div>
        </form>
    </div>

    <?php
    if (isset($_GET["erro"])) {
        echo '<script type="text/javascript"> alert("Acesso Negado! Verifique usuário e senha");</script>';
    }
    if (isset($_GET["sucesso"])) {
        echo '<script type="text/javascript"> alert("Cadastro realizado com sucesso");</script>';
    }
    ?>

    <script>
        function mostrarSenha() {
             var inputPass = document.getElementById('senha');
            var btnShowPass = document.getElementById('btn-senha');

            if (inputPass.type === 'password') {
                inputPass.type = 'text';
                btnShowPass.classList.replace('bi-eye-fill', 'bi-eye-slash-fill');
            } else {
                inputPass.type = 'password';
                btnShowPass.classList.replace('bi-eye-slash-fill', 'bi-eye-fill');
            }
        }
        //se for password oculta o texto, se  nao texto visivel,  se for 'password' o código altera o tipo de entrada para text e torna o texto visível, e os <i> para mostrar ou nao a senha

        (function () {
            'use strict';

            var forms = document.querySelectorAll('.needs-validation');

            Array.prototype.slice.call(forms).forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        })();
    </script>

<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html> 
