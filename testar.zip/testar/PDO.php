<?php

class usePDO {

 private $servername = "localhost";
 private $username = "root";
 private $password = "";
 private $dbname = "papodetorcedor";
 private $instance;
 function getInstance() {
     if (empty($this->instance)) {
      $this->instance = $this->connection();
      $this->createTableusers();
      $this->createTablePeople();
      $this->createTableState();
      $this->createTableCity();
      $this->createTableAddress();
      $this->createTableTimess();
      $this->createTableTimecoracao();
  }
  return $this->instance;
}
//verifica c a  $this->instance tá vazia, c tiver n foi criado instancia d conexao, no if $this->instance = $this->connection() cria instancia d conexao c o banco de dados e chama o método connection()


private function connection() {
  try {
   $conn = new PDO("mysql:host=$this->servername;dbname=$this->dbname", $this->username, $this->password);
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   return $conn;
} catch (PDOException $e) {
   echo "Connection failed: " . $e->getMessage() . "<br>";
   if (strpos($e->getMessage(), "Unknown database '$this->dbname'")) {
    echo "Conexão nula, criando o banco pela primeira vez" . "<br>";
    $conn = $this->createDB();
    $sql = "USE $this->dbname";
    $conn->exec($sql);
    return $conn;
} else {
    die("Connection failed: " . $e->getMessage() . "<br>");
}
}
}

function createDB() {
  try {
   $cnx = new PDO("mysql:host=$this->servername", $this->username, $this->password);
   $cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   $sql = "CREATE DATABASE IF NOT EXISTS $this->dbname";
   $cnx->exec($sql);
   return $cnx;
} catch (PDOException $e) {
   echo $sql . "<br>" . $e->getMessage();
}
}


function createTableusers() {
    try {
        $cnx = $this->getInstance();
        $sql = "
            CREATE TABLE IF NOT EXISTS users (
                ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(150) NOT NULL,
                email VARCHAR(150) UNIQUE NOT NULL,
                password_user TEXT NOT NULL,
                umadminzeronao INT(1) NOT NULL DEFAULT 0
            )";
        $cnx->exec($sql);

        // Verifica se o usuário padrão já existe
        $existingUser = $this->selectUser('admin@times');
        if (!$existingUser) {
            $hashed_password = password_hash('admin', PASSWORD_DEFAULT); // hash
            $sql2 = "INSERT INTO users (ID, nome, email, password_user, umadminzeronao) VALUES (1, 'Administrador', 'admin@times', '$hashed_password', 1)";
            $cnx->exec($sql2);
        } else {
            
        }
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}





function createTablePeople() {
    try {
        $cnx = $this->getInstance();
        $sql = "
            CREATE TABLE IF NOT EXISTS People (
                ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                cpf VARCHAR(14) UNIQUE NOT NULL,
                birth_date VARCHAR(12) NOT NULL,
                id_user INT UNSIGNED,
                FOREIGN KEY (id_user) REFERENCES users(ID)
            )";
        $cnx->exec($sql);

        // existe registro na tabela 
        $existingRecord = $this->selectPeople();
        if (!$existingRecord) {
            // Se não coloca valores padrão
            $sql2 = "INSERT INTO People (cpf, birth_date, id_user) VALUES ('admin', 'admin', 1)";
            $cnx->exec($sql2);
        }
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}

function createTableState() {
    try {
        $cnx = $this->getInstance();
        $sql = "
            CREATE TABLE IF NOT EXISTS State (
                ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                state_name VARCHAR(50) NOT NULL
            )";
        $cnx->exec($sql);

        // existe registro na tabela 
        $existingRecord = $this->selectState();
        if (!$existingRecord) {
            // Se não coloca valores padrão
            $sql2 = "INSERT INTO State (state_name) VALUES ('admin')";
            $cnx->exec($sql2);
        }
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}

function createTableCity() {
    try {
        $cnx = $this->getInstance();
        $sql = "
            CREATE TABLE IF NOT EXISTS City (
                ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                city_name VARCHAR(100) NOT NULL,
                state_ID INT UNSIGNED,
                FOREIGN KEY (state_ID) REFERENCES State(ID)
            )";
        $cnx->exec($sql);

        // existe registro na tabela 
        $existingRecord = $this->selectCity();
        if (!$existingRecord) {
            // Se não coloca valores padrão
            $sql2 = "INSERT INTO City (city_name, state_ID) VALUES ('admin', 1)";
            $cnx->exec($sql2);
        }
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}

function createTableAddress() {
    try {
        $cnx = $this->getInstance();
        $sql = "
            CREATE TABLE IF NOT EXISTS Address (
                ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                CEP VARCHAR(8) NOT NULL,
                road VARCHAR(150) NOT NULL,
                city_ID INT UNSIGNED,
                people_ID INT UNSIGNED,
                FOREIGN KEY (city_ID) REFERENCES City(ID),
                FOREIGN KEY (people_ID) REFERENCES People(ID)
            )";
        $cnx->exec($sql);

        // existe registro na tabela 
        $existingRecord = $this->selectAddress();
        if (!$existingRecord) {
            // Se não coloca valores padrão
            $sql2 = "INSERT INTO Address (CEP, road, city_ID, people_ID) VALUES ('admin', 'admin', 1, 1)";
            $cnx->exec($sql2);
        }
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}
  function createTableTimess(){
    try{
        $cnx = $this->getInstance();
        $sql = "
        CREATE TABLE IF NOT EXISTS Timess (
            ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            clube TEXT NOT NULL,  
            historia TEXT NOT NULL,
            idolo TEXT  NOT NULL,
            img TEXT NOT NULL
         
  
        )";
  
        $cnx->exec($sql);

    }
    catch(PDOException $e)
    {
        echo $sql . "<br>" . $e->getMessage();
    }
  }
  function createTableTimecoracao() {
    try {
     $cnx = $this->getInstance();
     $sql = "
     CREATE TABLE IF NOT EXISTS Timecoracao (
      ID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      timecoracao VARCHAR(90) NOT NULL,
      ID_user INT UNSIGNED ,
      FOREIGN KEY (ID_user) REFERENCES users(ID)
  
  )";
     $cnx->exec($sql);
     

  } catch (Exception $e) {
  
     return $sql . "<br>" . $e->getMessage();
  }
  }
  


 function insertusers($nome, $email, $password, $umadminzeronao) {
    try {
        $cnx = $this->getInstance();
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (nome, email, password_user, umadminzeronao) VALUES (?, ?, ?, ?)";
        $stmt = $cnx->prepare($sql);
        $stmt->execute([$nome, $email, $hashed_password, $umadminzeronao]);

        $result = $stmt->rowCount(); //  número de linhas afetadas
        return $result;
    } catch (PDOException $e) {
        error_log('Erro ao inserir usuário: ' . $e->getMessage());
        return false;
    }
}




function insertPeople($CPF, $birth_date, $ID_user) {
    try {
        $cnx = $this->getInstance();
        $sql = "INSERT INTO People (cpf, birth_date, id_user) VALUES (?, ?, ?)";
        $stmt = $cnx->prepare($sql);
        $stmt->execute([$CPF, $birth_date, $ID_user]);

        $result = $cnx->lastInsertId();
        return $result;
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
}

  
  function insertState($state_name) {
    try {
     $cnx = $this->getInstance();
     $sql = "INSERT INTO State(
      `state_name`
      )
     VALUES (
      \"$state_name\"
  )";
     $cnx->exec($sql);
     $result = $cnx->lastInsertId();
     return $result;
  } catch (Exception $e) {
     echo $sql . "<br>" . $e->getMessage();
     return false;
  }
  }
  
  
  
  function insertCity($city_name, $stateID) {
    try {
     $cnx = $this->getInstance();
     $sql = "INSERT INTO City(
      `city_name`,
      `state_ID`
      )
     VALUES (
      \"$city_name\",
      $stateID
  )";
     $cnx->exec($sql);
     $result = $cnx->lastInsertId();
     return $result;
  } catch (Exception $e) {
     echo $sql . "<br>" . $e->getMessage();
     return false;
  }
  }
  
  
  function insertAddress($cep, $road, $city_Id, $people_ID) {
    try {
        $cnx = $this->getInstance();
        $sql = "INSERT INTO Address (CEP, road, city_ID, people_ID) VALUES (?, ?, ?, ?)";
        $stmt = $cnx->prepare($sql);
        $stmt->execute([$cep, $road, $city_Id, $people_ID]);

        $result = $cnx->lastInsertId();
        return $result;
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
}

  
  function insertTimess($clube, $historia, $idolo, $img){
   try{
       $cnx = $this->getInstance();
       $sql = "INSERT INTO `Timess` (
           `clube`,
           `historia`,
           `idolo`,
           `img`
           ) 
       VALUES (
           \"$clube\",
           \"$historia\",
           \"$idolo\",
           \"$img\"
       )";
           $cnx->exec($sql);
           $result = $cnx->lastInsertId();
           return $result;
       } catch(PDOException $e) {
           echo $sql . "<br>" . $e->getMessage();
           die();
           return false;
       }
   }
  
  
  
   function insertTimescoracao($timecoracao, $userId){
    try{
        $cnx = $this->getInstance();
        $sql = "INSERT INTO `Timecoracao` (
            `timecoracao`,
            `id_user`
            ) VALUES (
            \"$timecoracao\",
            $userId
        )";
            $cnx->exec($sql);
            $result = $cnx->lastInsertId();
        } catch(PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
        }
    }
  
    function selectTimess($id){
        $sql = "SELECT * FROM `Timess` WHERE ID=$id";
        try{
            $cnx = $this->getInstance();
            $this->createTableTimess();
            $result = $cnx->query($sql);
            return $result->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
        }
    }
  
    function selectTimeCoracao($id){
        $sql = "SELECT * FROM `timecoracao` WHERE `id_user`=\"$id\"";
        try{
            $cnx = $this->getInstance();
            $this->createTableTimess();
            $result = $cnx->query($sql);
            return $result->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
        }
    }
  
  
  
  
  
  
  
  
  function selectUser($email) {
        $sql = "SELECT * FROM `users` WHERE `email`=\"$email\"";
        try {
         $cnx = $this->getInstance();
         $result = $cnx->query($sql);
         return $result->fetchAll()[0];
     } catch (PDOException $e) {
         echo $sql . "<br>" . $e->getMessage();
     }
  }
  
  function selectPeople() {
    try {
        $cnx = $this->getInstance();
        $sql = "SELECT * FROM People";
        $result = $cnx->query($sql);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
         echo $sql . "<br>" . $e->getMessage();
        return false;
    }
}
function selectState() {
    try {
        $cnx = $this->getInstance();
        $sql = "SELECT * FROM State";
        $result = $cnx->query($sql);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
          echo $sql . "<br>" . $e->getMessage();
        return false;
    }
}

function selectCity() {
    try {
        $cnx = $this->getInstance();
        $sql = "SELECT * FROM City";
        $result = $cnx->query($sql);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
           echo $sql . "<br>" . $e->getMessage();
        return false;
    }
}
function selectAddress() {
    try {
        $cnx = $this->getInstance();
        $sql = "SELECT * FROM Address";
        $result = $cnx->query($sql);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
        return false;
    }
}

  function deleteuser($id){
      try{
          $cnx = $this->getInstance();
          $sql = "DELETE FROM `users` WHERE id = $id";
  
          $cnx->exec($sql);
      }
      catch(PDOException $e)
      {
          echo $sql . "<br>" . $e->getMessage();
      }
  }
  function deletePeople($id){
      try{
          $cnx = $this->getInstance();
          $sql = "DELETE FROM `People` WHERE id = $id";
  
          $cnx->exec($sql);
      }
      catch(PDOException $e)
      {
          echo $sql . "<br>" . $e->getMessage();
      }
  }
  
  
  function deleteState($id){
      try{
          $cnx = $this->getInstance();
          $sql = "DELETE FROM `State` WHERE id = $id";
  
          $cnx->exec($sql);
      }
      catch(PDOException $e)
      {
          echo $sql . "<br>" . $e->getMessage();
      }
  }
  
  function deleteCity($id){
      try{
          $cnx = $this->getInstance();
          $sql = "DELETE FROM `City` WHERE id = $id";
  
          $cnx->exec($sql);
      }
      catch(PDOException $e)
      {
          echo $sql . "<br>" . $e->getMessage();
      }
  }
  function deleteAddress($id){
      try{
          $cnx = $this->getInstance();
          $sql = "DELETE FROM `Address` WHERE id = $id";
  
          $cnx->exec($sql);
      }
      catch(PDOException $e)
      {
          echo $sql . "<br>" . $e->getMessage();
      }
  }
  function deleteTimess($id){
    try {
        $cnx = $this->getInstance();
        $stmt = $cnx->prepare("DELETE FROM `Timess` WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    } catch(PDOException $e) {
        echo $e->getMessage();
    }
  }
  
  function selectAsterisco(){
  
     $sql = "SELECT * FROM `Timess`";
     try{
        $cnx = $this->getInstance();
        $this->createTableTimess();
        $result = $cnx->query($sql);
  
        return $result->fetchAll();
    }
    catch(PDOException $e)
    {
        echo $sql . "<br>" . $e->getMessage();
    }
  }
  
  function updateuser($id, $name, $email, $password_user){
    try{
        $cnx = $this->getInstance();
        $sql = "UPDATE `users`
        SET 
        `name`=\"$name\",      
        `email`=\"$email\",
        `password_user`=\"$password_user\"
        WHERE 
        id=$id";
  
        $cnx->exec($sql);
    }
    catch(PDOException $e)
    {
        echo $sql . "<br>" . $e->getMessage();
    }
  }
  
  function updatePeople($id, $CPF, $birth_date){
   try{
       $cnx = $this->getInstance();
       $sql = "UPDATE `People`
       SET 
       `CPF`=\"$CPF\",      
       `birth_date`=\"$birth_date\"
       WHERE 
       id=$id";
  
       $cnx->exec($sql);
   }
   catch(PDOException $e)
   {
       echo $sql . "<br>" . $e->getMessage();
   }
  }
  
  function updateState($id, $state_name){
   try{
       $cnx = $this->getInstance();
       $sql = "UPDATE `State`
       SET 
       `state_name`=\"$state_name\"
       WHERE 
       id=$id";
  
       $cnx->exec($sql);
   }
   catch(PDOException $e)
   {
       echo $sql . "<br>" . $e->getMessage();
   }
  }
  
  function updateCity($id, $city_name){
   try{
       $cnx = $this->getInstance();
       $sql = "UPDATE `City`
       SET 
       `city_name`=\"$city_name\"
       WHERE 
       id=$id";
  
       $cnx->exec($sql);
   }
   catch(PDOException $e)
   {
       echo $sql . "<br>" . $e->getMessage();
   }
  }
  
  function updateAddress($id, $cep, $road){
   try{
       $cnx = $this->getInstance();
       $sql = "UPDATE `Address`
       SET 
       `cep`=\"$cep\",
       `road`=\"$road\"
  
       WHERE 
       id=$id";
  
       $cnx->exec($sql);
   }
   catch(PDOException $e)
   {
       echo $sql . "<br>" . $e->getMessage();
   }
  }
  
  function update($id, $clube, $historia, $idolo, $img){
     try{
         $cnx = $this->getInstance();
         if($img != NULL){
           $sql = "UPDATE `Timess`
           SET 
           `clube`=\"$clube\",        
           `historia`=\"$historia\",
           `idolo`=\"$idolo\",
           `img`=\"$img\"
           WHERE 
           id=$id";
       }
       else{
           $sql = "UPDATE `Timess`
           SET 
           `clube`=\"$clube\",        
           `historia`=\"$historia\",
           `idolo`=\"$idolo\"
           WHERE 
           id=$id";
       }
  
       $cnx->exec($sql);
       return true;
   }
   catch(PDOException $e)
      {
     echo $sql . "<br>" . $e->getMessage();
     return false;
      }
  }
  function updateTimecoracao($id, $timecoracao, $user_id){
   try{
       $cnx = $this->getInstance();
       $sql = "UPDATE `timecoracao`
       SET 
       `timecoracao`=\"$timecoracao\",
       `id_user` = \"$user_id\"
       WHERE 
       `ID`=\"$id\"";
  
       $cnx->exec($sql);
   }
   catch(PDOException $e)
   {
       echo $sql . "<br>" . $e->getMessage();
   }
  }
  }
  
  ?>
  