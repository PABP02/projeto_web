<!DOCTYPE html>
<html>
<head>
  <title>Cadastro de Times</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
</head>
<body>

  <?php
  include "PDO.php";

  $pdo = new usePDO();
  $pdo->createDB();
  $pdo->createTableTimess();
  $resultado = NULL;

  if(isset($_GET['id'])) {
    $resultado = $pdo->selectTimess($_GET['id']);
  }

  if(isset($_GET['erro'])){
    //Mostrar mensagem de erro
    echo "erro no upload";
  }
  ?>

  <div class="container">
    <?php 
    if($resultado != NULL) {
      echo '<img src="data:image/png;base64,' . $resultado['img'] . '" alt="Logotipo do time" width="300px">';
    }


    
    if($resultado != NULL) {
      echo '<form action="update.php" method="POST" class="col-6 p-4 needs-validation" novalidate enctype="multipart/form-data">';
      echo '<input type="hidden" name="ID" value="'.$resultado['ID'].'">';
    } else {
      echo '<form action="processaa.php" method="POST" class="col-6 p-4 needs-validation" enctype="multipart/form-data" novalidate>';
    }
    ?>

    <h1 class="mb-3">Cadastro de Times</h1>
    <div class="input-group mb-3">

      <?php 
      if($resultado != NULL) {
        echo '<input type="text" class="form-control" placeholder="Time" aria-label="time" aria-describedby="basic-addon1" name="clube" id="clube" required value="'.$resultado['clube'].'">';
      } else {
        echo '<input type="text" class="form-control" placeholder="Time" aria-label="time" aria-describedby="basic-addon1" name="clube" id="clube" required>';
      }
      ?>

    </div>
    <div class="row">
      <div class="input-group mb-3">
        <?php 
        if($resultado != NULL) {
          echo '<input type="text" class="form-control" placeholder="História" aria-label="história" aria-describedby="basic-addon1" name="historia" id="historia" required value="'.$resultado['historia'].'">';
        } else {
          echo '<input type="text" class="form-control" placeholder="História" aria-label="história" aria-describedby="basic-addon1" name="historia" id="historia" required>';
        }
        ?>

      </div>
      <div class="input-group mb-3">

        <?php 
        if($resultado != NULL) {
          echo '<input type="text" class="form-control" placeholder="Ídolo" aria-label="ídolo" aria-describedby="basic-addon1" name="idolo" id="idolo" required value="'.$resultado['idolo'].'">';
        } else {
          echo '<input type="text" class="form-control" placeholder="Ídolo" aria-label="ídolo" aria-describedby="basic-addon1" name="idolo" id="idolo" required>';
        }
        ?>

      </div>

    </div>

    <!-- <input type="hidden" name="MAX_FILE_SIZE" value="30000" required> -->
    <input type="file" name="imagem" id="imagem">
    <br>
    <br>
    <button type="submit">Enviar</button>

    <br>
    <br>
    <hr>
  </form>
</div>
<div vw class="enabled">
     <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
<script>
// Validação do formulário com bootstrap
  (function () {
    'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
  })()
</script>

</body>
</html>
