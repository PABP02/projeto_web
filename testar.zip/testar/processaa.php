<?php 
include "PDO.php";
session_start();


$pdo = new usePDO();


if(isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
    $img = $_FILES['imagem']['tmp_name'];
    $bin = file_get_contents($img);
    $img_string = base64_encode($bin);


    $pdo->insertTimess($_POST['clube'], $_POST['historia'], $_POST['idolo'], $img_string);

    header("location: historia.php");
} else {
    echo '<script> alert("Erro ao carregar a imagem.")</script>';
    header("location: indexx.php");
}
?>