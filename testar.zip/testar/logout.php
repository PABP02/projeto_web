<?php
	session_start();
	session_unset(); 
	session_destroy(); 
	header('location:login.php');
?>
<div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>