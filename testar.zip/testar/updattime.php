<?php
include "PDO.php";

session_start();

$pdo = new usePDO();

$pdo->updateTimecoracao($_POST['ID'], $_POST['timecoracao'], $_SESSION['ID']); 
$_SESSION['timecoracao'] = $_POST['timecoracao'];
header("location:teste.php");
?>
