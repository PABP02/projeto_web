<!DOCTYPE html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
<?php
include "pdo.php";


$pdo = new usePDO();
$pdo -> createDB();
$pdo -> createTableusers();

session_start();
if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['nome']) == true)) {
    unset($_SESSION['email']);
    unset($_SESSION['nome']);
    session_unset();
    header('location:login.php?erro');
}

$nome = $_SESSION['nome'];


?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Leitura de Dados</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        h1 {
            text-align: center;
            padding: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #dddddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        tr:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Dados Cadastrados</h1>
        <div class="d-flex justify-content-center my-3">
        <a href="cadastro.php" class="btn btn-primary">Novo Cadastro</a>
    </div>
    <table>
        <thead>
            <tr>
                
                <th>Nome </th>
                <th>Email</th>
                <th>CPF</th>
                <th>Data de Nascimento</th>
                <th>CEP</th>
                <th>Endereço</th>
                <th>Cidade</th>
                 <th>Estado</th>
                
                 <th scope="col">Editar</th>
              <th scope="col">Excluir</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($codigo as $dados): ?>
                <tr>
                <td><?php echo $dados['nome']; ?></td>
                    <td><?php echo $dados['email']; ?></td>
                    <td><?php echo $dados['cpf']; ?></td>
                    <td><?php echo $dados['ddn']; ?></td>
                    <td><?php echo $dados['cep']; ?></td>
                    <td><?php echo $dados['endereco']; ?></td>
                          <td><?php echo $dados['cidade']; ?></td>
                                <td><?php echo $dados['estado']; ?></td>
                    <td>
                <a href="updateusuario.php?id= <?php echo $dados['ID'] ?>">
                    <i class="bi bi-pencil-fill text-primary"></i>
                </a>
                  <a href="delete.php?id= <?php echo $dados['ID'] ?>">
                    <i class="bi bi-pencil-fill text-primary"></i>
                </a>
            </td>
           
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div vw class="enabled">
   <div vw-access-button class="active"></div>
  <div vw-plugin-wrapper>
    <div class="vw-plugin-top-wrapper"></div>
  </div>
</div>

<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
  new window.VLibras.Widget({
      rootPah: '/app',
      personalization: 'https://vlibras.gov.br/config/default_logo.json',
      opacity: 0.5,
      position: 'L',
      avatar: 'random',
  });
</script>
</body>
</html>